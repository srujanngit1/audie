from datetime import datetime
from pathlib import Path
import os

script_dir = str(Path(os.path.dirname(__file__)).resolve())

##########################################
#             BASE CONFIG                #
##########################################

TODAY_DATE = datetime.now().strftime('%Y-%m-%d')
LOGPATH = f"{script_dir}/logs"
STATUS_EMOJIS = {
    'green': '\U00002705',  # ✅
    'amber': '\U000026A0',  # ⚠️
    'red': '\U0000274C'     # ❌
}
TEST_FLAG = True

##########################################
#                MINMAX                  #
##########################################

# Profile columns for analysis
PROFILE_COLUMNS = [
    "Person_Mailable_flag", 
    "Prospect Email", 
    "Households Greater than or Equal to 6", 
    "Available_For_Adsmart_Selection", 
    "Available_For_LiveRamp_Selection", 
    "Available_For_Partially_Addressed_Mail_Selection", 
    "Available_For_Match_ESIMedia", 
    "pc_county_or_unitary_auth_code_2011",
]

# C-variables columns for frequency analysis
C_VARIABLES_COLUMNS = [
    "C000001A", "C000005", "C000002A", "C000002B", "C000002D", 
    "C000002E", "C000002F", "C000003A", "C000003B", "C000004", 
    "C000008A", "C000008B", "C000014A", "C000018A", "C000011A", 
    "C000011B", "C000017", "C000016", "C000013", "C000010A", 
    "C000010B", "C000019", "C000009", "C000015", "C000020A",
    "C000020B", "C000020C", "C000020D", "C000020E", "C000020F",
    "C000024A", "C000024B", "C000024C", "C000021A", "C000025A",
    "C000025B", "C000025C", "C000025D", "C000025E", "C000025F",
    "C000022", "C000023", "C000029", "C000031", "C000063",
    "C000064", "C000059", "C000092", "C000065", "C000066",
    "C000067A", "C000067B", "C000067C", "C000067D", "C000067E",
    "C000067F", "C000067G", "C000067H", "C000067I", "C000067J",
    "C000067K", "C000067L", "C000067M", "C000067N", "C000067O",
    "C000067P", "C000067Q", "C000067R", "C000067S", "C000067T",
    "C000067U", "C000067V", "C000067W", "C000067X", "C000067Y",
    "C000067Z", "C000067AA", "C000006A", "C000006B", "C000006C",
    "C000006D", "C000006E", "C000006F", "C000006G", "C000006H",
    "C000006I", "C000006J", "C000006K", "C000006L", "C000007A",
    "C000007B", "C000007C", "C000007D", "C000007E", "C000007F",
    "C000007G", "C000007H", "C000007I", "C000007J", "C000007K",
    "C000007L", "C000007M", "C000007N", "C000007O", "C000007P",
    "C000007Q", "C000007R", "C000007S", "C000007T", "C000007U",
    "C000007V", "C000007W", "C000007X", "C000007Y", "C000007Z",
    "C000007AA", "C000007AB", "C000007AC", "C000007AD", "C000007AE",
    "C000007AF", "C000007AG", "C000007AH", "C000007AI", "C000007AJ",
    "C000007AK", "C000007AL", "C000007AM", "C000007AN", "C000007AO",
    "C000007AP", "C000007AQ", "C000007AR", "C000007AS", "C000007AT",
    "C000068AA", "C000068AB", "C000068AC", "C000068AD", "C000068AE",
    "C000068AF", "C000068AG", "C000068AH", "C000068AI", "C000068AJ",
    "C000068AK", "C000068AL", "C000068AM", "C000068AN", "C000068AO",
    "C000068AP", "C000068AQ", "C000068AR", "C000068AS", "C000068AT",
    "C000068AU", "C000068AV", "C000068AW", "C000068AX", "C000068AY",
    "C000068AZ", "C000068BA", "C000068BB", "C000068BC", "C000068BD",
    "C000068BE", "C000068BF", "C000068BG", "C000068BH", "C000068BI",
    "C000068BJ", "C000068BK", "C000068BL", "C000068BM", "C000068BN",
    "C000068BO", "C000068BP", "C000068BQ", "C000068BR", "C000068BS",
    "C000068BT", "C000068BU", "C000068BV", "C000068BW", "C000068BX",
    "C000068BY", "C000068BZ", "C000068CA", "C000068CB", "C000068CC",
    "C000068CD", "C000068CE", "C000068CF", "C000068CG", "C000068CH",
    "C000068CI", "C000068CJ", "C000068CK", "C000068CL", "C000068CM",
    "C000068CN", "C000068CO", "C000068CP", "C000068CQ", "C000398",
    "C000399", "C000400", "C000401", "C000404", "C000405", "C000402",
    "C000403", "C000417"
]

# Number of seed records to sample when exclude_seeds is enabled
EXCLUDE_SAMPLE_SIZE = 100

# Default output directory
OUTPUT_DIR = "/data"
