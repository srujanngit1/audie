import logging
import os
from logging.handlers import RotatingFileHandler

class LogConfig:
    """
    Configures logging for the application with proper handlers and formatters
    """
    
    def __init__(self, log_file_path):
        """
        Initialize with the path to the log file
        
        Args:
            log_file_path: The path where log files should be stored
        """
        self.log_file_path = log_file_path
        
        # Create directory for log file if it doesn't exist
        log_dir = os.path.dirname(log_file_path)
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

    def generate_logger(self, logger_name):
        """
        Creates and configures a logger with the specified name
        
        Args:
            logger_name: Name for the logger, used to identify it
            
        Returns:
            Configured logger object
        """
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.INFO)
        
        # Clear any existing handlers
        if logger.handlers:
            logger.handlers.clear()
        
        # Create file handler with rotation (10MB max size, keep 10 backup files)
        file_handler = RotatingFileHandler(
            self.log_file_path, 
            maxBytes=10*1024*1024,  # 10MB
            backupCount=10
        )
        file_handler.setLevel(logging.INFO)
        
        # Create console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Add formatter to handlers
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Add handlers to logger
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        
        return logger