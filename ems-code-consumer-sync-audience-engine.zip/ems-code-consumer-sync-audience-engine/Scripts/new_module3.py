from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, lit, count, when, isnan, expr, row_number, concat_ws
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType, IntegerType, StringType
import os
from datetime import datetime
import argparse
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import pandas as pd
import re
from log import LogConfig

pd.DataFrame.iteritems = pd.DataFrame.items

def save_to_csv(df: DataFrame, output_path: str, header: bool = True) -> None:
    """Save DataFrame to CSV format"""
    logger.info(f"Saving CSV to path: {output_path}")
    df.coalesce(1).write.mode("overwrite").option("header", header).csv(output_path)

def save_to_excel(df: DataFrame, output_path: str, sheet_name: str = "Data") -> None:
    """Save DataFrame to Excel format using pandas"""
    row_count = df.count()
    
    if (row_count > 1000000):
        logger.warning(f"Large DataFrame with {row_count} rows, saving only first 1,000,000 rows to Excel")
        pdf = df.limit(1000000).toPandas()
    else:
        pdf = df.toPandas()
    
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    
    if "Comparison" in output_path:
        csv_path = output_path.replace('.xlsx', '.csv')
        logger.info(f"Saving CSV comparison to {csv_path}")
        pdf.to_csv(csv_path, index=False)
    
    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        pdf.to_excel(writer, sheet_name=sheet_name, index=False)
        
    logger.info(f"Excel file saved successfully to {output_path}")

def log_dataframe_info(logger, df: DataFrame, stage_name: str) -> Tuple[int, int]:
    """Log DataFrame information including row count and schema"""
    column_count = len(df.columns)
    
    logger.info(f"Stage: {stage_name}")
    logger.info(f"Column count: {column_count}")
    
    if column_count <= 50:
        logger.info(f"Columns: {', '.join(df.columns)}")
    else:
        first_cols = df.columns[:20]
        last_cols = df.columns[-20:]
        logger.info(f"First 20 columns: {', '.join(first_cols)}")
        logger.info(f"Last 20 columns: {', '.join(last_cols)}")
        logger.info(f"Total columns: {column_count}")
    
    row_count = df.count()
    logger.info(f"Row count: {row_count}")
    
    return row_count, column_count

def read_excel_sheet(spark: SparkSession, file_path: str, sheet_name: str) -> DataFrame:
    """Read a specific sheet from an Excel file, add original order, and convert to Spark DataFrame"""
    logger.info(f"Reading Excel file: {file_path}, sheet: {sheet_name}")
    
    try:
        cache_key = f"{file_path}_{sheet_name}"
        if hasattr(spark, '_cached_dfs') and cache_key in spark._cached_dfs:
            logger.info(f"Using cached DataFrame for {cache_key}")
            return spark._cached_dfs[cache_key]
        
        is_hdfs_path = file_path.startswith("hdfs://") or file_path.startswith("/user/")
        
        if (is_hdfs_path):
            logger.info("HDFS path detected. Will download file locally first.")
            import tempfile
            import subprocess
            import os
            
            temp_dir = tempfile.mkdtemp()
            filename = os.path.basename(file_path)
            local_file_path = os.path.join(temp_dir, filename)
            
            logger.info(f"Downloading file from HDFS to local path: {local_file_path}")
            cmd = ["hdfs", "dfs", "-get", file_path, local_file_path]
            subprocess.check_call(cmd)
            
            csv_path = file_path.replace('.xlsx', '.csv')
            csv_dir = csv_path + "/"
            
            logger.info(f"Reading from local file: {local_file_path}")
            try:
                pandas_df = pd.read_excel(local_file_path, sheet_name=sheet_name)
                logger.info("Successfully read Excel file")
            except Exception as excel_err:
                logger.warning(f"Error reading Excel file: {str(excel_err)}")
                logger.info(f"Checking for CSV backup at: {csv_dir}")
                
                check_cmd = ["hdfs", "dfs", "-test", "-d", csv_dir]
                csv_exists = subprocess.call(check_cmd) == 0
                
                if csv_exists:
                    logger.info("Found CSV backup, using it instead")
                    csv_local_dir = local_file_path.replace('.xlsx', '.csv')
                    os.makedirs(csv_local_dir, exist_ok=True)
                    get_csv_cmd = ["hdfs", "dfs", "-get", f"{csv_dir}/*", csv_local_dir]
                    subprocess.check_call(get_csv_cmd)
                    
                    import glob
                    csv_files = glob.glob(f"{csv_local_dir}/part-*.csv")
                    if csv_files:
                        logger.info(f"Reading from CSV backup: {csv_files[0]}")
                        pandas_df = pd.read_csv(csv_files[0])
                    else:
                        raise Exception("No CSV part files found in backup directory")
                else:
                    raise excel_err
        else:
            logger.info("Reading from local file system")
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Excel file not found: {file_path}")
                
            pandas_df = pd.read_excel(file_path, sheet_name=sheet_name)

        logger.info("Adding '__OriginalOrder' column to preserve initial row order.")
        pandas_df.reset_index(inplace=True)
        pandas_df.rename(columns={'index': '__OriginalOrder'}, inplace=True)

        logger.info("Converting all columns to string type to avoid type conflicts")
        for col_name in pandas_df.columns:
            if col_name != '__OriginalOrder':
                pandas_df[col_name] = pandas_df[col_name].astype(str)
        
        spark_df = spark.createDataFrame(pandas_df)
        
        if not hasattr(spark, '_cached_dfs'):
            spark._cached_dfs = {}
        spark._cached_dfs[cache_key] = spark_df
        
        logger.info(f"Successfully read Excel data from {sheet_name}")
        return spark_df
    
    except Exception as e:
        logger.error(f"Error reading Excel file: {str(e)}")
        raise

def select_columns(df: DataFrame, columns: List[str], logger) -> DataFrame:
    """Select specified columns from DataFrame"""
    logger.info(f"Selecting {len(columns)} columns")
    
    missing_columns = [col for col in columns if col not in df.columns]
    if missing_columns:
        logger.warning(f"These columns don't exist in the DataFrame: {', '.join(missing_columns)}")
        columns = [col for col in columns if col in df.columns]
    
    if len(columns) <= 20:
        logger.info(f"Selecting columns: {', '.join(columns)}")
    else:
        logger.info(f"Selecting {len(columns)} columns including: {', '.join(columns[:10])}... and {len(columns)-10} more")
    
    return df.select(*columns)

def add_blank_percentage(df: DataFrame, logger) -> DataFrame:
    """Create a new column with percentage of blanks based on CountBlank and Count"""
    logger.info("Calculating percentage of blanks")
    return df.withColumn("CountBlank", col("CountBlank").cast(DoubleType())) \
             .withColumn("Count", col("Count").cast(DoubleType())) \
             .withColumn("%_Blanks", (col("CountBlank") / col("Count") * 100).cast(DoubleType()))

def dynamic_rename(df: DataFrame, field_names: List[str], new_name: str, logger) -> DataFrame:
    """Dynamically rename specific fields based on condition"""
    logger.info(f"Dynamically renaming fields: {', '.join(field_names)} to {new_name}")
    select_expressions = [col(c).alias(new_name) if c in field_names else col(c) for c in df.columns]
    return df.select(*select_expressions)

def perform_join(left_df: DataFrame, right_df: DataFrame, left_column: str, right_column: str, logger) -> Tuple[DataFrame, DataFrame, DataFrame]:
    """Perform a join and return inner join (J), left only (L), and right only (R)"""
    logger.info(f"Performing join on left.{left_column} = right.{right_column}")
    from pyspark.sql.functions import broadcast
    
    left_df = left_df.withColumnRenamed("__OriginalOrder", "__CurrentOrder")
    right_df = right_df.withColumnRenamed("__OriginalOrder", "__PreviousOrder")
        
    join_condition = left_df[left_column] == right_df[right_column]
    
    j_output = left_df.join(right_df, join_condition, "inner")
    l_output = left_df.join(right_df, join_condition, "left_anti")
    r_output = right_df.join(left_df, join_condition, "left_anti")
    
    j_rows, l_rows, r_rows = j_output.count(), l_output.count(), r_output.count()
    logger.info(f"Join results - Inner: {j_rows} rows | Left only: {l_rows} rows | Right only: {r_rows} rows")
    
    if right_column in j_output.columns and left_column in j_output.columns and right_column != left_column:
        logger.info(f"Dropping {right_column} column from inner join result")
        j_output = j_output.drop(right_column)
    
    if "__PreviousOrder" in j_output.columns:
        j_output = j_output.drop("__PreviousOrder")
        
    return j_output, l_output, r_output

def add_continuous_record_id(df: DataFrame, start_id: int, order_by_col: str = "Name") -> DataFrame:
    """Add RecordID column with continuous numbering"""
    logger.info(f"Adding continuous RecordID starting from {start_id}, ordering by {order_by_col}")
    
    window_spec = Window.orderBy(order_by_col)
    
    if "RecordID" in df.columns:
        df = df.drop("RecordID")
    
    df_with_id = df.withColumn("RecordID", (row_number().over(window_spec) + start_id - 1).cast(IntegerType()))
    
    all_cols = df_with_id.columns
    all_cols.remove("RecordID")
    reordered_cols = ["RecordID"] + all_cols
    
    return df_with_id.select(*reordered_cols)

# Global logger variable
logger = None

def main():
    global logger
    
    # Parse command line arguments first to get log file path
    parser = argparse.ArgumentParser(description="Process current and previous Excel files for Module 3.")
    parser.add_argument('--current_file', required=True, help='Path to current Excel file')
    parser.add_argument('--previous_file', required=True, help='Path to previous Excel file')
    parser.add_argument('--output_dir', required=True, help='Directory for output files')
    parser.add_argument('--sheet_name', default='Stats', help='Name of the sheet to process (default: Stats)')
    parser.add_argument('--log_file_path', required=False, help='Path to log file')
    
    args = parser.parse_args()
    
    # Set up logging using log.py
    if args.log_file_path:
        log_file_path = args.log_file_path
    else:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        log_dir = os.path.join(current_dir, "logs")
        os.makedirs(log_dir, exist_ok=True)
        log_file_path = os.path.join(log_dir, "new_module3.log")
    
    logger = LogConfig(log_file_path).generate_logger("new_module3")
    
    logger.info("Module 3 - Starting comparison processing")
    logger.info(f"Log file: {log_file_path}")
    logger.info("Command line arguments parsed successfully")
    
    # Initialize Spark session
    spark = SparkSession.builder \
        .appName('Module 3 - Comparison Processing') \
        .getOrCreate()
        
    spark.sparkContext.setLogLevel("WARN")
    logger.info("Spark Session initialized successfully")
    
    max_record_id = 0
    
    try:
        # STEP 1: READ CURRENT EXCEL FILE AND PROCESS DATA
        logger.info("STEP 1: Processing current data")
        current_df = read_excel_sheet(spark, args.current_file, args.sheet_name)
        log_dataframe_info(logger, current_df, "Current Excel data read")

        columns_to_select = ["__OriginalOrder", "Name", "Min_Value", "Max_Value", "CountBlank", "CountNonBlank", "Count", "FileName"]
        current_selected_df = select_columns(current_df, columns_to_select, logger)
        log_dataframe_info(logger, current_selected_df, "Selected columns from current data")

        current_with_id_df = add_continuous_record_id(current_selected_df, 1, "Name")
        max_record_id = current_with_id_df.agg({"RecordID": "max"}).collect()[0][0] or 0
        logger.info(f"Updated max_record_id to {max_record_id} after processing current data")

        current_with_blanks_df = add_blank_percentage(current_with_id_df, logger)
        current_with_blanks_df = current_with_blanks_df.withColumnRenamed("%_Blanks", "Current_%_Blanks")

        current_renamed_df = current_with_blanks_df.select(
            col("RecordID"), col("__OriginalOrder"), col("Name"),
            col("Min_Value").alias("Current_Min_Value"), col("Max_Value").alias("Current_Max_Value"),
            col("CountBlank").alias("Current_CountBlank"), col("CountNonBlank").alias("Current_CountNonBlank"),
            col("Count").alias("Current_Count"), col("Current_%_Blanks")
        )

        current_final_df = dynamic_rename(current_renamed_df, ["Name"], "Current_Name", logger)
        log_dataframe_info(logger, current_final_df, "Current data processing complete")

        # STEP 2: READ PREVIOUS EXCEL FILE AND PROCESS DATA
        logger.info("STEP 2: Processing previous data")
        previous_df = read_excel_sheet(spark, args.previous_file, args.sheet_name)
        log_dataframe_info(logger, previous_df, "Previous Excel data read")

        previous_selected_df = select_columns(previous_df, columns_to_select, logger)
        previous_with_id_df = add_continuous_record_id(previous_selected_df, max_record_id + 1, "Name")
        max_record_id = previous_with_id_df.agg({"RecordID": "max"}).collect()[0][0] or max_record_id
        logger.info(f"Updated max_record_id to {max_record_id} after processing previous data")

        previous_with_blanks_df = add_blank_percentage(previous_with_id_df, logger)
        previous_with_blanks_df = previous_with_blanks_df.withColumnRenamed("%_Blanks", "Previous_%_Blanks")

        previous_renamed_df = previous_with_blanks_df.select(
            col("RecordID"), col("__OriginalOrder"), col("Name"),
            col("Min_Value").alias("Previous_Min_Value"), col("Max_Value").alias("Previous_Max_Value"),
            col("CountBlank").alias("Previous_CountBlank"), col("CountNonBlank").alias("Previous_CountNonBlank"),
            col("Count").alias("Previous_Count"), col("Previous_%_Blanks")
        )
        previous_final_df = dynamic_rename(previous_renamed_df, ["Name"], "Previous_Name", logger)
        log_dataframe_info(logger, previous_final_df, "Previous data processing complete")

        # STEP 3: JOIN CURRENT AND PREVIOUS DATA
        logger.info("STEP 3: Joining current and previous data")
        j_output, l_output, r_output = perform_join(current_final_df, previous_final_df, "Current_Name", "Previous_Name", logger)

        # STEP 4 & 5: PROCESSING L & R OUTPUTS
        logger.info("STEP 4 & 5: Processing Left and Right outputs")
        l_output_with_new_field = l_output.withColumn("New_Field", lit("Y"))
        r_output_with_old_field = r_output.withColumn("Old_Field", lit("Y"))
        r_output_renamed = r_output_with_old_field.withColumnRenamed("Previous_Name", "Current_Name")

        max_id_before_r = (j_output.count() + l_output.count())
        r_output_with_id = add_continuous_record_id(r_output_renamed, max_id_before_r + 1, "Current_Name")

        # STEP 6 & 7: UNION ALL DATA & CREATE SORT KEY
        logger.info("STEP 6 & 7: Unioning all data parts (J, L, R) and preparing for sort")

        j_output = j_output.withColumnRenamed("__CurrentOrder", "__SortOrder")
        l_output_with_new_field = l_output_with_new_field.withColumnRenamed("__CurrentOrder", "__SortOrder")

        if "__PreviousOrder" in r_output_with_id.columns:
            r_output_with_id = r_output_with_id.drop("__PreviousOrder")

        j_columns_lower = [col.lower() for col in j_output.columns]
        duplicate_cols = [col for col in j_columns_lower if j_columns_lower.count(col) > 1]

        if duplicate_cols:
            logger.warning(f"Found duplicate column names (case-insensitive): {', '.join(set(duplicate_cols))}")
            
            for dup_col in set(duplicate_cols):
                matching_cols = [col for col in j_output.columns if col.lower() == dup_col]
                logger.info(f"Columns that match '{dup_col}': {', '.join(matching_cols)}")
                
                # Keep the first occurrence, drop the rest
                for col_to_drop in matching_cols[1:]:
                    logger.info(f"Dropping duplicate column: {col_to_drop}")
                    j_output = j_output.drop(col_to_drop)

        # Do the same for L output
        l_columns_lower = [col.lower() for col in l_output_with_new_field.columns]
        duplicate_cols = [col for col in l_columns_lower if l_columns_lower.count(col) > 1]

        if duplicate_cols:
            logger.warning(f"Found duplicate column names in L output (case-insensitive): {', '.join(set(duplicate_cols))}")
            
            for dup_col in set(duplicate_cols):
                matching_cols = [col for col in l_output_with_new_field.columns if col.lower() == dup_col]
                for col_to_drop in matching_cols[1:]:
                    logger.info(f"Dropping duplicate column from L output: {col_to_drop}")
                    l_output_with_new_field = l_output_with_new_field.drop(col_to_drop)

        r_columns_lower = [col.lower() for col in r_output_with_id.columns]
        duplicate_cols = [col for col in r_columns_lower if r_columns_lower.count(col) > 1]

        if duplicate_cols:
            logger.warning(f"Found duplicate column names in R output (case-insensitive): {', '.join(set(duplicate_cols))}")
            
            for dup_col in set(duplicate_cols):
                matching_cols = [col for col in r_output_with_id.columns if col.lower() == dup_col]
                for col_to_drop in matching_cols[1:]:
                    logger.info(f"Dropping duplicate column from R output: {col_to_drop}")
                    r_output_with_id = r_output_with_id.drop(col_to_drop)

        # Union all three parts together
        logger.info("Performing first union: J and L outputs")
        union_jl_df = j_output.unionByName(l_output_with_new_field, allowMissingColumns=True)

        logger.info("Performing second union: Adding R output")
        final_union_df = union_jl_df.unionByName(r_output_with_id, allowMissingColumns=True)

        log_dataframe_info(logger, final_union_df, "Final union of J, L, and R complete")

        # STEP 8: CALCULATE CHANGE METRICS
        logger.info("STEP 8: Calculating change metrics")
        final_union_df = final_union_df.withColumn("Previous_Count", col("Previous_Count").cast(DoubleType())) \
                                       .withColumn("Current_Count", col("Current_Count").cast(DoubleType())) \
                                       .withColumn("Previous_%_Blanks", col("Previous_%_Blanks").cast(DoubleType())) \
                                       .withColumn("Current_%_Blanks", col("Current_%_Blanks").cast(DoubleType()))

        final_union_df = final_union_df.withColumn(
            "% Blanks Change",
            when(col("Previous_%_Blanks") == 0, 0)
            .otherwise(((col("Current_%_Blanks") / col("Previous_%_Blanks")) - 1) * 100)
        )
        final_union_df = final_union_df.withColumn(
            "% Blanks Change",
            when(col("% Blanks Change").isNull(),
                 when(col("Current_%_Blanks") == 0, 0).otherwise(1)
            ).otherwise(col("% Blanks Change"))
        )
        final_union_df = final_union_df.withColumn(
            "Total Change",
            when(col("Previous_Count").isNull() | (col("Previous_Count") == 0), lit(None))
            .otherwise(((col("Current_Count") / col("Previous_Count")) - 1) * 100)
        )

        # STEP 9 & 10: FINAL PREPARATION AND SORTING
        logger.info("STEP 9 & 10: Final data preparation and sorting")
        required_column_order = [
            "RecordID", "Current_Name", "Current_Min_Value", "Current_Max_Value",
            "Current_CountBlank", "Current_CountNonBlank", "Current_Count", "Current_%_Blanks",
            "Previous_Min_Value", "Previous_Max_Value", "Previous_CountBlank", "Previous_CountNonBlank",
            "Previous_Count", "Previous_%_Blanks", "New_Field", "Old_Field", "% Blanks Change", "Total Change"
        ]

        for column in required_column_order:
            if column not in final_union_df.columns:
                logger.warning(f"Required column {column} is missing. Adding with null values.")
                final_union_df = final_union_df.withColumn(column, lit(None).cast(StringType()))

        logger.info("Sorting final DataFrame based on original file order.")
        final_union_df_sorted = final_union_df.orderBy(col("__SortOrder").asc_nulls_last())

        final_output_df_presort = final_union_df_sorted.select(*required_column_order)
        final_output_df = final_output_df_presort.withColumn("RecordID", row_number().over(Window.orderBy(lit(1))))

        log_dataframe_info(logger, final_output_df, "Final DataFrame sorted and ready for saving")

        # STEP 11: SAVE FINAL OUTPUT
        logger.info("STEP 11: Saving final output")
        current_date_str = datetime.now().strftime("%Y-%m-%d")
        output_dir = args.output_dir
        base_filename = f"Audience_Engine_Supply_Internal_minmax_{current_date_str}_Comparison"
        excel_output_path = os.path.join(output_dir, f"{base_filename}.xlsx")
        csv_output_path = os.path.join(output_dir, f"{base_filename}_csv")

        logger.info(f"Excel output path: {excel_output_path}")
        logger.info(f"CSV output path: {csv_output_path}")

        if excel_output_path.startswith("hdfs://") or excel_output_path.startswith("/user/"):
            import subprocess
            import tempfile
            
            logger.info("Saving to HDFS path. Writing locally first, then uploading.")
            temp_dir = tempfile.mkdtemp()
            local_excel_path = os.path.join(temp_dir, f"{base_filename}.xlsx")
            pandas_df = final_output_df.toPandas()
            
            logger.info(f"Saving Excel locally to: {local_excel_path}")
            with pd.ExcelWriter(local_excel_path, engine='openpyxl') as writer:
                pandas_df.to_excel(writer, sheet_name=args.sheet_name, index=False)
            
            try:
                subprocess.check_call(["hdfs", "dfs", "-mkdir", "-p", output_dir])
                subprocess.check_call(["hdfs", "dfs", "-put", "-f", local_excel_path, excel_output_path])
                logger.info("Excel file uploaded to HDFS successfully")
            except Exception as e:
                logger.error(f"Error uploading Excel file to HDFS: {str(e)}")
            
            logger.info(f"Saving CSV directly to HDFS: {csv_output_path}")
            save_to_csv(final_output_df, csv_output_path)
        else:
            logger.info("Saving to local filesystem.")
            os.makedirs(output_dir, exist_ok=True)
            
            pandas_df = final_output_df.toPandas()
            logger.info(f"Saving Excel file to: {excel_output_path}")
            with pd.ExcelWriter(excel_output_path, engine='openpyxl') as writer:
                pandas_df.to_excel(writer, sheet_name=args.sheet_name, index=False)
            
            # Also save a single CSV file locally
            local_csv_path = os.path.join(output_dir, f"{base_filename}.csv")
            logger.info(f"Saving CSV file to: {local_csv_path}")
            pandas_df.to_csv(local_csv_path, index=False)

        logger.info("Module 3 processing completed successfully")
        
    except Exception as e:
        logger.error(f"Error in Module 3 processing: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise
    finally:
        logger.info("Stopping Spark session")
        spark.stop()

if __name__ == "__main__":
    main()