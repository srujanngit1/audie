from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.window import Window
from pyspark.sql.functions import (
    row_number, monotonically_increasing_id, lit, regexp_extract, length, col,
    rand, round, coalesce, when, isnan, upper, sum as sum_func, trim
)
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, LongType
)
from datetime import datetime
import time
import pandas as pd
import numpy as np
import os
import re
import json
from config import C_VARIABLES_COLUMNS, PROFILE_COLUMNS, TODAY_DATE, EXCLUDE_SAMPLE_SIZE
from functions import file_config, escape_xml_metacharacters
from log import LogConfig
import argparse
import sys



spark = None


def logic_stats(logger, stats_df, include_empty_cells, input_format_fixed, filepath):
    """
    Generate stats preserving exact input column order (excluding Original_Row_Number)
    """
    try:
        import re
        from pyspark.sql.functions import upper, row_number, lit, length, col, when
        from pyspark.sql.window import Window
        from pyspark.sql.types import StructType, StructField, StringType, IntegerType

        def sanitize_view_name(column_name):
            """Create valid SQL view name from column name"""
            sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', column_name)
            if sanitized and not sanitized[0].isalpha():
                sanitized = 'v_' + sanitized
            return sanitized

        logger.info("MinMax File Process - Starting stats process with preserved column order")

        row_count = stats_df.count()
        logger.info(f"Processing stats for {row_count} rows")

        cols_to_drop = [c for c in ["Minmax_RecordID", "batch", "Original_Row_Number"]
                         if c in stats_df.columns]
        if cols_to_drop:
            stats_df_clean = stats_df.drop(*cols_to_drop)
            logger.info(f"Dropped columns for stats: {cols_to_drop}")
        else:
            stats_df_clean = stats_df

        input_column_order = stats_df_clean.columns
        logger.info(f"Input column order preserved: {input_column_order[:5]}... (showing first 5)")

        logger.info("Extracting column configuration information")
        stats_config_df = file_config(spark, stats_df_clean, filepath)

        if not input_format_fixed:
            logger.info("CSV format detected - using simple sequential positions")
        else:
            logger.info("Fixed format detected - calculating byte positions")
            from pyspark.sql.functions import sum as sum_func
            window_spec_order = Window.partitionBy(lit(1)).orderBy("Position")
            window_spec_running = Window.orderBy("Position").rowsBetween(
                Window.unboundedPreceding, Window.currentRow)

            stats_config_df = stats_config_df.withColumn(
                "running_size",
                sum_func(when(col("Size").cast("int").isNotNull(), col("Size").cast("int")).otherwise(0))
                .over(window_spec_running)
            ).withColumn(
                "Position",
                when(col("Position") == 1, 1)
                .otherwise(col("running_size") - col("Size").cast("int") + 1)
            ).drop("running_size")

        stats_config_df = stats_config_df.withColumn("Name", upper(col("Name")))
        stats_config_df = escape_xml_metacharacters(stats_config_df, "Name")

        valid_columns = input_column_order
        logger.info(f"Processing {len(valid_columns)} columns in original order")

        stats_df_clean.createOrReplaceTempView("stats_temp")

        logger.info("Computing all column metrics using optimized SQL approach")

        combined_results = []
        batch_size = 50

        all_metrics = {}
        for i in range(0, len(valid_columns), batch_size):
            batch_columns = valid_columns[i:i+batch_size]
            if not batch_columns:
                continue

            logger.info(f"Processing metrics batch {i//batch_size + 1} for {len(batch_columns)} columns")

            all_metrics_exprs = []
            for col_name in batch_columns:
                escaped_name = col_name.replace("`", "``")
                all_metrics_exprs.extend([
                    f"SUM(CASE WHEN `{escaped_name}` IS NULL THEN 1 ELSE 0 END) as `{escaped_name}_null`",
                    f"SUM(CASE WHEN `{escaped_name}` = '' THEN 1 ELSE 0 END) as `{escaped_name}_empty`",
                    f"MIN(CASE WHEN `{escaped_name}` IS NOT NULL AND `{escaped_name}` != '' THEN LENGTH(CAST(`{escaped_name}` AS STRING)) ELSE NULL END) as `{escaped_name}_min_len`",
                    f"MAX(LENGTH(CAST(`{escaped_name}` AS STRING))) as `{escaped_name}_max_len`"
                ])

            batch_sql = f"SELECT {', '.join(all_metrics_exprs)} FROM stats_temp"
            batch_result = spark.sql(batch_sql).collect()[0]

            for field_name in batch_result.__fields__:
                all_metrics[field_name] = batch_result[field_name]

        for column_name in valid_columns:
            null_count = all_metrics.get(f"{column_name}_null", 0) or 0
            empty_count = all_metrics.get(f"{column_name}_empty", 0) or 0
            total_blank_count = null_count + empty_count
            min_len = all_metrics.get(f"{column_name}_min_len", 0) or 0
            max_len = all_metrics.get(f"{column_name}_max_len", 0) or 0

            sample_sql = f"""
            SELECT `{column_name}` FROM stats_temp
            WHERE `{column_name}` IS NOT NULL AND `{column_name}` != ''
            LIMIT 5
            """
            sample_values = [row[0] for row in spark.sql(sample_sql).collect()]

            numeric_indicators = ["id", "key", "count", "num", "total", "amount", "price", "cost", "qty", "quantity"]
            name_indicates_numeric = any(indicator in column_name.lower() for indicator in numeric_indicators)

            treat_as_numeric = False
            if sample_values:
                numeric_pattern = r'^-?\d+(\.\d+)?$'
                if "code" in column_name.lower():
                    has_numeric = any(re.match(numeric_pattern, str(val).strip()) for val in sample_values if val is not None)
                    treat_as_numeric = has_numeric
                elif name_indicates_numeric or all(
                    re.match(r'^-?\d+(\.\d+)?([eE][+-]?\d+)?$', str(val).strip())
                    for val in sample_values if val is not None
                ):
                    treat_as_numeric = True

            sanitized_view_name = sanitize_view_name(column_name)
            stats_df_clean.select(column_name).createOrReplaceTempView(f"col_{sanitized_view_name}")

            min_value = ""
            max_value = ""

            if treat_as_numeric:
                min_max_sql = f"""
                SELECT
                    {f"MIN(CASE WHEN `{column_name}` IS NOT NULL AND `{column_name}` != '' THEN CAST(`{column_name}` AS DOUBLE) ELSE NULL END)" if include_empty_cells else f"MIN(CAST(`{column_name}` AS DOUBLE))"} as min_val,
                    MAX(CAST(`{column_name}` AS DOUBLE)) as max_val
                FROM col_{sanitized_view_name}
                WHERE CAST(`{column_name}` AS DOUBLE) IS NOT NULL AND NOT isnan(CAST(`{column_name}` AS DOUBLE))
                """
                try:
                    min_max_result = spark.sql(min_max_sql).collect()
                    if min_max_result and len(min_max_result) > 0:
                        min_numeric = min_max_result[0].min_val
                        max_numeric = min_max_result[0].max_val

                        if min_numeric is not None:
                            min_sql = f"SELECT `{column_name}` FROM col_{sanitized_view_name} WHERE CAST(`{column_name}` AS DOUBLE) = {min_numeric} LIMIT 1"
                            min_result = spark.sql(min_sql).collect()
                            min_value = str(min_result[0][0]) if min_result else ""

                        if max_numeric is not None:
                            max_sql = f"SELECT `{column_name}` FROM col_{sanitized_view_name} WHERE CAST(`{column_name}` AS DOUBLE) = {max_numeric} LIMIT 1"
                            max_result = spark.sql(max_sql).collect()
                            max_value = str(max_result[0][0]) if max_result else ""
                except:
                    treat_as_numeric = False

            if not treat_as_numeric:
                if include_empty_cells:
                    min_max_sql = f"""
                    SELECT
                        MIN(CASE WHEN `{column_name}` IS NOT NULL AND `{column_name}` != ''
                            THEN `{column_name}` ELSE NULL END) as min_val,
                        MAX(`{column_name}`) as max_val
                    FROM col_{sanitized_view_name}
                    """
                else:
                    min_max_sql = f"SELECT MIN(`{column_name}`) as min_val, MAX(`{column_name}`) as max_val FROM col_{sanitized_view_name}"

                min_max_result = spark.sql(min_max_sql).collect()
                if min_max_result and len(min_max_result) > 0:
                    min_value = str(min_max_result[0].min_val) if min_max_result[0].min_val is not None else ""
                    max_value = str(min_max_result[0].max_val) if min_max_result[0].max_val is not None else ""

            shortest_value = ""
            longest_value = ""

            if min_len > 0:
                shortest_sql = f"""
                SELECT `{column_name}` FROM col_{sanitized_view_name}
                WHERE LENGTH(CAST(`{column_name}` AS STRING)) = {min_len}
                AND `{column_name}` IS NOT NULL AND `{column_name}` != ''
                LIMIT 1
                """
                shortest_result = spark.sql(shortest_sql).collect()
                shortest_value = str(shortest_result[0][0]) if shortest_result else ""

            if max_len > 0:
                longest_sql = f"""
                SELECT `{column_name}` FROM col_{sanitized_view_name}
                WHERE LENGTH(CAST(`{column_name}` AS STRING)) = {max_len}
                AND `{column_name}` IS NOT NULL
                LIMIT 1
                """
                longest_result = spark.sql(longest_sql).collect()
                longest_value = str(longest_result[0][0]) if longest_result else ""

            combined_results.append({
                "Name": column_name,
                "Min_Value": min_value,
                "Max_Value": max_value,
                "CountBlank": int(total_blank_count),
                "CountNonBlank": int(row_count - total_blank_count),
                "Count": int(row_count),
                "Type": "V_String",
                "Position": valid_columns.index(column_name) + 1,
                "Shortest": shortest_value,
                "Shortest_Length": int(min_len),
                "Longest": longest_value,
                "Longest_Length": int(max_len)
            })

            spark.catalog.dropTempView(f"col_{sanitized_view_name}")

        spark.catalog.dropTempView("stats_temp")

        schema = StructType([
            StructField("Name", StringType(), True),
            StructField("Min_Value", StringType(), True),
            StructField("Max_Value", StringType(), True),
            StructField("CountBlank", IntegerType(), True),
            StructField("CountNonBlank", IntegerType(), True),
            StructField("Count", IntegerType(), True),
            StructField("Type", StringType(), True),
            StructField("Position", IntegerType(), True),
            StructField("Shortest", StringType(), True),
            StructField("Shortest_Length", IntegerType(), True),
            StructField("Longest", StringType(), True),
            StructField("Longest_Length", IntegerType(), True)
        ])

        stats_results_df = spark.createDataFrame(combined_results, schema)

        stats_results_df = stats_results_df.orderBy("Position").select(
            "Name", "Min_Value", "Max_Value", "CountBlank", "CountNonBlank", "Count",
            "Type", "Position", "Shortest", "Shortest_Length", "Longest", "Longest_Length"
        )

        logger.info("MinMax File Process - Stats output process completed successfully with preserved column order")
        return stats_results_df

    except Exception as e:
        logger.error(f"Stats process failed: {str(e)}")
        return None

#########################################################################################################
# OPTIMIZED SAMPLES LOGIC - PRESERVES ROWNUMBER FROM MODULE1                                           #
#########################################################################################################
def logic_samples(logger, current_batch_df, num_sample_records):
    """
    Generate random sample records preserving RowNumber from module1 output.
    Optimized for 50M+ row datasets.
    """
    try:
        logger.info("MinMax File Process - Starting optimized samples output process")

        if "Original_Row_Number" not in current_batch_df.columns:
            logger.error("FATAL: Original_Row_Number column NOT FOUND in input for logic_samples. This column is expected from Module 1.")
            raise ValueError("Original_Row_Number column is missing, cannot proceed with sampling as required.")

        row_count = current_batch_df.count()
        logger.info(f"Generating samples from {row_count} records for batch.")

        if row_count == 0 or num_sample_records == 0:
            logger.info("No records or zero samples requested, returning empty samples DataFrame.")
            sample_columns = ["Original_Row_Number"] + [c for c in current_batch_df.columns if c not in ["Original_Row_Number", "Minmax_RecordID", "batch"]]
            empty_schema = StructType([StructField(c, StringType(), True) for c in sample_columns])
            if "Original_Row_Number" in sample_columns:
                 empty_schema["Original_Row_Number"].dataType = LongType()
            return spark.createDataFrame([], schema=empty_schema)

        cols_to_keep = ["Original_Row_Number"] + [c for c in current_batch_df.columns if c not in ["Original_Row_Number", "Minmax_RecordID", "batch"]]
        df_for_sampling = current_batch_df.select(*cols_to_keep)

        samples_df = None
        if num_sample_records >= row_count:
            logger.info(f"Number of requested samples ({num_sample_records}) is >= total rows ({row_count}). Taking all records.")
            samples_df = df_for_sampling
        elif row_count > 1000000 and num_sample_records < row_count * 0.1:
            sample_fraction = min(1.0, (num_sample_records * 2.0) / row_count)
            logger.info(f"Large dataset ({row_count} rows) detected. Using two-stage sampling with initial fraction: {sample_fraction:.6f}")
            intermediate_samples = df_for_sampling.sample(withReplacement=False, fraction=sample_fraction, seed=42)
            samples_df = intermediate_samples.orderBy(rand(seed=123)).limit(num_sample_records)
        else:
            logger.info(f"Using direct orderBy(rand()).limit() sampling for {row_count} rows.")
            samples_df = df_for_sampling.orderBy(rand(seed=42)).limit(num_sample_records)

        final_cols = ["Original_Row_Number"] + [c for c in samples_df.columns if c != "Original_Row_Number"]
        samples_df = samples_df.select(*final_cols)

        final_sample_count = samples_df.count()
        logger.info(f"Generated {final_sample_count} sample records with preserved RowNumber.")
        if final_sample_count < num_sample_records and row_count >= num_sample_records :
             logger.warning(f"Requested {num_sample_records} samples, but only {final_sample_count} were generated. This might happen with skewed data or very small sampling fractions.")

        return samples_df

    except Exception as e:
        logger.error(f"MinMax File Process - Samples process failed: {str(e)}", exc_info=True)
        raise

#########################################################################################################
# OPTIMIZED EXCLUDE SEED SAMPLES LOGIC - PRESERVES ROWNUMBER                                           #
#########################################################################################################
def logic_exclude_seed_samples(logger, seed_records_df):
    """
    Process excluded seed records preserving RowNumber from module1.
    Optimized for large datasets.
    """
    try:
        logger.info("MinMax File Process - Starting Exclude Seed Samples process")

        if seed_records_df is None:
            logger.warning("No seed records DataFrame provided.")
            return None

        if "Original_Row_Number" not in seed_records_df.columns:
            logger.error("FATAL: Original_Row_Number column NOT FOUND in input for logic_exclude_seed_samples.")
            raise ValueError("Original_Row_Number column is missing from seed_records_df.")

        row_count = seed_records_df.count()
        if row_count == 0:
            logger.warning("No seed records to process (empty DataFrame).")
            sample_columns = ["Original_Row_Number"] + [c for c in seed_records_df.columns if c not in ["Original_Row_Number", "Minmax_RecordID", "batch"]]
            empty_schema = StructType([StructField(c, StringType(), True) for c in sample_columns])
            if "Original_Row_Number" in sample_columns:
                 empty_schema["Original_Row_Number"].dataType = LongType()
            return spark.createDataFrame([], schema=empty_schema)

        logger.info(f"Processing {row_count} seed records.")

        cols_to_keep = ["Original_Row_Number"] + [c for c in seed_records_df.columns if c not in ["Original_Row_Number", "Minmax_RecordID", "batch"]]
        processed_df = seed_records_df.select(*cols_to_keep)

        if row_count > EXCLUDE_SAMPLE_SIZE:
            logger.info(f"Number of seed records ({row_count}) exceeds EXCLUDE_SAMPLE_SIZE ({EXCLUDE_SAMPLE_SIZE}). Sampling down.")
            processed_df = processed_df.orderBy(rand(seed=43)).limit(EXCLUDE_SAMPLE_SIZE)
            logger.info(f"Sampled down to {processed_df.count()} seed records.")

        processed_df = processed_df.orderBy("Original_Row_Number")

        final_cols = ["Original_Row_Number"] + [c for c in processed_df.columns if c != "Original_Row_Number"]
        processed_df = processed_df.select(*final_cols)

        final_seed_sample_count = processed_df.count()
        logger.info(f"Prepared {final_seed_sample_count} seed records for output with preserved RowNumber.")
        return processed_df

    except Exception as e:
        logger.error(f"MinMax File Process - Exclude Seed Samples process failed: {str(e)}", exc_info=True)
        raise

#########################################################################################################
# FREQUENCY STATS ON BATCH (Helper for logic_frequency_reports)                                        #
#########################################################################################################
def logic_frequency_Stats_on_batch(logger, current_batch_minmax_ids_df, df_raw_full, batch_field_name):
    """
    Generate frequency statistics for the batch_field_name itself.
    Uses Minmax_RecordID from current_batch_minmax_ids_df to filter df_raw_full.
    """
    try:
        logger.info(f"MinMax File Process - Starting frequency stats on actual batch field: {batch_field_name}")

        if "Minmax_RecordID" not in current_batch_minmax_ids_df.columns:
            logger.error("Minmax_RecordID missing from current_batch_minmax_ids_df for batch stats.")
            return None
        if batch_field_name not in df_raw_full.columns:
            logger.error(f"Batch field '{batch_field_name}' not found in df_raw_full for batch stats.")
            return None

        current_batch_minmax_ids_df.select("Minmax_RecordID").distinct().createOrReplaceTempView("current_batch_records_view")
        df_raw_full.createOrReplaceTempView("df_raw_full_view")
        logger.info("Created temporary views for batch field frequency calculation.")

        escaped_batch_field = f"`{batch_field_name}`"

        batch_freq_sql = f"""
        SELECT
            'Batch' as Name,  -- Standardized Name for this type of frequency
            CAST(r.{escaped_batch_field} AS STRING) as Value,
            COUNT(*) as Count,
            '' as KeyCodeCounter -- Placeholder, can be populated if ranking is needed
        FROM df_raw_full_view r
        JOIN current_batch_records_view cbr ON r.Minmax_RecordID = cbr.Minmax_RecordID
        WHERE r.{escaped_batch_field} IS NOT NULL AND TRIM(CAST(r.{escaped_batch_field} AS STRING)) != ''
        GROUP BY r.{escaped_batch_field}
        ORDER BY Count DESC
        """

        batch_freq_result_df = spark.sql(batch_freq_sql)

        try:
            spark.sql("DROP VIEW IF EXISTS current_batch_records_view")
        except:
            logger.info("View current_batch_records_view might not exist, continuing...")
        try:
            spark.sql("DROP VIEW IF EXISTS df_raw_full_view")
        except:
            logger.info("View df_raw_full_view might not exist, continuing...")

        logger.info("Dropped temporary views for batch field frequency.")

        count_result = batch_freq_result_df.count()
        logger.info(f"Found {count_result} distinct batch values for the batch field '{batch_field_name}'.")
        return batch_freq_result_df

    except Exception as e:
        logger.error(f"MinMax File Process - Frequency stats on batch field failed: {str(e)}", exc_info=True)
        try:
            spark.sql("DROP VIEW IF EXISTS current_batch_records_view")
        except:
            pass
        try:
            spark.sql("DROP VIEW IF EXISTS df_raw_full_view")
        except:
            pass
        return None

def logic_frequency_reports(logger, current_batch_df, frequency_c_fields, num_records_show, df_raw_for_batch_stats=None, batch_field=None):
    """
    Memory-optimized frequency analysis for large column counts
    Fixed to preserve PROFILE_COLUMNS first, then C_VARIABLES_COLUMNS order
    """
    try:
        logger.info("MinMax File Process - Starting OPTIMIZED frequency reports")

        row_count_batch = current_batch_df.count()
        logger.info(f"Processing frequency reports for {row_count_batch} rows")

        if row_count_batch == 0:
            logger.warning("Empty batch for frequency reports")
            return None

        df_columns_in_batch = current_batch_df.columns

        if frequency_c_fields:
            all_columns_to_analyze = [c for c in frequency_c_fields if c in df_columns_in_batch]
        else:
            all_columns_to_analyze = []

            for column in PROFILE_COLUMNS:
                if column in df_columns_in_batch and column not in all_columns_to_analyze:
                    all_columns_to_analyze.append(column)

            for column in C_VARIABLES_COLUMNS:
                if column in df_columns_in_batch and column not in all_columns_to_analyze:
                    all_columns_to_analyze.append(column)

        cols_to_exclude_freq = ["Original_Row_Number", "Minmax_RecordID", "batch"]
        if batch_field:
            cols_to_exclude_freq.append(batch_field)

        all_columns_to_analyze = [c for c in all_columns_to_analyze if c not in cols_to_exclude_freq]

        logger.info(f"Analyzing {len(all_columns_to_analyze)} columns for frequency reports")
        logger.info(f"Column order: P-columns first: {[c for c in all_columns_to_analyze if c in PROFILE_COLUMNS][:3]}...")
        logger.info(f"Then C-columns: {[c for c in all_columns_to_analyze if c.startswith('C')][:3]}...")

        if not all_columns_to_analyze:
            logger.warning("No columns to analyze for frequency reports")
            return None

        column_order_map = {col_name: idx for idx, col_name in enumerate(all_columns_to_analyze)}

        all_frequency_results = []

        # if batch_field and df_raw_for_batch_stats is not None:
        #     batch_entries = logic_frequency_Stats_on_batch(logger, current_batch_df, df_raw_for_batch_stats, batch_field)
        #     if batch_entries is not None and batch_entries.count() > 0:
        #         all_frequency_results.append(batch_entries)
        #         logger.info(f"Batch entries added to frequency results, total records: {len(all_frequency_results)}")

        view_name = f"freq_simple_view_{int(time.time())}"
        current_batch_df.createOrReplaceTempView(view_name)
        logger.info(f"Created temp view: {view_name}")

        for i, col_name in enumerate(all_columns_to_analyze):
            if i % 10 == 0:
                logger.info(f"Processing frequency column {i+1}/{len(all_columns_to_analyze)}: {col_name}")

            try:
                safe_column = col_name.replace("`", "``")

                frequency_sql = f"""
                SELECT
                    CASE
                        WHEN `{safe_column}` IS NULL THEN ''
                        WHEN TRIM(CAST(`{safe_column}` AS STRING)) = '' THEN '<BLANK>'
                        ELSE CAST(`{safe_column}` AS STRING)
                    END AS Value,
                    COUNT(*) AS Count
                FROM {view_name}
                GROUP BY
                    CASE
                        WHEN `{safe_column}` IS NULL THEN ''
                        WHEN TRIM(CAST(`{safe_column}` AS STRING)) = '' THEN '<BLANK>'
                        ELSE CAST(`{safe_column}` AS STRING)
                    END
                ORDER BY Count DESC, Value ASC
                LIMIT {num_records_show}
                """

                column_results = spark.sql(frequency_sql).collect()

                for rank, record in enumerate(column_results, 1):
                    all_frequency_results.append({
                        "Name": col_name,
                        "Value": record.Value,
                        "Count": record.Count,
                        "KeyCodeCounter": str(rank),
                        "ColumnOrder": column_order_map[col_name]
                    })

                if i % 20 == 0:
                    spark.catalog.clearCache()

            except Exception as col_error:
                logger.warning(f"Error processing column {col_name}: {str(col_error)}")
                continue

        spark.catalog.dropTempView(view_name)
        logger.info(f"Processed {len(all_columns_to_analyze)} columns, generated {len(all_frequency_results)} frequency records")

        if not all_frequency_results:
            logger.warning("No frequency data generated")
            return None

        from pyspark.sql.types import StructType, StructField, StringType, LongType, IntegerType
        schema = StructType([
            StructField("Name", StringType(), True),
            StructField("Value", StringType(), True),
            StructField("Count", LongType(), True),
            StructField("KeyCodeCounter", StringType(), True),
            StructField("ColumnOrder", IntegerType(), True)
        ])

        final_frequencies_df = spark.createDataFrame(all_frequency_results, schema)

        final_frequencies_df = final_frequencies_df.orderBy("ColumnOrder", col("Count").desc(), "Value")

        final_frequencies_df = final_frequencies_df.drop("ColumnOrder")

        logger.info(f"Optimized frequency reports completed successfully with PRESERVED ORDER. Total records: {len(all_frequency_results)}")
        return final_frequencies_df

    except Exception as e:
        logger.error(f"Optimized frequency reports failed: {str(e)}")
        try:
            spark.catalog.dropTempView(view_name)
        except:
            pass
        spark.catalog.clearCache()
        raise

#########################################################################################################
# OPTIMIZED MAIN LOGIC FOR 50M+ ROWS                                                                   #
#########################################################################################################
def logic_main(logger, file_path, output_dir, num_sample_records, run_exclude_seeds, exclude_field, exclude_value,
               include_empty_cells, input_format_fixed, batch_processing_enabled, batch_field_name, run_frequency_reports=False,
               frequency_c_fields=None, num_records_show_freq=10, separate_reports_by_batch=False):
    """
    Main processing logic optimized for 50M+ row datasets.
    """
    success_flags = []
    starttime = datetime.now()

    filename_only = os.path.basename(file_path)
    logger.info(f"Running MinMax process for file: {filename_only}")

    df_raw = None

    try:
        logger.info(f"Reading input CSV file(s) from: {file_path}")
        df_raw = spark.read.option("header", "true") \
            .option("inferSchema", "false") \
            .option("sep", ",") \
            .option("mode", "PERMISSIVE") \
            .option("multiLine", "false") \
            .csv(file_path)

        if "Original_Row_Number" in df_raw.columns:
            logger.info("Casting Original_Row_Number column to LongType.")
            df_raw = df_raw.withColumn("Original_Row_Number", col("Original_Row_Number").cast(LongType()))
        else:
            logger.error("CRITICAL: Original_Row_Number column expected from Module 1 output is MISSING.")
            raise ValueError("Original_Row_Number column is missing from the input file. This is required.")

        num_cols = len(df_raw.columns)
        logger.info(f"Input file loaded with {num_cols} columns. Schema: {df_raw.printSchema()}")

        df_raw = df_raw.withColumn("Minmax_RecordID", monotonically_increasing_id())
        logger.info("Added Minmax_RecordID.")

        df_raw.persist()
        num_rows = df_raw.count()
        logger.info(f"Input file contains {num_rows} rows. df_raw is persisted.")

        if num_rows == 0:
            logger.warning("Input file is empty. No processing will occur.")
            success_flags.append(True)
            return

        if batch_processing_enabled and batch_field_name and batch_field_name in df_raw.columns:
            logger.info(f"Batch processing enabled. Using field '{batch_field_name}' to define batches.")
            df_raw = df_raw.withColumn("batch", col(batch_field_name))
        else:
            logger.info("Batch processing not enabled or batch field invalid. Processing as a single batch.")
            df_raw = df_raw.withColumn("batch", lit("DEFAULT_BATCH_VALUE"))
            batch_field_name = "batch"
            separate_reports_by_batch = False

        if batch_processing_enabled:
            distinct_batch_values_df = df_raw.select("batch").distinct()
            batch_count = distinct_batch_values_df.count()
            logger.info(f"Found {batch_count} unique batch values in '{batch_field_name}'.")

            if batch_count == 0:
                logger.warning("No distinct batch values found, though batching was enabled. Processing as single batch.")
                batch_values_to_process = [("DEFAULT_BATCH_VALUE", df_raw.filter(lit(True)))]
                _process_batches_iteratively(
                    logger, batch_values_to_process, separate_reports_by_batch, df_raw,
                    run_exclude_seeds, exclude_field, exclude_value,
                    include_empty_cells, input_format_fixed, file_path, num_sample_records,
                    run_frequency_reports, frequency_c_fields, num_records_show_freq,
                    batch_field_name,
                    output_dir
                )
            else:
                batch_values_list = [row.batch for row in distinct_batch_values_df.orderBy("batch").collect()]
                _process_batches_iteratively(
                    logger, batch_values_list, separate_reports_by_batch, df_raw,
                    run_exclude_seeds, exclude_field, exclude_value,
                    include_empty_cells, input_format_fixed, file_path, num_sample_records,
                    run_frequency_reports, frequency_c_fields, num_records_show_freq,
                    batch_field_name,
                    output_dir
                )
        else:
            logger.info("Processing entire dataset as a single batch.")
            single_batch_data = [("DEFAULT_BATCH_VALUE", df_raw.filter(lit(True)))]
            _process_batches_iteratively(
                logger, single_batch_data, False, df_raw,
                run_exclude_seeds, exclude_field, exclude_value,
                include_empty_cells, input_format_fixed, file_path, num_sample_records,
                run_frequency_reports, frequency_c_fields, num_records_show_freq,
                batch_field_name,
                output_dir
            )

        success_flags.append(True)

    except Exception as e:
        logger.error(f"MinMax File Process - Main logic error: {str(e)}", exc_info=True)
        success_flags.append(False)
        raise
    finally:
        if df_raw is not None and df_raw.is_cached:
            df_raw.unpersist()
            logger.info("Unpersisted df_raw.")
        spark.catalog.clearCache()
        endtime = datetime.now()
        execution_time = str(endtime - starttime).split('.')[0]
        if all(success_flags):
            logger.info(f"MinMax File Process - Process completed successfully in {execution_time}")
        else:
            logger.error(f"MinMax File Process - Process failed or had errors, stopped in {execution_time}")


#########################################################################################################
# HELPER FOR BATCH PROCESSING (ITERATIVE APPROACH)                                                      #
#########################################################################################################
def _process_batches_iteratively(logger, batch_values_or_data_list, separate_reports, full_df_raw,
                                run_exclude_seeds, exclude_field, exclude_value,
                                include_empty_cells, input_format_fixed, file_path_for_stats_config, num_sample_records,
                                run_frequency_reports, frequency_c_fields, num_records_show_freq,
                                original_batch_field_name_for_freq,
                                output_dir):
    """
    Helper to process data, either as one consolidated report or separate reports per batch.
    """
    logger.info(f"Starting iterative batch processing. Separate reports: {separate_reports}.")

    if not separate_reports:
        logger.info("=================================================================")
        logger.info("CREATING A SINGLE CONSOLIDATED REPORT FOR ALL DATA")
        logger.info("=================================================================")

        current_data_to_process = full_df_raw
        non_seed_records_df = current_data_to_process
        seed_records_df = None

        if run_exclude_seeds and exclude_field and exclude_value and exclude_field in current_data_to_process.columns:
            logger.info(f"CONSOLIDATED: Applying seed exclusion: field='{exclude_field}', value='{exclude_value}'")
            if '*' in exclude_value:
                regex_pattern = '^' + exclude_value.replace('*', '.*') + '$'
                seed_filter_cond = col(exclude_field).rlike(regex_pattern)
            else:
                seed_filter_cond = (col(exclude_field) == exclude_value)

            seed_records_df = current_data_to_process.filter(seed_filter_cond)
            non_seed_records_df = current_data_to_process.filter(~seed_filter_cond)

            seed_records_df.persist()
            non_seed_records_df.persist()
            logger.info(f"CONSOLIDATED: Found {seed_records_df.count()} seed records and {non_seed_records_df.count()} non-seed records. Persisted.")
        else:
            logger.info("CONSOLIDATED: Seed exclusion not run or misconfigured. Processing all records as non-seed.")

        stats_df, samples_df, seed_samples_df, frequencies_df = None, None, None, None

        if non_seed_records_df.count() > 0:
            stats_df = logic_stats(logger, non_seed_records_df, include_empty_cells, input_format_fixed, file_path_for_stats_config)
            samples_df = logic_samples(logger, non_seed_records_df, num_sample_records)
            if run_frequency_reports:
                frequencies_df = logic_frequency_reports(logger, non_seed_records_df, frequency_c_fields, num_records_show_freq,
                                                         full_df_raw, original_batch_field_name_for_freq)
        else:
            logger.warning("CONSOLIDATED: No non-seed records to process for stats, samples, or frequencies.")

        if seed_records_df is not None and seed_records_df.count() > 0:
            seed_samples_df = logic_exclude_seed_samples(logger, seed_records_df)

        save_to_csv(logger, stats_df, samples_df, seed_samples_df, frequencies_df,
                    batch_value="CONSOLIDATED_REPORT",
                    separate_reports=False,
                    output_dir=output_dir)

        if seed_records_df is not None and seed_records_df.is_cached:
            seed_records_df.unpersist()
        if non_seed_records_df.is_cached and non_seed_records_df != current_data_to_process:
             non_seed_records_df.unpersist()
        logger.info("CONSOLIDATED: Processing complete.")

    else:
        logger.info(f"=================================================================")
        logger.info(f"CREATING SEPARATE REPORTS. Total batches to process: {len(batch_values_or_data_list)}")
        logger.info(f"=================================================================")

        for idx, batch_item in enumerate(batch_values_or_data_list):
            batch_value_str, current_batch_df = None, None

            if isinstance(batch_item, tuple) and len(batch_item) == 2 and isinstance(batch_item[1], DataFrame):
                batch_value_str, current_batch_df = batch_item
                logger.info(f"--- Processing pre-filtered data for batch value: '{batch_value_str}' (Batch {idx+1}/{len(batch_values_or_data_list)}) ---")
            else:
                batch_value_str = str(batch_item)
                logger.info(f"--- Filtering data for batch value: '{batch_value_str}' (Batch {idx+1}/{len(batch_values_or_data_list)}) ---")
                current_batch_df = full_df_raw.filter(col("batch") == batch_value_str)

            current_batch_df.persist()
            batch_row_count = current_batch_df.count()
            logger.info(f"Batch '{batch_value_str}' has {batch_row_count} records. Persisted.")

            if batch_row_count == 0:
                logger.warning(f"Batch '{batch_value_str}' is empty. Skipping analysis for this batch.")
                current_batch_df.unpersist()
                continue

            non_seed_records_this_batch_df = current_batch_df
            seed_records_this_batch_df = None

            if run_exclude_seeds and exclude_field and exclude_value and exclude_field in current_batch_df.columns:
                logger.info(f"BATCH '{batch_value_str}': Applying seed exclusion: field='{exclude_field}', value='{exclude_value}'")
                if '*' in exclude_value:
                    regex_pattern = '^' + exclude_value.replace('*', '.*') + '$'
                    seed_filter_cond = col(exclude_field).rlike(regex_pattern)
                else:
                    seed_filter_cond = (col(exclude_field) == exclude_value)

                seed_records_this_batch_df = current_batch_df.filter(seed_filter_cond)
                non_seed_records_this_batch_df = current_batch_df.filter(~seed_filter_cond)

                seed_records_this_batch_df.persist()
                non_seed_records_this_batch_df.persist()
                logger.info(f"BATCH '{batch_value_str}': Found {seed_records_this_batch_df.count()} seed and {non_seed_records_this_batch_df.count()} non-seed records. Persisted.")
            else:
                logger.info(f"BATCH '{batch_value_str}': Seed exclusion not run. Processing all as non-seed.")

            batch_stats_df, batch_samples_df, batch_seed_samples_df, batch_frequencies_df = None, None, None, None

            if non_seed_records_this_batch_df.count() > 0:
                batch_stats_df = logic_stats(logger, non_seed_records_this_batch_df, include_empty_cells, input_format_fixed, file_path_for_stats_config)
                batch_samples_df = logic_samples(logger, non_seed_records_this_batch_df, num_sample_records)
                if run_frequency_reports:
                    batch_frequencies_df = logic_frequency_reports(logger, non_seed_records_this_batch_df, frequency_c_fields, num_records_show_freq,
                                                                   full_df_raw, original_batch_field_name_for_freq)
            else:
                logger.warning(f"BATCH '{batch_value_str}': No non-seed records to process for stats, samples, or main frequencies.")

            if seed_records_this_batch_df is not None and seed_records_this_batch_df.count() > 0:
                batch_seed_samples_df = logic_exclude_seed_samples(logger, seed_records_this_batch_df)

            save_to_csv(logger, batch_stats_df, batch_samples_df, batch_seed_samples_df, batch_frequencies_df,
                        batch_value=str(batch_value_str),
                        separate_reports=True,
                        output_dir=output_dir)

            if seed_records_this_batch_df is not None and seed_records_this_batch_df.is_cached:
                seed_records_this_batch_df.unpersist()
            if non_seed_records_this_batch_df.is_cached and non_seed_records_this_batch_df != current_batch_df:
                 non_seed_records_this_batch_df.unpersist()
            current_batch_df.unpersist()
            logger.info(f"--- Processing for batch '{batch_value_str}' complete. Unpersisted DFs. ---")

            if (idx + 1) % 10 == 0:
                logger.info(f"Clearing Spark catalog cache after {idx+1} batches.")
                spark.catalog.clearCache()

        logger.info("SEPARATE REPORTS: All batch processing complete.")

#########################################################################################################
# SAVE TO CSV FUNCTION (Provided by user)                                                               #
#########################################################################################################
def save_to_csv(logger, stats_df=None, samples_df=None, seed_samples_df=None, frequencies_df=None,
                batch_value=None, separate_reports=False, output_dir="/data"):
    """
    Save the provided DataFrames to CSV files for faster processing.
    Optimized for large datasets where Excel writing can be slow.
    """
    try:
        current_date_str = datetime.now().strftime('%Y%m%d')

        if separate_reports and batch_value:
            batch_value_clean = re.sub(r'[^\w\-_.]', '_', str(batch_value))
            base_dir_name = f"report_{batch_value_clean}_{current_date_str}"
        else:
            base_dir_name = f"Audience_Engine_Supply_Internal_minmax_{current_date_str}"

        base_output_dir = os.path.join(output_dir, base_dir_name)
        logger.info(f"Preparing to save CSV outputs in HDFS directory: {base_output_dir}")

        csv_paths = {
            "base_dir": base_output_dir, "stats": None, "samples": None,
            "seed_samples": None, "frequencies": None
        }
        metadata = {
            "created_date": current_date_str,
            "batch_value": str(batch_value) if batch_value else "all_consolidated",
            "separate_reports": separate_reports,
            "sheets": {}
        }

        def write_df_to_csv(df, name, path_key):
            if df is not None:
                df_count = df.count()
                if df_count > 0:
                    target_path = os.path.join(base_output_dir, name)
                    logger.info(f"Saving {name} data to CSV: {target_path} ({df_count} rows)")
                    num_partitions = 1 if df_count < 500000 else df.rdd.getNumPartitions()
                    df.coalesce(num_partitions).write.mode("overwrite").option("header", "true").csv(target_path)
                    csv_paths[path_key] = target_path
                    metadata["sheets"][name.capitalize()] = {
                        "path": target_path, "row_count": df_count, "columns": df.columns
                    }
                    logger.info(f"{name.capitalize()} data saved successfully.")
                else:
                    logger.info(f"{name.capitalize()} DataFrame is empty. Skipping CSV write.")
            else:
                logger.info(f"{name.capitalize()} DataFrame is None. Skipping CSV write.")

        write_df_to_csv(stats_df, "stats", "stats")
        write_df_to_csv(samples_df, "samples", "samples")
        write_df_to_csv(seed_samples_df, "seed_samples", "seed_samples")
        write_df_to_csv(frequencies_df, "frequencies", "frequencies")

        if metadata["sheets"]:
            metadata_dir_path = os.path.join(base_output_dir, "metadata_json")
            logger.info(f"Saving metadata to: {metadata_dir_path}")
            metadata_json_str = json.dumps(metadata, indent=2)
            metadata_rdd = spark.sparkContext.parallelize([metadata_json_str])
            metadata_df = spark.createDataFrame(metadata_rdd, StringType()).withColumnRenamed("value", "json_content")
            metadata_df.coalesce(1).write.mode("overwrite").text(metadata_dir_path)
            logger.info(f"Metadata JSON saved successfully in {metadata_dir_path}")
        else:
            logger.info("No data was written, so metadata file was not created.")

        logger.info(f"All available CSV files and metadata saved to base directory: {base_output_dir}")
        return csv_paths

    except Exception as e:
        logger.error(f"Error saving to CSV: {str(e)}", exc_info=True)
        raise

#########################################################################################################
# START OF MAIN SCRIPT                                                                                  #
#########################################################################################################
if __name__ == "__main__":


    parser = argparse.ArgumentParser(description="MinMax Data Profiling Processor (Optimized for Large Datasets)")
    parser.add_argument('--input_file', required=True, help='Path to the input CSV file or directory from Module 1 (must contain Original_Row_Number)')
    parser.add_argument('--output_dir', required=True, help='HDFS base directory for output CSVs and metadata')
    parser.add_argument('--log_file_path', required=False, help='Full path for the log file')

    parser.add_argument('--num_sample_records', type=int, required=True, help='Number of records for the Samples output')

    parser.add_argument('--run_exclude_seeds', type=lambda x: (str(x).lower() == 'true'), required=True, help='Boolean: Run seed exclusion logic')
    parser.add_argument('--exclude_field', type=str, required=False, help='Field name for seed exclusion (required if run_exclude_seeds is True)')
    parser.add_argument('--exclude_value', type=str, required=False, help='Value/pattern for seed exclusion (e.g., "AB10" or "AB*") (required if run_exclude_seeds is True)')

    parser.add_argument('--include_empty_cells', type=lambda x: (str(x).lower() == 'true'), required=True, help='Boolean: Include empty/blank cells in certain stats (min/max string value logic)')
    parser.add_argument('--input_format_fixed', type=lambda x: (str(x).lower() == 'true'), required=True, help='Boolean: Is input using fixed-width format (affects stats position calc)')

    parser.add_argument('--batch', type=lambda x: (str(x).lower() == 'true'), required=True, help='Boolean: Enable batch processing based on a field')
    parser.add_argument('--batch_field', type=str, required=False, help='Field name to use for batching (required if --batch is True)')
    parser.add_argument('--separate_reports', type=lambda x: (str(x).lower() == 'true'), default=False, help='Boolean: Create separate CSV output directories for each batch (default: False, consolidated report)')

    parser.add_argument('--run_frequency_reports', type=lambda x: (str(x).lower() == 'true'), default=False, help='Boolean: Generate frequency reports (default: False)')
    parser.add_argument('--frequency_c_fields', nargs='+', required=False, default=None, help='List of C-Variable column names for frequency reports (overrides config defaults)')
    parser.add_argument('--num_records_show', type=int, default=10, help='Number of top records to show per field in frequency reports (default: 10)')

    args = parser.parse_args()

    if args.log_file_path:
        log_file_path = args.log_file_path
    else:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        log_dir = os.path.join(current_dir, "logs")
        os.makedirs(log_dir, exist_ok=True)
        log_file_path = os.path.join(log_dir, "minmax_processor.log")
    
    logger = LogConfig(log_file_path).generate_logger("minmax_processor")
    
    logger.info("MinMax Processor V2 started")
    logger.info(f"Log file: {log_file_path}")
    logger.info(f"Received arguments: {args}")

    if args.run_exclude_seeds and (not args.exclude_field or args.exclude_value is None):
        logger.error("If --run_exclude_seeds is True, both --exclude_field and --exclude_value must be provided.")
        sys.exit(1)
    if args.batch and not args.batch_field:
        logger.error("If --batch is True, --batch_field must be provided.")
        sys.exit(1)

    try:
        spark = SparkSession.builder \
            .appName(f"MinMaxProcessorV2_row_number") \
            .getOrCreate()
        spark.sparkContext.setLogLevel("WARN")
        logger.info("SparkSession initialized successfully.")
    except Exception as e:
        logger.error(f"Failed to initialize SparkSession: {str(e)}", exc_info=True)
        sys.exit(1)

    try:
        logic_main(
            logger=logger,
            file_path=args.input_file,
            output_dir=args.output_dir,
            num_sample_records=args.num_sample_records,
            run_exclude_seeds=args.run_exclude_seeds,
            exclude_field=args.exclude_field,
            exclude_value=args.exclude_value,
            include_empty_cells=args.include_empty_cells,
            input_format_fixed=args.input_format_fixed,
            batch_processing_enabled=args.batch,
            batch_field_name=args.batch_field,
            run_frequency_reports=args.run_frequency_reports,
            frequency_c_fields=args.frequency_c_fields,
            num_records_show_freq=args.num_records_show,
            separate_reports_by_batch=args.separate_reports
        )
        logger.info(f"Main processing logic completed")
    except Exception as e:
        logger.error(f"Unhandled exception in main script execution: {str(e)}", exc_info=True)
        sys.exit(1)
    finally:
        if spark:
            logger.info("Stopping SparkSession.")
            spark.stop()
            logger.info("SparkSession stopped.")