import json
import logging
import time
import boto3
import fnmatch
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.python import PythonOperator, BranchPythonOperator, get_current_context
from airflow.operators.dummy import DummyOperator
from airflow.operators.email import EmailOperator
from airflow.models import Variable
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

import pendulum
import re
import sys
import os
import tempfile
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))
sys.path.append(str(Path(__file__).resolve().parents[1]) + "/shared")

logging.getLogger(__name__).setLevel(logging.INFO)

import shared.functions
import shared.utils
import shared.utils.utils
import shared.bucket_list

from shared.functions import platform, get_env, parse_s3_path
from urllib.parse import urlparse

def resolve_s3_pattern(s3_path_pattern):
    import boto3
    import fnmatch
    
    if s3_path_pattern.startswith("s3://"):
        s3_path_pattern = s3_path_pattern[5:]
    elif s3_path_pattern.startswith("s3a://"):
        s3_path_pattern = s3_path_pattern[6:]
    
    parts = s3_path_pattern.split('/', 1)
    bucket_name = parts[0]
    key_pattern = parts[1] if len(parts) > 1 else ""
    
    logging.info(f"Resolving S3 pattern: bucket={bucket_name}, pattern={key_pattern}")
    
    try:
        s3 = boto3.client('s3')
        
        if '*' not in key_pattern:
            return f"s3://{bucket_name}/{key_pattern}"
        
        # Extract prefix before first wildcard for efficient S3 listing
        prefix = key_pattern.split('*')[0]
        
        paginator = s3.get_paginator('list_objects_v2')
        page_iterator = paginator.paginate(Bucket=bucket_name, Prefix=prefix)
        
        for page in page_iterator:
            if 'Contents' in page:
                for obj in page['Contents']:
                    obj_key = obj['Key']
                    if fnmatch.fnmatch(obj_key, key_pattern):
                        resolved_path = f"s3://{bucket_name}/{obj_key}"
                        logging.info(f"Resolved pattern to: {resolved_path}")
                        return resolved_path
        
        logging.warning(f"No files found matching pattern: {key_pattern}")
        return None
        
    except Exception as e:
        logging.error(f"Error resolving S3 pattern {s3_path_pattern}: {e}")
        return None

def file_exists_with_pattern(bucket_name, key_pattern, exclude=None):
    import boto3
    import fnmatch
    
    logging.info(f"Checking if file exists in bucket '{bucket_name}' with pattern '{key_pattern}'")
    
    try:
        s3 = boto3.client('s3')

        if '*' in key_pattern:
            prefix = key_pattern.split('*')[0]
        else:
            try:
                s3.head_object(Bucket=bucket_name, Key=key_pattern)
                logging.info(f"Found exact match for key: {key_pattern}")
                return True
            except Exception as e:
                logging.error(f"Error checking exact key {key_pattern}: {e}")
                return False
        
        paginator = s3.get_paginator('list_objects_v2')
        page_iterator = paginator.paginate(Bucket=bucket_name, Prefix=prefix)
        
        for page in page_iterator:
            if 'Contents' in page:
                for obj in page['Contents']:
                    obj_key = obj['Key']
                    logging.info(f"Checking object key: {obj_key}")
  
                    if fnmatch.fnmatch(obj_key, key_pattern):

                        if exclude and exclude in obj_key:
                            logging.info(f"Excluding {obj_key} due to exclude pattern: {exclude}")
                            continue
                        
                        logging.info(f"Found matching file: {obj_key}")
                        return True
        
        logging.warning(f"No files found matching pattern: {key_pattern}")
        return False
        
    except Exception as e:
        logging.error(f"Error checking if file exists with pattern {key_pattern}: {e}")
        return False

from shared.utils.emr_application_factory import create_emr_application, delete_emr_application, start_emr_job
import boto3

with DAG(
    "audience_engine_processing",
    description="Process Audience Engine data end-to-end",
    catchup=False,
    start_date=pendulum.datetime(2023, 1, 1, tz="UTC"),
    schedule_interval="0 10 * * 3",  # Weekly on Wednesday at 10 AM
    tags=["audience_engine", "consumer_sync"],
    default_args={
        'owner': 'airflow',
        'depends_on_past': False,
        'email_on_failure': True,
        'email_on_retry': False,
        'retries': 1,
        'retry_delay': timedelta(minutes=5),
    },
) as dag:

    def create_script_arguments(**context):
        from shared.bucket_list import get_bucket_name
        from shared.functions import latest_path, get_env, latest_file
        
        logging.info("Creating script arguments for Audience Engine processing")
        
        workflow_start_time = time.time()
        logging.info("Workflow started %s", datetime.fromtimestamp(workflow_start_time))
        
        env = get_env()
        execution_date = context["execution_date"]
        
        # Support both compressed (YYYYMM) and hyphenated (YYYY-MM) date formats
        month_yyyymm = execution_date.strftime("%Y%m")
        month_yyyy_mm = execution_date.strftime("%Y-%m")
        date_str = execution_date.strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%Y%m%d%H%M%S")
        
        # Store timing, environment, and date information for processing continuity
        context["task_instance"].xcom_push(key="workflow_start_time", value=workflow_start_time)
        context["task_instance"].xcom_push(key="env", value=env)
        context["task_instance"].xcom_push(key="month_yyyymm", value=month_yyyymm)
        context["task_instance"].xcom_push(key="month_yyyy_mm", value=month_yyyy_mm)
        context["task_instance"].xcom_push(key="execution_date", value=date_str)
        
        PROTOCOL = "s3a"
        
        source_bucket = get_bucket_name("source")
        interim_bucket = get_bucket_name("interim") 
        output_bucket = get_bucket_name("output")
        code_bucket = get_bucket_name("code")
        log_bucket = get_bucket_name("logs")
        stats_bucket = get_bucket_name("stats")
        
        stats_timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        context["task_instance"].xcom_push(key="stats_timestamp", value=stats_timestamp)

        context["task_instance"].xcom_push(key="source_bucket", value=source_bucket)
        context["task_instance"].xcom_push(key="interim_bucket", value=interim_bucket)
        context["task_instance"].xcom_push(key="output_bucket", value=output_bucket)
        context["task_instance"].xcom_push(key="code_bucket", value=code_bucket)
        context["task_instance"].xcom_push(key="log_bucket", value=log_bucket)
        context["task_instance"].xcom_push(key="stats_bucket", value=stats_bucket)

        ae_source_base_path = f"{PROTOCOL}://{source_bucket}/internal/audience_engine"
        ae_output_base_path = f"{PROTOCOL}://{output_bucket}/audience_engine"

        # Define file organization patterns based on on-premises structure
        file_patterns = {
            # Current month files (YYYY_MM folder structure to match on-prem)
                "current_month": {
                    "digital_taxonomy_input": f"{ae_source_base_path}/{month_yyyy_mm}/*_Digital_taxonomy*.txt",
                    "experian_match_input": f"{ae_source_base_path}/{month_yyyy_mm}/Experian_matched_IDs_*.csv",
                    "pam_directory_input": f"{ae_source_base_path}/{month_yyyy_mm}/F03.PAMDirectory*.csv",
                    "cbaf_utility_input": f"{ae_source_base_path}/{month_yyyy_mm}/F45.*.cbaf_utility*.csv",
                    "utility_input": f"{ae_source_base_path}/{month_yyyy_mm}/A16_*_cbaf_utility*.csv",
                    "counties_lookup_input": f"{ae_source_base_path}/{month_yyyy_mm}/Counties_Lookup*.xlsx",
                    "match_output_input": f"{ae_source_base_path}/{month_yyyy_mm}/MatchOutputFile*.csv"
                }
        }
        
        # Flatten file patterns into single input_files dict
        input_files = {}
        for category, files in file_patterns.items():
            input_files.update(files)
        
        # Previous month file for comparison (if exists)
        prev_month = (execution_date - timedelta(days=30)).strftime("%Y_%m")
        prev_month_comparison = f"{ae_output_base_path}/output/{prev_month}/*/minmax_output/*.xlsx"

        # No config files needed - EMR scripts use hardcoded config.py
        config_files = {}
        
        # Use interim bucket for all interim files
        interim_paths = {
            "module1_output": f"{ae_output_base_path}/output/{month_yyyy_mm}/module1_output",
            "minmax_output": f"{ae_output_base_path}/output/{month_yyyy_mm}/minmax_output", 
            "comparison_output": f"{ae_output_base_path}/output/{month_yyyy_mm}/comparison_output"
        }
        
        output_paths = {
            "final_output_dir": f"{PROTOCOL}://{output_bucket}/audience_engine/{month_yyyy_mm}",
            "local_temp_dir": f"/tmp/audience_engine_{now_str}",
            "previous_comparison_file": prev_month_comparison
        }
        
        all_paths = {
            **input_files,
            **config_files, 
            **interim_paths,
            **output_paths
        }
        
        logging.info(f"Using Audience Engine file paths for {month_yyyy_mm}")
     
        context["task_instance"].xcom_push(key="AE_INPUT_FILES", value=input_files)
        context["task_instance"].xcom_push(key="AE_CONFIG_FILES", value=config_files)
        context["task_instance"].xcom_push(key="AE_INTERIM_PATHS", value=interim_paths)
        context["task_instance"].xcom_push(key="AE_OUTPUT_PATHS", value=output_paths)
        context["task_instance"].xcom_push(key="AE_ALL_PATHS", value=all_paths)

        required_files = [
            "digital_taxonomy_input", "experian_match_input", "pam_directory_input", 
            "cbaf_utility_input", "utility_input", "counties_lookup_input", "match_output_input"
        ]
        
        missing_files = []
        existing_files = []
        
        for file_key in required_files:
            file_path = input_files[file_key]
            try:
                bucket_name, key = parse_s3_path(file_path)
                if file_exists_with_pattern(bucket_name, key):
                    existing_files.append(file_key)
                    logging.info(f"Found {file_key} at {file_path}")
                else:
                    missing_files.append(file_key)
                    logging.warning(f"Missing {file_key} at {file_path}")
            except Exception as e:
                missing_files.append(file_key)
                logging.error(f"Error checking {file_key}: {str(e)}")
        
        context["task_instance"].xcom_push(key="missing_files", value=missing_files)
        context["task_instance"].xcom_push(key="existing_files", value=existing_files)
        context["task_instance"].xcom_push(key="all_files_exist", value=len(missing_files) == 0)
        
        execution_role_arn = shared.utils.utils.get_emr_serverless_role(env)
        log_uri_prefix = f"s3://{log_bucket}/spark-logs"
        shared_code = [
            f"s3://{code_bucket}/zipped/ems-code-shared.zip,s3://{code_bucket}/zipped/openpyxl.zip,s3://{code_bucket}/zipped/fsspec.zip,s3://{code_bucket}/zipped/s3fs.zip",
            f"s3://{code_bucket}/repos/ems-code-consumer-sync-audience-engine/spark/config.py",
            f"s3://{code_bucket}/repos/ems-code-consumer-sync-audience-engine/spark/functions.py"
        ]
        ae_code_prefix = f"s3://{code_bucket}/repos/ems-code-consumer-sync-audience-engine/spark"
        
        context["task_instance"].xcom_push(key="EXECUTION_ROLE_ARN", value=execution_role_arn)
        context["task_instance"].xcom_push(key="LOG_URI_PREFIX", value=log_uri_prefix)
        context["task_instance"].xcom_push(key="SHARED_CODE", value=shared_code)
        context["task_instance"].xcom_push(key="AE_CODE_PREFIX", value=ae_code_prefix)
        
        return True

    def initialise(**context):
        logging.info("Initializing EMR Serverless application for Audience Engine")
        
        emr_subnet_ids = None
        emr_security_group_ids = None
      
        date = datetime.now().strftime("%Y%m%d%H%M%S")
        emr_application_name = f"audience-engine-{date}"
        
        logging.info(f"Creating EMR application with name {emr_application_name}")
  
        app_id = create_emr_application(
            context, emr_application_name, emr_subnet_ids, emr_security_group_ids
        )
 
        context["task_instance"].xcom_push(key="application_id", value=app_id)
        context["task_instance"].xcom_push(key="emr_application_name", value=emr_application_name)
        
        logging.info(f"Created EMR application {app_id}")
        
        end_time = time.time()
        workflow_start_time = context["task_instance"].xcom_pull(key="workflow_start_time", task_ids="create_script_arguments")
        
        logging.info(f"Initialisation finished, created {app_id}, time taken: {timedelta(seconds=end_time - workflow_start_time)}")
        
        return "Executed initialise..."

    def check_inputs_exist(**context):
        from airflow.exceptions import AirflowSkipException
        
        all_files_exist = context["ti"].xcom_pull(key="all_files_exist", task_ids="create_script_arguments")
        missing_files = context["ti"].xcom_pull(key="missing_files", task_ids="create_script_arguments")
        existing_files = context["ti"].xcom_pull(key="existing_files", task_ids="create_script_arguments")
        
        if all_files_exist:
            logging.info("All required input files exist, proceeding with processing")
            
            # Send start email notification like in original shell script
            send_start_email(context, existing_files)
            
            return True
        else:
            logging.warning(f"Missing required files: {missing_files}")
            
            # Send failure email notification
            send_file_validation_failure_email(context, missing_files)
            
            raise AirflowSkipException(f"Skipping processing due to missing required files: {missing_files}")

    def send_start_email(context, existing_files):
        """Send pipeline start email notification"""
        from airflow.operators.email import EmailOperator
        
        execution_date = context["execution_date"]
        month_name = execution_date.strftime("%B_%Y")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Create file inventory
        file_inventory = "=== VALIDATED INPUT FILES ===\n"
        input_files = context["ti"].xcom_pull(key="AE_INPUT_FILES", task_ids="create_script_arguments")
        
        for file_key in existing_files:
            if file_key in input_files:
                file_inventory += f"- {file_key.upper()}: {input_files[file_key]}\n"
        
        email_body = f"""Audience Engine Pipeline - STARTED for {month_name}
==================================================
✅ ALL REQUIRED FILES VALIDATED SUCCESSFULLY

Pipeline execution has started with validated input files.
Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Execution ID: {timestamp}
Month: {month_name}

{file_inventory}

The pipeline will now proceed with Module 1 processing.
You will receive progress updates for each major stage.
"""
        
        email_op = EmailOperator(
            task_id="send_start_email",
            to=["kallusrujan.reddy@experian.com"],
            subject=f"[AUDIENCE ENGINE] STARTED - {month_name} Pipeline (All Files Validated)",
            html_content=email_body.replace('\n', '<br>'),
            dag=context['dag']
        )
        
        email_op.execute(context=context)
        logging.info("Sent pipeline start email notification")

    def send_file_validation_failure_email(context, missing_files):
        """Send file validation failure email"""
        from airflow.operators.email import EmailOperator
        
        execution_date = context["execution_date"]
        month_name = execution_date.strftime("%B_%Y")
        
        email_body = f"""Audience Engine Pipeline - FILE VALIDATION FAILED
==================================================
FILE VALIDATION FAILED - CANNOT PROCEED

The pipeline cannot start because required input files are missing or invalid.

Missing files: {', '.join(missing_files)}

Please ensure all required files are available in the correct S3 location and retry.
"""
        
        email_op = EmailOperator(
            task_id="send_file_validation_failure_email",
            to=["kallusrujan.reddy@experian.com"],
            subject=f"[AUDIENCE ENGINE] FILE VALIDATION FAILED - Cannot Start Pipeline",
            html_content=email_body.replace('\n', '<br>'),
            dag=context['dag']
        )
        
        email_op.execute(context=context)
        logging.info("Sent file validation failure email notification")

    def send_stage_completion_email(context, stage_name: str, stage_number: int, duration: float, job_id: str):
        """Send stage completion email notification (matching shell script pattern)"""
        from airflow.operators.email import EmailOperator
        
        execution_date = context["execution_date"]
        month_name = execution_date.strftime("%B_%Y")
        
        # Format duration like shell script
        def format_duration(seconds):
            hours = int(seconds // 3600)
            minutes = int((seconds % 3600) // 60)
            secs = int(seconds % 60)
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        
        email_body = f"""Audience Engine Pipeline - Stage {stage_number} Complete for {month_name}
==================================================
✅ STEP {stage_number}: {stage_name} completed successfully

Execution ID: {datetime.now().strftime("%Y%m%d_%H%M%S")}
Stage: {stage_name}
Duration: {format_duration(duration)} ({int(duration)}s)
Job ID: {job_id}

Processing Details:
- Stage {stage_number} completed successfully
- All outputs generated as expected
- Ready to proceed to next stage

Next: Proceeding to next processing stage

Logs available in EMR Serverless application logs.
"""
        
        email_op = EmailOperator(
            task_id=f"send_stage_{stage_number}_email",
            to=["kallusrujan.reddy@experian.com"],
            subject=f"[AUDIENCE ENGINE] Stage {stage_number} Complete - {stage_name}",
            html_content=email_body.replace('\n', '<br>'),
            dag=context['dag']
        )
        
        email_op.execute(context=context)
        logging.info(f"Sent stage {stage_number} completion email notification")

    # Stats collection functions for all input files (like digital taxonomy)
    def collect_digital_taxonomy_stats(**context):
        """Collect statistics from Digital Taxonomy input file"""
        return collect_file_stats(context, "Digital_Taxonomy", "digital_taxonomy_input")
    
    def collect_experian_match_stats(**context):
        """Collect statistics from Experian Match input file"""  
        return collect_file_stats(context, "Experian_Match", "experian_match_input")
    
    def collect_pam_directory_stats(**context):
        """Collect statistics from PAM Directory input file"""
        return collect_file_stats(context, "PAM_Directory", "pam_directory_input")
    
    def collect_cbaf_utility_stats(**context):
        """Collect statistics from CBAF Utility input file"""
        return collect_file_stats(context, "CBAF_Utility", "cbaf_utility_input")
    
    def collect_utility_stats(**context):
        """Collect statistics from Utility input file"""
        return collect_file_stats(context, "Utility", "utility_input")
    
    def collect_counties_lookup_stats(**context):
        """Collect statistics from Counties Lookup input file"""
        return collect_file_stats(context, "Counties_Lookup", "counties_lookup_input")
    
    def collect_match_output_stats(**context):
        """Collect statistics from Match Output input file"""
        return collect_file_stats(context, "Match_Output", "match_output_input")

    def collect_file_stats(context, file_name: str, file_key: str):
        from shared.utils.emr_application_factory import start_emr_job
        
        start_time = time.time()
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        AE_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="AE_CODE_PREFIX", task_ids="create_script_arguments"
        )
        
        input_files = context["task_instance"].xcom_pull(
            key="AE_INPUT_FILES", task_ids="create_script_arguments"
        )
     
        execution_date = context["task_instance"].xcom_pull(key="execution_date", task_ids="create_script_arguments")
        
        # Use the same stats script path as digital taxonomy
        stats_script = f"{AE_CODE_PREFIX}/get_stats_emr.py"
        
        input_file_pattern = input_files[file_key]
        if input_file_pattern.startswith("s3a://"):
            input_file_pattern = input_file_pattern.replace("s3a://", "s3://")
        
        input_file_path = resolve_s3_pattern(input_file_pattern)
        if not input_file_path:
            raise ValueError(f"No file found matching pattern: {input_file_pattern}")
        
        logging.info(f"Collecting stats for {file_name} input file: {input_file_path} (resolved from {input_file_pattern})")

        job = start_emr_job(
            task_id=f"collect_{file_name.lower()}_stats",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": stats_script,
                    "entryPointArguments": [
                        "-m", execution_date,
                        "-if", input_file_path
                    ],
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                }
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/audience_engine_{file_name.lower()}_stats",
                    }
                }
            },
        )
        
        job_id = job.execute(get_current_context())
        
        end_time = time.time()
        logging.info(f"{file_name} stats collection finished, time taken: {timedelta(seconds=end_time - start_time)}")
        
        return f"Executed {file_name} stats collection: {job_id}"

    def run_module1(**context):
        from shared.utils.emr_application_factory import start_emr_job
        
        start_time = time.time()
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        AE_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="AE_CODE_PREFIX", task_ids="create_script_arguments"
        )
        
        input_files = context["task_instance"].xcom_pull(
            key="AE_INPUT_FILES", task_ids="create_script_arguments"
        )
        interim_paths = context["task_instance"].xcom_pull(
            key="AE_INTERIM_PATHS", task_ids="create_script_arguments"
        )
        source_bucket = context["task_instance"].xcom_pull(
            key="source_bucket", task_ids="create_script_arguments"
        )
        
        # Resolve S3 patterns to actual file paths
        resolved_files = {}
        for file_key, file_pattern in input_files.items():
            resolved_path = resolve_s3_pattern(file_pattern)
            if resolved_path:
                # Ensure s3a:// protocol for Spark
                if resolved_path.startswith("s3://"):
                    resolved_path = resolved_path.replace("s3://", "s3a://")
                resolved_files[file_key] = resolved_path
                logging.info(f"Resolved {file_key}: {resolved_path}")
            else:
                logging.error(f"Could not resolve {file_key}: {file_pattern}")
                raise Exception(f"Required file not found: {file_key}")
        
        module1_script = f"{AE_CODE_PREFIX}/module1_emr.py"
        
        # Build arguments for Module 1 with s3a:// paths
        output_dir = interim_paths["module1_output"]
        if output_dir.startswith("s3://"):
            output_dir = output_dir.replace("s3://", "s3a://")
        
        supporting_data_dir = f"s3a://{source_bucket}/internal/audience_engine"
        
        script_args = [
            "--digital_taxonomy_file", resolved_files["digital_taxonomy_input"],
            "--experian_match_file", resolved_files["experian_match_input"],
            "--pam_directory_file", resolved_files["pam_directory_input"],
            "--cbaf_utility_file", resolved_files["cbaf_utility_input"],
            "--utility_file", resolved_files["utility_input"],
            "--counties_lookup_file", resolved_files["counties_lookup_input"],
            "--match_output_file", resolved_files["match_output_input"],
            "--output_dir", output_dir,
            "--supporting_data_dir", supporting_data_dir
        ]
        
        logging.info(f"Starting Module 1 EMR job with script: {module1_script}")
        logging.info(f"Script arguments: {script_args}")
        
        # Use the correct start_emr_job function signature
        job = start_emr_job(
            task_id="run_module1_emr",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": module1_script,
                    "entryPointArguments": script_args,
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                }
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/audience_engine_module1",
                    }
                }
            },
        )
        
        job_run_id = job.execute(get_current_context())
        
        end_time = time.time()
        duration = end_time - start_time
        
        logging.info(f"Module 1 completed in {timedelta(seconds=duration)}")
        
        context["task_instance"].xcom_push(key="module1_job_run_id", value=job_run_id)
        context["task_instance"].xcom_push(key="module1_duration", value=duration)
        
        # Send stage completion email like in shell script
        send_stage_completion_email(context, "Module 1 Processing", 1, duration, job_run_id)
        
        return f"Module 1 completed: {job_run_id}"

    def run_minmax_processing(**context):
        from shared.utils.emr_application_factory import start_emr_job
        
        start_time = time.time()
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        AE_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="AE_CODE_PREFIX", task_ids="create_script_arguments"
        )
        
        interim_paths = context["task_instance"].xcom_pull(
            key="AE_INTERIM_PATHS", task_ids="create_script_arguments"
        )
        
        minmax_script = f"{AE_CODE_PREFIX}/minmax_processor_emr.py"
        
        # Simple approach: Build the expected Module 1 CSV output path directly
        # Module 1 should create: module1_output/YYYYMMDD_module1_output.csv/
        current_date = datetime.now().strftime("%Y%m%d")
        expected_csv_name = f"{current_date}_module1_output.csv"
        
        module1_base = interim_paths["module1_output"]
        # Build the direct path to the CSV directory
        input_csv_path = f"{module1_base}/{expected_csv_name}"
        
        # Convert to s3a:// for Spark
        if input_csv_path.startswith("s3://"):
            input_csv_path = input_csv_path.replace("s3://", "s3a://")
        
        output_dir = interim_paths["minmax_output"]
        if output_dir.startswith("s3://"):
            output_dir = output_dir.replace("s3://", "s3a://")
        
        # Build arguments for MinMax processing
        script_args = [
            "--input_file", input_csv_path,  # Direct path to the CSV directory
            "--output_dir", output_dir,
            "--num_sample_records", "100",
            "--run_exclude_seeds", "False",
            "--exclude_field", "Postcode District",
            "--exclude_value", "FY1",
            "--include_empty_cells", "True",
            "--input_format_fixed", "False",
            "--batch", "False",
            "--batch_field", "Postcode Area",
            "--run_frequency_reports", "True",
            "--num_records_show", "999",
            "--separate_reports", "False"
        ]
        
        logging.info(f"Starting MinMax processing EMR job with script: {minmax_script}")
        logging.info(f"Expected CSV path: {input_csv_path}")
        logging.info(f"Output directory: {output_dir}")
        logging.info(f"Script arguments: {script_args}")
        
        job = start_emr_job(
            task_id="run_minmax_emr",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": minmax_script,
                    "entryPointArguments": script_args,
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                }
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/audience_engine_minmax",
                    }
                }
            },
        )
        
        job_run_id = job.execute(get_current_context())
        
        end_time = time.time()
        duration = end_time - start_time
        
        logging.info(f"MinMax processing completed in {timedelta(seconds=duration)}")
        
        context["task_instance"].xcom_push(key="minmax_job_run_id", value=job_run_id)
        context["task_instance"].xcom_push(key="minmax_duration", value=duration)
        
        # Send stage completion email like in shell script
        send_stage_completion_email(context, "MinMax Processing", 2, duration, job_run_id)
        
        return f"MinMax processing completed: {job_run_id}"

    def run_excel_conversion(**context):
        from shared.utils.emr_application_factory import start_emr_job
        
        start_time = time.time()
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        AE_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="AE_CODE_PREFIX", task_ids="create_script_arguments"
        )
        
        interim_paths = context["task_instance"].xcom_pull(
            key="AE_INTERIM_PATHS", task_ids="create_script_arguments"
        )
        
        excel_script = f"{AE_CODE_PREFIX}/excel_builder_emr.py"
        
        # Build the specific MinMax output subdirectory path
        current_date = datetime.now().strftime("%Y%m%d")
        minmax_subdir_name = f"Audience_Engine_Supply_Internal_minmax_{current_date}"
        
        minmax_base_dir = interim_paths["minmax_output"]
        # Point to the specific subdirectory where MinMax saves the CSV files
        input_dir = f"{minmax_base_dir}/{minmax_subdir_name}"
        output_dir = interim_paths["minmax_output"]  # Save Excel in the base minmax directory
        
        # Keep s3:// for boto3 operations in excel_builder_emr.py
        # The script handles s3a:// conversion internally for Spark operations
        
        # Build arguments for Excel conversion
        script_args = [
            "--input_dir", input_dir,
            "--output_dir", output_dir,
            "--single_report"  # Create single consolidated Excel report
        ]
        
        logging.info(f"Starting Excel conversion EMR job")
        logging.info(f"Script: {excel_script}")
        logging.info(f"Input directory (MinMax CSV subdirectory): {input_dir}")
        logging.info(f"Output directory: {output_dir}")
        logging.info(f"Arguments: {script_args}")
        
        job = start_emr_job(
            task_id="run_excel_emr",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": excel_script,
                    "entryPointArguments": script_args,
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                }
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/audience_engine_excel",
                    }
                }
            },
        )
        
        job_run_id = job.execute(get_current_context())
        
        end_time = time.time()
        duration = end_time - start_time
        
        logging.info(f"Excel conversion completed in {timedelta(seconds=duration)}")
        
        context["task_instance"].xcom_push(key="excel_job_run_id", value=job_run_id)
        context["task_instance"].xcom_push(key="excel_duration", value=duration)
        
        # Send stage completion email like in shell script
        send_stage_completion_email(context, "Excel Conversion", 3, duration, job_run_id)
        
        return f"Excel conversion completed: {job_run_id}"

    def run_comparison_processing(**context):
        from shared.utils.emr_application_factory import start_emr_job
        
        start_time = time.time()
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        AE_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="AE_CODE_PREFIX", task_ids="create_script_arguments"
        )
        
        interim_paths = context["task_instance"].xcom_pull(
            key="AE_INTERIM_PATHS", task_ids="create_script_arguments"
        )
        output_paths = context["task_instance"].xcom_pull(
            key="AE_OUTPUT_PATHS", task_ids="create_script_arguments"
        )
        
        comparison_script = f"{AE_CODE_PREFIX}/module3_comparison_emr.py"
        
        # Build arguments for comparison processing
        current_file_dir = interim_paths["minmax_output"]
        previous_file = output_paths["previous_comparison_file"]
        output_dir = interim_paths["comparison_output"]
        
        # Convert to s3a:// for Spark operations
        if current_file_dir.startswith("s3://"):
            current_file_dir = current_file_dir.replace("s3://", "s3a://")
        if output_dir.startswith("s3://"):
            output_dir = output_dir.replace("s3://", "s3a://")
        
        script_args = [
            "--current_file", current_file_dir,  # Pass directory containing Excel file
            "--previous_file", previous_file,     # Keep as pattern for script to resolve
            "--output_dir", output_dir
        ]
        
        logging.info(f"Starting comparison processing EMR job with script: {comparison_script}")
        logging.info(f"Current file directory: {current_file_dir}")
        logging.info(f"Previous file pattern: {previous_file}")
        logging.info(f"Output directory: {output_dir}")
        logging.info(f"Script arguments: {script_args}")
        
        job = start_emr_job(
            task_id="run_comparison_emr",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": comparison_script,
                    "entryPointArguments": script_args,
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                }
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/audience_engine_comparison",
                    }
                }
            },
        )
        
        job_run_id = job.execute(get_current_context())
        
        end_time = time.time()
        duration = end_time - start_time
        
        logging.info(f"Comparison processing completed in {timedelta(seconds=duration)}")
        
        context["task_instance"].xcom_push(key="comparison_job_run_id", value=job_run_id)
        context["task_instance"].xcom_push(key="comparison_duration", value=duration)
        
        return f"Comparison processing completed: {job_run_id}"

    def copy_to_local_temp(**context):
        """Copy processed files to final output location in S3"""
        from shared.utils.emr_application_factory import start_emr_job
        
        start_time = time.time()
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        AE_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="AE_CODE_PREFIX", task_ids="create_script_arguments"
        )
        
        interim_paths = context["task_instance"].xcom_pull(
            key="AE_INTERIM_PATHS", task_ids="create_script_arguments"
        )
        output_paths = context["task_instance"].xcom_pull(
            key="AE_OUTPUT_PATHS", task_ids="create_script_arguments"
        )
        
        execution_date = context["task_instance"].xcom_pull(
            key="execution_date", task_ids="create_script_arguments"
        )
        
        # Create file copy script to handle file organization
        copy_script = f"{AE_CODE_PREFIX}/file_copy_emr.py"
        
        # Generate dynamic filenames like in shell script
        file_suffix = context["execution_date"].strftime('%B%y').replace(' ', '') + '_Supply'
        
        # Convert paths to s3a:// for Spark operations
        module1_output = interim_paths["module1_output"]
        minmax_output = interim_paths["minmax_output"]
        comparison_output = interim_paths["comparison_output"]
        final_output = output_paths["final_output_dir"]
        
        if module1_output.startswith("s3://"):
            module1_output = module1_output.replace("s3://", "s3a://")
        if minmax_output.startswith("s3://"):
            minmax_output = minmax_output.replace("s3://", "s3a://")
        if comparison_output.startswith("s3://"):
            comparison_output = comparison_output.replace("s3://", "s3a://")
        if final_output.startswith("s3://"):
            final_output = final_output.replace("s3://", "s3a://")
        
        # Build arguments for file copying
        script_args = [
            "--module1_s3_output", module1_output,
            "--minmax_s3_output", minmax_output,
            "--comparison_s3_output", comparison_output,
            "--final_s3_output", final_output,
            "--file_suffix", file_suffix,
            "--execution_date", execution_date
        ]
        
        logging.info(f"Starting file copy EMR job with script: {copy_script}")
        logging.info(f"Module1 output: {module1_output}")
        logging.info(f"MinMax output: {minmax_output}")
        logging.info(f"Comparison output: {comparison_output}")
        logging.info(f"Final output: {final_output}")
        logging.info(f"Script arguments: {script_args}")
        
        job = start_emr_job(
            task_id="run_copy_emr",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": copy_script,
                    "entryPointArguments": script_args,
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                }
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/audience_engine_copy",
                    }
                }
            },
        )
        
        job_run_id = job.execute(get_current_context())
        
        end_time = time.time()
        duration = end_time - start_time
        
        logging.info(f"File copy completed in {timedelta(seconds=duration)}")
        
        context["task_instance"].xcom_push(key="copy_job_run_id", value=job_run_id)
        context["task_instance"].xcom_push(key="copy_duration", value=duration)
        
        return f"File copy completed: {job_run_id}"

    def send_success_email(**context):
        """Send comprehensive success email notification"""
        from airflow.operators.email import EmailOperator
        
        execution_date = context["execution_date"]
        month_name = execution_date.strftime("%B_%Y")
        
        # Get timing information
        workflow_start_time = context["task_instance"].xcom_pull(key="workflow_start_time", task_ids="create_script_arguments")
        current_time = time.time()
        total_duration = current_time - workflow_start_time
        
        # Get individual stage durations
        module1_duration = context["task_instance"].xcom_pull(key="module1_duration", task_ids="run_module1") or 0
        minmax_duration = context["task_instance"].xcom_pull(key="minmax_duration", task_ids="run_minmax_processing") or 0
        excel_duration = context["task_instance"].xcom_pull(key="excel_duration", task_ids="run_excel_conversion") or 0
        comparison_duration = context["task_instance"].xcom_pull(key="comparison_duration", task_ids="run_comparison_processing") or 0
        copy_duration = context["task_instance"].xcom_pull(key="copy_duration", task_ids="copy_to_final_output") or 0
        
        # Get copied files list
        copied_files = context["task_instance"].xcom_pull(key="copied_files", task_ids="copy_to_local_temp") or []
        
        # Get input files for summary
        input_files = context["task_instance"].xcom_pull(key="AE_INPUT_FILES", task_ids="create_script_arguments")
        existing_files = context["task_instance"].xcom_pull(key="existing_files", task_ids="create_script_arguments")
        
        # Format durations
        def format_duration(seconds):
            hours = int(seconds // 3600)
            minutes = int((seconds % 3600) // 60)
            secs = int(seconds % 60)
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        
        # Create comprehensive summary like shell script
        input_files_summary = "INPUT FILES PROCESSED:\n"
        file_mapping = {
            "digital_taxonomy_input": "Digital Taxonomy",
            "experian_match_input": "Experian Match", 
            "pam_directory_input": "PAM Directory",
            "cbaf_utility_input": "CBAF Utility",
            "utility_input": "Utility",
            "counties_lookup_input": "Counties Lookup",
            "match_output_input": "Match Output"
        }
        
        for file_key in existing_files:
            if file_key in file_mapping and file_key in input_files:
                file_path = input_files[file_key]
                file_name = file_path.split('/')[-1] if '/' in file_path else file_path
                input_files_summary += f"- {file_mapping[file_key]}: {file_name}\n"
        
        output_files_summary = "FILES COPIED AND PROCESSED:\n"
        for file_name in copied_files:
            output_files_summary += f"✅ {file_name}\n"
        
        email_body = f"""Audience Engine Pipeline - COMPLETE SUMMARY for {month_name}
==================================================
🎉 Pipeline execution completed successfully

Execution ID: {datetime.now().strftime("%Y%m%d_%H%M%S")}
Start time: {datetime.fromtimestamp(workflow_start_time).strftime('%Y-%m-%d %H:%M:%S')}
End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Total duration: {format_duration(total_duration)} ({int(total_duration)}s)

STAGE DURATIONS:
✅ File Validation: Completed successfully
✅ Stage 1 (Module 1): {format_duration(module1_duration)} ({int(module1_duration)}s)
✅ Stage 2 (MinMax Analysis): {format_duration(minmax_duration)} ({int(minmax_duration)}s)
✅ Stage 3 (Excel Conversion): {format_duration(excel_duration)} ({int(excel_duration)}s)
✅ Stage 4 (Comparison): {format_duration(comparison_duration)} ({int(comparison_duration)}s)
✅ Stage 5 (File Copying): {format_duration(copy_duration)} ({int(copy_duration)}s)

{input_files_summary}

OUTPUT LOCATIONS:
✅ Final Output Directory: Available in S3 output bucket
✅ All merged files copied and processed successfully
✅ Excel files generated with proper formatting

{output_files_summary}

🔍 All output files have been processed and are available for downstream consumption
📊 Excel files are available with appropriate statistical analysis
📝 All execution logs are preserved for troubleshooting and audit purposes

Pipeline execution completed successfully! 🚀
"""
        
        email_op = EmailOperator(
            task_id="send_success_email",
            to=["kallusrujan.reddy@experian.com"],
            subject=f"[AUDIENCE ENGINE] COMPLETED SUCCESSFULLY - {month_name} Pipeline",
            html_content=email_body.replace('\n', '<br>'),
            dag=context['dag']
        )
        
        email_op.execute(context=context)
        logging.info("Sent pipeline success email notification")

    def send_failure_email(**context):
        """Send failure email notification"""
        from airflow.operators.email import EmailOperator
        
        execution_date = context["execution_date"]
        month_name = execution_date.strftime("%B_%Y")
        
        # Get the failed task information
        failed_task = context.get('task_instance')
        task_id = failed_task.task_id if failed_task else "Unknown"
        
        email_body = f"""Audience Engine Pipeline - FAILED for {month_name}
==================================================
❌ PIPELINE EXECUTION FAILED

The pipeline has failed during execution and requires attention.

Failed task: {task_id}
Failure time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Month: {month_name}

Please check the Airflow logs for detailed error information.
The pipeline will need to be restarted after resolving the issue.

Contact the data engineering team for assistance if needed.
"""
        
        email_op = EmailOperator(
            task_id="send_failure_email",
            to=["kallusrujan.reddy@experian.com"],
            subject=f"[AUDIENCE ENGINE] FAILED - {month_name} Pipeline",
            html_content=email_body.replace('\n', '<br>'),
            dag=context['dag']
        )
        
        email_op.execute(context=context)
        logging.info("Sent pipeline failure email notification")

    def cleanup_emr_application(**context):
        """Clean up EMR Serverless application"""
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        if app_id:
            logging.info(f"Cleaning up EMR application: {app_id}")
            try:
                delete_emr_application(context, app_id)
                logging.info(f"Successfully deleted EMR application: {app_id}")
            except Exception as e:
                logging.warning(f"Could not delete EMR application {app_id}: {e}")
        else:
            logging.warning("No EMR application ID found for cleanup")
        
        return "EMR cleanup completed"

    def send_input_stats_email(**context):
        """Send consolidated input stats email after all stats collection"""
        import boto3
        import tempfile
        import os

        stats_bucket = context["task_instance"].xcom_pull(key="stats_bucket", task_ids="create_script_arguments")
        execution_date = context["task_instance"].xcom_pull(key="execution_date", task_ids="create_script_arguments")
        
        # Calculate week start date
        current_date = datetime.strptime(execution_date, "%Y-%m-%d")
        week_start_date = (current_date - timedelta(days=current_date.weekday())).strftime("%Y-%m-%d")
        if current_date.weekday() == 0:
            week_start_date = execution_date
        
        logging.info(f"Sending consolidated input stats email for date: {execution_date}, week start: {week_start_date}")
        
        # Set recipients
        recipients = ['kallusrujan.reddy@experian.com']
        
        try:
            # Initialize S3 client
            s3 = boto3.client('s3')
            
            # Check for consolidated email JSON data first
            email_data_path = f"get_stats/{week_start_date}/email_data_weekly_{week_start_date}.json"
            try:
                logging.info(f"Looking for consolidated email JSON data at {email_data_path}")
                email_response = s3.get_object(Bucket=stats_bucket, Key=email_data_path)
                email_data = json.loads(email_response['Body'].read().decode('utf-8'))
                
                # Send consolidated stats email
                email_subject = f"*** Audience Engine Input Statistics *** - {execution_date}"
                email_content = email_data.get('html_content', f"<p>No detailed statistics available for {execution_date}</p>")
                
                stats_email = EmailOperator(
                    task_id="send_input_stats_email_json",
                    to=recipients,
                    subject=email_subject,
                    html_content=email_content,
                    dag=context['dag']
                )
                
                stats_email.execute(context=context)
                logging.info(f"Sent consolidated input stats email using JSON data")
                
                return f"Sent consolidated input stats email for {execution_date} using JSON data"
                
            except Exception as json_err:
                logging.warning(f"No email JSON found, trying CSV file: {str(json_err)}")
                
                # FALLBACK: Try the consolidated CSV file
                stats_file_key = f"get_stats/{week_start_date}/pipeline_stats__{week_start_date}.csv"
                try:
                    logging.info(f"Looking for consolidated CSV file at {stats_file_key}")
                    with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as temp_file:
                        s3.download_fileobj(stats_bucket, stats_file_key, temp_file)
                        temp_file_path = temp_file.name
                    
                    # Send the email with CSV attachment
                    email_op = EmailOperator(
                        task_id="send_input_stats_email_with_attachment",
                        to=recipients,
                        subject=f"*** Audience Engine Input Statistics *** - {execution_date}",
                        html_content=f"""
                        <h2>Audience Engine Input Statistics Report - {execution_date}</h2>
                        <p>Please find attached the consolidated input statistics report covering all major input files:</p>
                        <ul>
                            <li>Digital Taxonomy - Main input file</li>
                            <li>Experian Match - Matched IDs</li>
                            <li>PAM Directory - Address data</li>
                            <li>CBAF Utility - Utility data</li>
                            <li>Utility - Additional utility data</li>
                            <li>Counties Lookup - Geography mapping</li>
                            <li>Match Output - Output matching</li>
                        </ul>
                        <p><em>This is an automated message from the Audience Engine processing system.</em></p>
                        """,
                        files=[temp_file_path],
                        dag=context['dag']
                    )
                    
                    email_op.execute(context=context)
                    
                    # Clean up the temporary file
                    os.unlink(temp_file_path)
                    
                    logging.info(f"Sent consolidated input stats email with CSV attachment")
                    return f"Sent consolidated input stats email with CSV attachment for {execution_date}"
                    
                except Exception as csv_err:
                    logging.warning(f"Error with CSV file: {str(csv_err)}")
                    
                    # LAST RESORT: Send basic email
                    basic_email = EmailOperator(
                        task_id="send_basic_input_email",
                        to=recipients,
                        subject=f"*** Audience Engine Input Statistics Summary *** - {execution_date}",
                        html_content=f"""
                        <h2>Audience Engine Input Statistics Summary</h2>
                        <p>Input statistics were collected for {execution_date} covering all major input files.</p>
                        <p>Statistics were collected for: Digital Taxonomy, Experian Match, PAM Directory, CBAF Utility, Utility, Counties Lookup, and Match Output files.</p>
                        <p>Please check the logs for more details.</p>
                        <p><em>This is an automated message from the Audience Engine processing system.</em></p>
                        """,
                        dag=context['dag']
                    )
                    
                    basic_email.execute(context=context)
                    logging.info(f"Sent basic input stats email")
                    
                    return f"Sent basic input stats email for {execution_date}"
                    
        except Exception as e:
            logging.error(f"Error sending consolidated input stats email: {str(e)}")
            return f"Error sending consolidated input stats email: {str(e)}"

    # =====================================================================
    # DAG TASK DEFINITIONS
    # =====================================================================

    # Task 1: Create script arguments and validate environment
    create_args_task = PythonOperator(
        task_id="create_script_arguments",
        python_callable=create_script_arguments,
        dag=dag,
    )

    # Task 2: Initialize EMR Serverless application
    initialise_task = PythonOperator(
        task_id="initialise",
        python_callable=initialise,
        dag=dag,
    )

    # Task 3: Check if all input files exist
    check_inputs_task = PythonOperator(
        task_id="check_inputs_exist",
        python_callable=check_inputs_exist,
        dag=dag,
    )

    # Stats collection tasks for all input files (SEQUENTIAL execution like shell script)
    collect_digital_taxonomy_stats_task = PythonOperator(
        task_id="collect_digital_taxonomy_stats",
        python_callable=collect_digital_taxonomy_stats,
        dag=dag,
    )

    collect_experian_match_stats_task = PythonOperator(
        task_id="collect_experian_match_stats",
        python_callable=collect_experian_match_stats,
        dag=dag,
    )

    collect_pam_directory_stats_task = PythonOperator(
        task_id="collect_pam_directory_stats",
        python_callable=collect_pam_directory_stats,
        dag=dag,
    )

    collect_cbaf_utility_stats_task = PythonOperator(
        task_id="collect_cbaf_utility_stats",
        python_callable=collect_cbaf_utility_stats,
        dag=dag,
    )

    collect_utility_stats_task = PythonOperator(
        task_id="collect_utility_stats",
        python_callable=collect_utility_stats,
        dag=dag,
    )

    collect_counties_lookup_stats_task = PythonOperator(
        task_id="collect_counties_lookup_stats",
        python_callable=collect_counties_lookup_stats,
        dag=dag,
    )

    collect_match_output_stats_task = PythonOperator(
        task_id="collect_match_output_stats",
        python_callable=collect_match_output_stats,
        dag=dag,
    )

    # Send input stats email after all stats collection
    send_input_stats_email_task = PythonOperator(
        task_id="send_input_stats_email",
        python_callable=send_input_stats_email,
        dag=dag,
    )

    # Processing tasks (SEQUENTIAL like shell script)
    run_module1_task = PythonOperator(
        task_id="run_module1",
        python_callable=run_module1,
        dag=dag,
    )

    run_minmax_task = PythonOperator(
        task_id="run_minmax_processing",
        python_callable=run_minmax_processing,
        dag=dag,
    )

    run_excel_task = PythonOperator(
        task_id="run_excel_conversion",
        python_callable=run_excel_conversion,
        dag=dag,
    )

    run_comparison_task = PythonOperator(
        task_id="run_comparison_processing",
        python_callable=run_comparison_processing,
        dag=dag,
    )

    copy_local_temp_task = PythonOperator(
        task_id="copy_to_local_temp",
        python_callable=copy_to_local_temp,
        dag=dag,
    )

    # Email notification tasks
    send_success_email_task = PythonOperator(
        task_id="send_success_email",
        python_callable=send_success_email,
        dag=dag,
        trigger_rule="all_success"
    )

    send_failure_email_task = PythonOperator(
        task_id="send_failure_email",
        python_callable=send_failure_email,
        dag=dag,
        trigger_rule="one_failed"
    )

    # Cleanup task
    cleanup_task = PythonOperator(
        task_id="cleanup_emr_application",
        python_callable=cleanup_emr_application,
        dag=dag,
        trigger_rule="all_done"  # Always run cleanup
    )

    # =====================================================================
    # DAG TASK DEPENDENCIES - SEQUENTIAL LIKE SHELL SCRIPT
    # =====================================================================

    # Step 1: Sequential initialization
    create_args_task >> initialise_task >> check_inputs_task >> send_input_stats_email_task

    # # Step 2: Sequential stats collection (line by line like shell script)
    # check_inputs_task >> collect_digital_taxonomy_stats_task
    # collect_digital_taxonomy_stats_task >> collect_experian_match_stats_task
    # collect_experian_match_stats_task >> collect_pam_directory_stats_task
    # collect_pam_directory_stats_task >> collect_cbaf_utility_stats_task
    # collect_cbaf_utility_stats_task >> collect_utility_stats_task
    # collect_utility_stats_task >> collect_counties_lookup_stats_task
    # collect_counties_lookup_stats_task >> collect_match_output_stats_task

    # # Step 3: Send stats email after all stats collection
    # collect_match_output_stats_task >> send_input_stats_email_task

    # Step 4: Sequential main processing (like shell script stages)
    # send_input_stats_email_task >> run_module1_task
    # run_module1_task >> run_minmax_task

    send_input_stats_email_task >> run_minmax_task

    run_minmax_task >> run_excel_task
    run_excel_task >> run_comparison_task
    run_comparison_task >> copy_local_temp_task

    # Step 5: Success email
    copy_local_temp_task >> send_success_email_task

    # Step 6: Failure email - connects to ALL tasks that can fail
    create_args_task >> send_failure_email_task
    initialise_task >> send_failure_email_task
    check_inputs_task >> send_failure_email_task
    # collect_digital_taxonomy_stats_task >> send_failure_email_task
    # collect_experian_match_stats_task >> send_failure_email_task
    # collect_pam_directory_stats_task >> send_failure_email_task
    # collect_cbaf_utility_stats_task >> send_failure_email_task
    # collect_utility_stats_task >> send_failure_email_task
    # collect_counties_lookup_stats_task >> send_failure_email_task
    # collect_match_output_stats_task >> send_failure_email_task
    # send_input_stats_email_task >> send_failure_email_task
    run_module1_task >> send_failure_email_task
    run_minmax_task >> send_failure_email_task
    run_excel_task >> send_failure_email_task
    run_comparison_task >> send_failure_email_task
    copy_local_temp_task >> send_failure_email_task

    # Step 7: Cleanup always runs at the end
    [send_success_email_task, send_failure_email_task] >> cleanup_task