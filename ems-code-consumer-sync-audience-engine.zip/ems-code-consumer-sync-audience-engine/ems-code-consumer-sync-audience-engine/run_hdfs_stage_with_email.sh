
#!/bin/bash

# =====================================================================
# =====================================================================
# AUDIENCE ENGINE PRODUCTION PIPELINE - ENHANCED VERSION
# =====================================================================

set -e          
set -o pipefail 
trap 'handle_error $? $LINENO' ERR 

# =====================================================================
# CONFIGURATION SECTION - CUSTOMIZE AS NEEDED
# =====================================================================

# Base paths
DATA_BASE_DIR="/user/unity/audience_engine/data"
OUTPUT_BASE_DIR="/user/unity/audience_engine/output"
LOCAL_TEMP_BASE="/data/data_to_sts/temp/audience_engine"

# Script paths
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SCRIPTS_DIR="$SCRIPT_DIR/Scripts"

# Email configuration
EMAIL_FROM="idg_process_monitor@experian.com"
EMAIL_TO="kallusrujan.reddy@experian.com"
EMAIL_CC="" # Add additional recipients as needed
EMAIL_SUBJECT_PREFIX="[AUDIENCE ENGINE]"


QUEUE="andy"

# File naming patterns - EXACT MATCH REQUIRED
DIGITAL_TAXONOMY_PATTERN="*_Digital_taxonomy*.txt"
EXPERIAN_MATCH_PATTERN="Experian_matched_IDs_*.csv"
PAM_DIRECTORY_PATTERN="F03.PAMDirectory*.csv"
CBAF_UTILITY_PATTERN="F45.*.cbaf_utility*.csv"
UTILITY_PATTERN="A16_*_cbaf_utility*.csv"
COUNTIES_LOOKUP_PATTERN="Counties_Lookup*.xlsx"
MATCH_OUTPUT_PATTERN="MatchOutputFile*.csv"

# =====================================================================
# LOGGING AND ERROR HANDLING
# =====================================================================

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
CURRENT_MONTH=$(date +"%Y_%m")
CURRENT_MONTH_NAME=$(date +"%B_%Y")

# Enhanced logging setup
MAIN_LOG_DIR="$SCRIPT_DIR/logs"
EXECUTION_LOG_DIR="$MAIN_LOG_DIR/execution_$TIMESTAMP"
mkdir -p "$EXECUTION_LOG_DIR"

# Main pipeline log - this will contain all logs from all modules
MAIN_LOG_FILE="$EXECUTION_LOG_DIR/pipeline_main_${TIMESTAMP}.log"

# Individual module logs - these will be passed to each script
MODULE1_LOG_FILE="$EXECUTION_LOG_DIR/module1_${TIMESTAMP}.log"
MINMAX_LOG_FILE="$EXECUTION_LOG_DIR/minmax_${TIMESTAMP}.log"
MODULE3_LOG_FILE="$EXECUTION_LOG_DIR/module3_${TIMESTAMP}.log"
EXCEL_LOG_FILE="$EXECUTION_LOG_DIR/excel_builder_${TIMESTAMP}.log"

# Set up HDFS paths
HDFS_MONTH_DIR="${OUTPUT_BASE_DIR}/${CURRENT_MONTH}"
HDFS_OUTPUT_DIR="${HDFS_MONTH_DIR}/${TIMESTAMP}"

# Set up local temp paths
LOCAL_TEMP_DIR="${LOCAL_TEMP_BASE}/${TIMESTAMP}"
LOCAL_TMP_DIR="/tmp/${TIMESTAMP}"

# Function to log messages with enhanced formatting
log() {
    local level="$1"
    local message="$2"
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    local log_entry="[$timestamp] [$level] $message"
    
    # Action 1: Write plain text to the main log file.
    echo "$log_entry" >> "$MAIN_LOG_FILE"
    
    # Action 2: Print to the screen (with color).
    case "$level" in
        "ERROR")
            echo -e "\033[31m$log_entry\033[0m" ;;
        "WARNING")
            echo -e "\033[33m$log_entry\033[0m" ;;
        "SUCCESS")
            echo -e "\033[32m$log_entry\033[0m" ;;
        *)
            echo "$log_entry" ;;
    esac
}

# Function to handle errors
handle_error() {
    local exit_code=$1
    local line_number=$2
    local command=$(sed -n "${line_number}p" "$0")
    
    log "ERROR" "Command failed (exit code $exit_code): $command at line $line_number"
    
    # Send email notification about the error
    EMAIL_BODY="Audience Engine Pipeline - CRITICAL ERROR
==================================================
ERROR DETAILS:
- Exit Code: $exit_code
- Line Number: $line_number
- Command: $command
- Timestamp: $(date)
- Execution ID: $TIMESTAMP

The pipeline has been stopped due to an error.
Please check the logs for more details:
- Main log: $MAIN_LOG_FILE
- Log directory: $EXECUTION_LOG_DIR

Current execution status:
- Current step: $CURRENT_STEP
- Last completed step: $LAST_COMPLETED_STEP

All logs are saved in: $EXECUTION_LOG_DIR
"
    send_email "$EMAIL_SUBJECT_PREFIX CRITICAL ERROR - Pipeline Failed" "$EMAIL_BODY"
    
    # Create error summary file
    echo "Pipeline execution failed at $(date)" > "$EXECUTION_LOG_DIR/EXECUTION_FAILED.txt"
    echo "Error code: $exit_code" >> "$EXECUTION_LOG_DIR/EXECUTION_FAILED.txt"
    echo "Failed at line: $line_number" >> "$EXECUTION_LOG_DIR/EXECUTION_FAILED.txt"
    
    exit $exit_code
}

# Format time in hours:minutes:seconds
format_time() {
    local seconds=$1
    local hours=$((seconds / 3600))
    local minutes=$(( (seconds % 3600) / 60 ))
    local secs=$((seconds % 60))
    printf "%02d:%02d:%02d" $hours $minutes $secs
}

# Function to send email notifications
send_email() {
    local subject="$1"
    local body="$2"
    
    echo "$body" | mailx -r "$EMAIL_FROM" -s "$subject" -c "$EMAIL_CC" "$EMAIL_TO"
    log "INFO" "Email sent: $subject"
}

# =====================================================================
# ENHANCED FILE DETECTION AND VALIDATION
# =====================================================================

# Function to find and validate required files
find_and_validate_files() {
    local base_dir="$1"
    local current_month_dir="${base_dir}/${CURRENT_MONTH}"
    
    log "INFO" "Starting comprehensive file detection and validation"
    log "INFO" "Base directory: $base_dir"
    log "INFO" "Current month directory: $current_month_dir"
    
    # Check if current month directory exists
    if ! hdfs dfs -test -d "$current_month_dir" 2>/dev/null; then
        log "ERROR" "Current month directory does not exist: $current_month_dir"
        return 1
    fi
    
    # Initialize file tracking
    declare -A REQUIRED_FILES
    declare -A FOUND_FILES
    declare -A FILE_DETAILS
    
    # Define required file patterns
    REQUIRED_FILES["DIGITAL_TAXONOMY"]="$DIGITAL_TAXONOMY_PATTERN"
    REQUIRED_FILES["EXPERIAN_MATCH"]="$EXPERIAN_MATCH_PATTERN"
    REQUIRED_FILES["PAM_DIRECTORY"]="$PAM_DIRECTORY_PATTERN"
    REQUIRED_FILES["CBAF_UTILITY"]="$CBAF_UTILITY_PATTERN"
    REQUIRED_FILES["UTILITY"]="$UTILITY_PATTERN"
    REQUIRED_FILES["COUNTIES_LOOKUP"]="$COUNTIES_LOOKUP_PATTERN"
    REQUIRED_FILES["MATCH_OUTPUT"]="$MATCH_OUTPUT_PATTERN"
    
    log "INFO" "Searching for required files in: $current_month_dir"
    
    # Search for each required file type
    local all_files_found=true
    
    for file_type in "${!REQUIRED_FILES[@]}"; do
        local pattern="${REQUIRED_FILES[$file_type]}"
        log "INFO" "Searching for $file_type with pattern: $pattern"
        
        # Use hdfs dfs -ls to find files matching pattern
        local found_files=$(hdfs dfs -ls "$current_month_dir/$pattern" 2>/dev/null | grep -v "^d" | awk '{print $8}' | head -10)
        
        if [ -z "$found_files" ]; then
            log "ERROR" "No files found for $file_type (pattern: $pattern) in $current_month_dir"
            all_files_found=false
            continue
        fi
        
        # Get the most recent file (by timestamp in filename or modification time)
        local latest_file=$(echo "$found_files" | sort -r | head -1)
        
        # Validate file exists and get details
        if hdfs dfs -test -e "$latest_file" 2>/dev/null; then
            # Get file size and modification time
            local file_info=$(hdfs dfs -ls "$latest_file" 2>/dev/null)
            local file_size=$(echo "$file_info" | awk '{print $5}')
            local file_date=$(echo "$file_info" | awk '{print $6, $7}')
            
            # Check if file is not empty
            if [ "$file_size" -eq 0 ]; then
                log "ERROR" "$file_type file is empty: $latest_file"
                all_files_found=false
                continue
            fi
            
            FOUND_FILES[$file_type]="$latest_file"
            FILE_DETAILS[$file_type]="Size: $file_size bytes, Modified: $file_date"
            log "SUCCESS" "Found $file_type: $(basename $latest_file) ($file_size bytes)"
        else
            log "ERROR" "File exists in listing but not accessible: $latest_file"
            all_files_found=false
        fi
    done
    
    # Check for previous comparison file
    log "INFO" "Searching for previous month's comparison file"
    local prev_month=$(date -d "last month" +"%Y_%m")
    local prev_month_dir="${OUTPUT_BASE_DIR}/${prev_month}"
    
    local prev_file=$(hdfs dfs -ls -t "$prev_month_dir/*/minmax_output/*.xlsx" 2>/dev/null | head -1 | awk '{print $8}')
    
    if [ -n "$prev_file" ] && hdfs dfs -test -e "$prev_file" 2>/dev/null; then
        FOUND_FILES["PREVIOUS_COMPARISON"]="$prev_file"
        local prev_file_info=$(hdfs dfs -ls "$prev_file" 2>/dev/null)
        local prev_file_size=$(echo "$prev_file_info" | awk '{print $5}')
        local prev_file_date=$(echo "$prev_file_info" | awk '{print $6, $7}')
        FILE_DETAILS["PREVIOUS_COMPARISON"]="Size: $prev_file_size bytes, Modified: $prev_file_date"
        log "SUCCESS" "Found previous comparison file: $(basename $prev_file)"
    else
        log "WARNING" "No previous comparison file found in $prev_month_dir"
        log "WARNING" "This might be the first run or previous month's data is missing"
        FOUND_FILES["PREVIOUS_COMPARISON"]=""
    fi
    
    # Generate comprehensive file validation report
    log "INFO" "=== FILE VALIDATION SUMMARY ==="
    for file_type in "${!REQUIRED_FILES[@]}"; do
        if [ -n "${FOUND_FILES[$file_type]:-}" ]; then
            log "SUCCESS" "$file_type: ✓ ${FOUND_FILES[$file_type]}"
            log "INFO" "  Details: ${FILE_DETAILS[$file_type]}"
        else
            log "ERROR" "$file_type: ✗ NOT FOUND"
        fi
    done
    
    if [ -n "${FOUND_FILES[PREVIOUS_COMPARISON]:-}" ]; then
        log "SUCCESS" "PREVIOUS_COMPARISON: ✓ ${FOUND_FILES[PREVIOUS_COMPARISON]}"
        log "INFO" "  Details: ${FILE_DETAILS[PREVIOUS_COMPARISON]}"
    else
        log "WARNING" "PREVIOUS_COMPARISON: ⚠ NOT FOUND (Will proceed without comparison)"
    fi
    
    # Set global variables for found files
    DIGITAL_TAXONOMY_FILE="${FOUND_FILES[DIGITAL_TAXONOMY]:-}"
    EXPERIAN_MATCH_FILE="${FOUND_FILES[EXPERIAN_MATCH]:-}"
    PAM_DIRECTORY_FILE="${FOUND_FILES[PAM_DIRECTORY]:-}"
    CBAF_UTILITY_FILE="${FOUND_FILES[CBAF_UTILITY]:-}"
    UTILITY_FILE="${FOUND_FILES[UTILITY]:-}"
    COUNTIES_LOOKUP_FILE="${FOUND_FILES[COUNTIES_LOOKUP]:-}"
    MATCH_OUTPUT_FILE="${FOUND_FILES[MATCH_OUTPUT]:-}"
    PREVIOUS_FILE="${FOUND_FILES[PREVIOUS_COMPARISON]:-}"
    
    # Final validation
    if [ "$all_files_found" = true ]; then
        log "SUCCESS" "All required files found and validated successfully"
        
        # Create file inventory
        cat > "$EXECUTION_LOG_DIR/file_inventory.txt" << EOF
Audience Engine Pipeline - File Inventory
Generated: $(date)
Execution ID: $TIMESTAMP

=== REQUIRED INPUT FILES ===
EOF
        
        for file_type in "${!FOUND_FILES[@]}"; do
            if [ "$file_type" != "PREVIOUS_COMPARISON" ] && [ -n "${FOUND_FILES[$file_type]:-}" ]; then
                echo "$file_type: ${FOUND_FILES[$file_type]}" >> "$EXECUTION_LOG_DIR/file_inventory.txt"
                echo "  ${FILE_DETAILS[$file_type]}" >> "$EXECUTION_LOG_DIR/file_inventory.txt"
                echo "" >> "$EXECUTION_LOG_DIR/file_inventory.txt"
            fi
        done
        
        if [ -n "${FOUND_FILES[PREVIOUS_COMPARISON]:-}" ]; then
            echo "=== PREVIOUS COMPARISON FILE ===" >> "$EXECUTION_LOG_DIR/file_inventory.txt"
            echo "PREVIOUS_COMPARISON: ${FOUND_FILES[PREVIOUS_COMPARISON]}" >> "$EXECUTION_LOG_DIR/file_inventory.txt"
            echo "  ${FILE_DETAILS[PREVIOUS_COMPARISON]}" >> "$EXECUTION_LOG_DIR/file_inventory.txt"
        else
            echo "=== PREVIOUS COMPARISON FILE ===" >> "$EXECUTION_LOG_DIR/file_inventory.txt"
            echo "PREVIOUS_COMPARISON: NOT FOUND (First run or missing previous data)" >> "$EXECUTION_LOG_DIR/file_inventory.txt"
        fi
        
        return 0
    else
        log "ERROR" "File validation failed - missing required files"
        return 1
    fi
}

# =====================================================================
# FILE COPYING FUNCTIONS
# =====================================================================

# Function to copy output files to local temp directories
copy_to_local_temp() {
    local hdfs_output_dir="$1"
    
    log "INFO" "Starting copy to local temp directories using getmerge"
    
    # Create local temp directories
    mkdir -p "$LOCAL_TEMP_DIR"
    mkdir -p "$LOCAL_TMP_DIR"
    chmod 777 "$LOCAL_TMP_DIR"
    
    # Generate dynamic file suffix (Month+YY_Supply)
    local file_suffix=$(date '+%B%y' | sed 's/ //g')_Supply  # e.g. July25_Supply
    
    # Define dynamic filenames
    local audience_file="Digital_taxonomy_Audience_Engine_${file_suffix}.txt"
    local count_file="Digital_taxonomy_Count_${file_suffix}.txt"
    
    # Files to merge
    local files_to_merge=(
        "counties_check.csv"
        "Adsmart_liveramp_files_used.xlsx"
        "$audience_file"
        "$count_file"
    )
    
    # Process all other files using getmerge
    for file_name in "${files_to_merge[@]}"; do
        log "INFO" "Processing and merging: $file_name"
        local hdfs_path=$(hdfs dfs -ls "$hdfs_output_dir/module1_output" | grep "$file_name" | head -1 | awk '{print $8}')

        if [ -n "$hdfs_path" ]; then
            if hdfs dfs -test -d "$hdfs_path"; then
                # It's a directory with parts, use getmerge
                hdfs dfs -getmerge -skip-empty-file "$hdfs_path" "$LOCAL_TEMP_DIR/$file_name"
                log "SUCCESS" "Merged directory parts to single file: $file_name"
            else
                # It's already a single file, copy directly
                hdfs dfs -get "$hdfs_path" "$LOCAL_TEMP_DIR/$file_name"
                log "SUCCESS" "Copied single file: $file_name"
            fi
        else
            log "WARNING" "File/directory not found: $file_name"
        fi
    done
    
    # Copy Excel files to both directories
    log "INFO" "Copying Excel files to local directories"
    
    # Find and copy minmax Excel file
    local minmax_excel=$(hdfs dfs -ls "$hdfs_output_dir/minmax_output" | grep ".xlsx" | head -1 | awk '{print $8}')
    if [ -n "$minmax_excel" ]; then
        hdfs dfs -get "$minmax_excel" "$LOCAL_TEMP_DIR/"
        hdfs dfs -get "$minmax_excel" "$LOCAL_TMP_DIR/"
        log "SUCCESS" "Copied MinMax Excel: $(basename $minmax_excel)"
    fi
    
    # Find and copy comparison Excel file
    local comparison_excel=$(hdfs dfs -ls "$hdfs_output_dir/comparison_output" | grep ".xlsx" | head -1 | awk '{print $8}')
    if [ -n "$comparison_excel" ]; then
        hdfs dfs -get "$comparison_excel" "$LOCAL_TEMP_DIR/"
        hdfs dfs -get "$comparison_excel" "$LOCAL_TMP_DIR/"
        log "SUCCESS" "Copied Comparison Excel: $(basename $comparison_excel)"
    fi
    
    # Set permissions
    chmod -R 755 "$LOCAL_TEMP_DIR"
    chmod 777 "$LOCAL_TMP_DIR"/*
    
    log "SUCCESS" "Local temp copy completed using getmerge"
    log "INFO" "Files copied to: $LOCAL_TEMP_DIR"
    log "INFO" "Excel files copied to: $LOCAL_TMP_DIR (with 777 permissions)"
    
    return 0
}

# =====================================================================
# INITIALIZATION
# =====================================================================

log "INFO" "Starting Audience Engine Pipeline (Execution ID: $TIMESTAMP)"
log "INFO" "Processing month: $CURRENT_MONTH_NAME"
log "INFO" "Main log file: $MAIN_LOG_FILE"
log "INFO" "Execution log directory: $EXECUTION_LOG_DIR"

# Current and last completed step tracking
CURRENT_STEP="Initialization"
LAST_COMPLETED_STEP="None"

# Create HDFS directories
log "INFO" "Creating HDFS output directories"
hdfs dfs -mkdir -p $HDFS_OUTPUT_DIR/module1_output
hdfs dfs -mkdir -p $HDFS_OUTPUT_DIR/minmax_output
hdfs dfs -mkdir -p $HDFS_OUTPUT_DIR/comparison_output

# =====================================================================
# ENHANCED FILE DETECTION AND VALIDATION
# =====================================================================

CURRENT_STEP="File Detection and Validation"
log "INFO" "=== STARTING FILE DETECTION AND VALIDATION ==="

if ! find_and_validate_files "$DATA_BASE_DIR"; then
    log "ERROR" "File validation failed. Cannot proceed with pipeline execution."
    
    # Send detailed failure email
    EMAIL_BODY="Audience Engine Pipeline - FILE VALIDATION FAILED
==================================================
FILE VALIDATION FAILED - CANNOT PROCEED

The pipeline cannot start because required input files are missing or invalid.

Expected location: $DATA_BASE_DIR/$CURRENT_MONTH/

Missing or invalid files were detected during validation.
Please check the detailed logs for specific file issues:
- Main log: $MAIN_LOG_FILE
- Log directory: $EXECUTION_LOG_DIR

REQUIRED FILES:
- Digital Taxonomy: $DIGITAL_TAXONOMY_PATTERN
- Experian Match: $EXPERIAN_MATCH_PATTERN  
- PAM Directory: $PAM_DIRECTORY_PATTERN
- CBAF Utility: $CBAF_UTILITY_PATTERN
- Utility: $UTILITY_PATTERN
- Counties Lookup: $COUNTIES_LOOKUP_PATTERN
- Match Output: $MATCH_OUTPUT_PATTERN

Please ensure all required files are available in the correct location and retry.
"
    send_email "$EMAIL_SUBJECT_PREFIX FILE VALIDATION FAILED - Cannot Start Pipeline" "$EMAIL_BODY"
    exit 1
fi

LAST_COMPLETED_STEP="File Detection and Validation"

# =====================================================================
# PIPELINE START - SEND INITIAL NOTIFICATION WITH FILE DETAILS
# =====================================================================

PIPELINE_START_TIME=$(date +%s)

# Log input files with full details
log "INFO" "=== VALIDATED INPUT CONFIGURATION ==="
log "INFO" "- Digital Taxonomy: $DIGITAL_TAXONOMY_FILE"
log "INFO" "- Experian Match: $EXPERIAN_MATCH_FILE"
log "INFO" "- PAM Directory: $PAM_DIRECTORY_FILE"
log "INFO" "- CBAF Utility: $CBAF_UTILITY_FILE"
log "INFO" "- Utility: $UTILITY_FILE"
log "INFO" "- Counties Lookup: $COUNTIES_LOOKUP_FILE"
log "INFO" "- Match Output File: $MATCH_OUTPUT_FILE"
log "INFO" "- Previous File: $PREVIOUS_FILE"
log "INFO" "- Output Directory: $HDFS_OUTPUT_DIR"

# Read file inventory for email
FILE_INVENTORY=$(cat "$EXECUTION_LOG_DIR/file_inventory.txt")

# Send comprehensive initial email notification
EMAIL_BODY="Audience Engine Pipeline - STARTED for $CURRENT_MONTH_NAME
==================================================
✅ ALL REQUIRED FILES VALIDATED SUCCESSFULLY

Pipeline execution has started with validated input files.
Start time: $(date)
Execution ID: $TIMESTAMP
Month: $CURRENT_MONTH_NAME

$FILE_INVENTORY

Output Structure:
- HDFS Output: $HDFS_OUTPUT_DIR
- Log Directory: $EXECUTION_LOG_DIR

The pipeline will now proceed with Module 1 processing.
You will receive progress updates for each major stage.
"

send_email "$EMAIL_SUBJECT_PREFIX STARTED - $CURRENT_MONTH_NAME Pipeline (All Files Validated)" "$EMAIL_BODY"

# =====================================================================
# STEP 1: Run new_module1.py for initial data processing
# =====================================================================

CURRENT_STEP="Module 1 Processing"
log "INFO" "=== STEP 1: STARTING MODULE 1 DATA PROCESSING ==="
STEP1_START_TIME=$(date +%s)

# Run with validated input files and enhanced logging
spark-submit \
    --master yarn \
    --queue $QUEUE \
    --files "$SCRIPTS_DIR/config.py,$SCRIPTS_DIR/functions.py,$SCRIPTS_DIR/log.py" \
    "$SCRIPTS_DIR/new_module1.py" \
    --digital_taxonomy_file "$DIGITAL_TAXONOMY_FILE" \
    --experian_match_file "$EXPERIAN_MATCH_FILE" \
    --pam_directory_file "$PAM_DIRECTORY_FILE" \
    --cbaf_utility_file "$CBAF_UTILITY_FILE" \
    --utility_file "$UTILITY_FILE" \
    --counties_lookup_file "$COUNTIES_LOOKUP_FILE" \
    --match_output_file "$MATCH_OUTPUT_FILE" \
    --output_dir "$HDFS_OUTPUT_DIR/module1_output" \
    --supporting_data_dir "$DATA_BASE_DIR" \
    --log_file_path "$MODULE1_LOG_FILE" 2>&1 | tee -a "$MAIN_LOG_FILE"

# Check if module1 succeeded
if [ $? -eq 0 ]; then
    STEP1_END_TIME=$(date +%s)
    STEP1_DURATION=$((STEP1_END_TIME - STEP1_START_TIME))
    log "SUCCESS" "Module 1 processing completed successfully in $(format_time $STEP1_DURATION) (${STEP1_DURATION}s)"
    
    # List the output directories to verify
    hdfs dfs -ls $HDFS_OUTPUT_DIR/module1_output/ >> "$MAIN_LOG_FILE"
    
    # Send email notification for Stage 1 success
    EMAIL_BODY="Audience Engine Pipeline - Stage 1 Complete for $CURRENT_MONTH_NAME
==================================================
✅ STEP 1: Module 1 data processing completed successfully

Execution ID: $TIMESTAMP
Start time: $(date -d @$STEP1_START_TIME)
End time: $(date -d @$STEP1_END_TIME)
Duration: $(format_time $STEP1_DURATION) (${STEP1_DURATION}s)

Processing Details:
- Input Files: All validated files processed successfully
- Output: $HDFS_OUTPUT_DIR/module1_output
- Module 1 Log: $MODULE1_LOG_FILE

Next: Proceeding to Stage 2 (MinMax Processing)

Logs available in: $EXECUTION_LOG_DIR
"
    send_email "$EMAIL_SUBJECT_PREFIX Stage 1 Complete - Module 1 Processing" "$EMAIL_BODY"
    
    LAST_COMPLETED_STEP="Module 1 Processing"
else
    log "ERROR" "Module 1 processing failed"
    
    # Send failure email
    EMAIL_BODY="Audience Engine Pipeline - Stage 1 FAILED for $CURRENT_MONTH_NAME
==================================================
❌ STEP 1: Module 1 data processing FAILED

Execution ID: $TIMESTAMP
Start time: $(date -d @$STEP1_START_TIME)
End time: $(date)
Duration: $(($(date +%s) - STEP1_START_TIME)) seconds

Check logs for details:
- Main Log: $MAIN_LOG_FILE
- Module 1 Log: $MODULE1_LOG_FILE
- Log Directory: $EXECUTION_LOG_DIR

Pipeline has been stopped.
"
    send_email "$EMAIL_SUBJECT_PREFIX FAILED - Module 1 Processing Error" "$EMAIL_BODY"
    exit 1
fi

# =====================================================================
# STEP 2: Run minmax_processor.py for statistical analysis
# =====================================================================

CURRENT_STEP="MinMax Processing"
log "INFO" "=== STEP 2: STARTING MINMAX STATISTICAL ANALYSIS ==="
STEP2_START_TIME=$(date +%s)

# Use the main CSV directory from module1 output for MinMax processing
MODULE1_CSV_DIR=$(hdfs dfs -ls $HDFS_OUTPUT_DIR/module1_output | grep -v "_SUCCESS" | grep ".csv" | head -1 | awk '{print $8}')
# Validate module1 output
if [ -z "$MODULE1_CSV_DIR" ]; then
    log "ERROR" "Could not find main CSV directory from module1 in HDFS."
    
    # Send failure email
    EMAIL_BODY="Audience Engine Pipeline - Stage 2 FAILED for $CURRENT_MONTH_NAME
==================================================
❌ STEP 2: MinMax processing FAILED

Execution ID: $TIMESTAMP
Error: Could not find main CSV directory from module1.
Start time: $(date -d @$STEP2_START_TIME)
End time: $(date)

Pipeline has been stopped. Check logs for details:
- Main Log: $MAIN_LOG_FILE
- Log Directory: $EXECUTION_LOG_DIR
"
    send_email "$EMAIL_SUBJECT_PREFIX FAILED - MinMax Processing Error" "$EMAIL_BODY"
    exit 1
fi

log "INFO" "Using module1 main CSV directory from HDFS: $MODULE1_CSV_DIR"

# Run MinMax processor with enhanced logging
spark-submit \
    --master yarn \
    --queue $QUEUE \
    --files "$SCRIPTS_DIR/config.py,$SCRIPTS_DIR/functions.py,$SCRIPTS_DIR/log.py" \
    "$SCRIPTS_DIR/minmax_comparision.py" \
    --input_file "$MODULE1_CSV_DIR" \
    --output_dir "$HDFS_OUTPUT_DIR/minmax_output" \
    --log_file_path "$MINMAX_LOG_FILE" \
    --num_sample_records 100 \
    --run_exclude_seeds False \
    --exclude_field "Postcode District" \
    --exclude_value "AB10" \
    --include_empty_cells True \
    --input_format_fixed False \
    --batch False \
    --batch_field "Postcode Area" \
    --run_frequency_reports True \
    --num_records_show 999 \
    --separate_reports False 2>&1 | tee -a "$MAIN_LOG_FILE"

if [ $? -eq 0 ]; then
    STEP2A_END_TIME=$(date +%s)
    STEP2A_DURATION=$((STEP2A_END_TIME - STEP2_START_TIME))
    log "SUCCESS" "MinMax CSV processing completed successfully in $(format_time $STEP2A_DURATION) (${STEP2A_DURATION}s)"
    
    # =====================================================================
    # STEP 2B: Convert CSV to Excel using excel_builder.py
    # =====================================================================
    
    CURRENT_STEP="Excel Conversion"
    log "INFO" "=== STEP 2B: CONVERTING CSV FILES TO EXCEL WORKBOOKS ==="
    STEP2B_START_TIME=$(date +%s)
    
    # Find MinMax CSV directory
    MINMAX_CSV_DIR=$(hdfs dfs -ls $HDFS_OUTPUT_DIR/minmax_output | grep "Audience_Engine_Supply_Internal_minmax" | head -1 | awk '{print $8}')
    
    # Validate MinMax CSV output
    if [ -z "$MINMAX_CSV_DIR" ]; then
        log "WARNING" "Could not find specific minmax output directory. Using default path."
        MINMAX_CSV_DIR="$HDFS_OUTPUT_DIR/minmax_output"
    else
        log "INFO" "Found minmax output directory: $MINMAX_CSV_DIR"
    fi
    
    # Run excel builder with enhanced logging
    spark-submit \
        --master yarn \
        --queue $QUEUE \
        --files "$SCRIPTS_DIR/log.py" \
        "$SCRIPTS_DIR/excel_builder.py" \
        --input_dir "$MINMAX_CSV_DIR" \
        --output_dir "$HDFS_OUTPUT_DIR/minmax_output" \
        --single_report \
        --log_file_path "$EXCEL_LOG_FILE" 2>&1 | tee -a "$MAIN_LOG_FILE"
    
    if [ $? -eq 0 ]; then
        STEP2B_END_TIME=$(date +%s)
        STEP2B_DURATION=$((STEP2B_END_TIME - STEP2B_START_TIME))
        STEP2_TOTAL_DURATION=$((STEP2B_END_TIME - STEP2_START_TIME))
        
        log "SUCCESS" "Excel conversion completed successfully in $(format_time $STEP2B_DURATION) (${STEP2B_DURATION}s)"
        log "SUCCESS" "Total MinMax processing time: $(format_time $STEP2_TOTAL_DURATION) (${STEP2_TOTAL_DURATION}s)"
        
        # Send email notification for Stage 2 success
        EMAIL_BODY="Audience Engine Pipeline - Stage 2 Complete for $CURRENT_MONTH_NAME
==================================================
✅ STEP 2: MinMax statistical analysis completed successfully

Execution ID: $TIMESTAMP
Start time: $(date -d @$STEP2_START_TIME)
End time: $(date -d @$STEP2B_END_TIME)
Total duration: $(format_time $STEP2_TOTAL_DURATION) (${STEP2_TOTAL_DURATION}s)
- CSV generation: $(format_time $STEP2A_DURATION) (${STEP2A_DURATION}s)
- Excel conversion: $(format_time $STEP2B_DURATION) (${STEP2B_DURATION}s)

Processing Details:
- Input: $MODULE1_CSV_DIR
- CSV Output: $HDFS_OUTPUT_DIR/minmax_output
- Excel Output: $HDFS_OUTPUT_DIR/minmax_output/*.xlsx
- MinMax Log: $MINMAX_LOG_FILE
- Excel Log: $EXCEL_LOG_FILE

Next: Proceeding to Stage 3 (Comparison Processing)

Logs available in: $EXECUTION_LOG_DIR
"
        send_email "$EMAIL_SUBJECT_PREFIX Stage 2 Complete - MinMax Analysis" "$EMAIL_BODY"
        
        LAST_COMPLETED_STEP="MinMax Processing"
    else
        log "ERROR" "Excel conversion failed"
        
        # Send failure email
        EMAIL_BODY="Audience Engine Pipeline - Stage 2B FAILED for $CURRENT_MONTH_NAME
==================================================
❌ STEP 2B: Excel conversion FAILED

Execution ID: $TIMESTAMP
Start time: $(date -d @$STEP2B_START_TIME)
End time: $(date)
Duration: $(($(date +%s) - STEP2B_START_TIME)) seconds

CSV generation succeeded but Excel conversion failed.
Check logs for details:
- Main Log: $MAIN_LOG_FILE
- Excel Log: $EXCEL_LOG_FILE
- Log Directory: $EXECUTION_LOG_DIR

Pipeline has been stopped.
"
        send_email "$EMAIL_SUBJECT_PREFIX FAILED - Excel Conversion Error" "$EMAIL_BODY"
        exit 1
    fi
else
    log "ERROR" "MinMax CSV processing failed"
    
    # Send failure email
    EMAIL_BODY="Audience Engine Pipeline - Stage 2 FAILED for $CURRENT_MONTH_NAME
==================================================
❌ STEP 2: MinMax CSV generation FAILED

Execution ID: $TIMESTAMP
Start time: $(date -d @$STEP2_START_TIME)
End time: $(date)
Duration: $(($(date +%s) - STEP2_START_TIME)) seconds

Check logs for details:
- Main Log: $MAIN_LOG_FILE
- MinMax Log: $MINMAX_LOG_FILE
- Log Directory: $EXECUTION_LOG_DIR

Pipeline has been stopped.
"
    send_email "$EMAIL_SUBJECT_PREFIX FAILED - MinMax Processing Error" "$EMAIL_BODY"
    exit 1
fi

# =====================================================================
# STEP 3: Run new_module3.py for comparison processing
# =====================================================================

CURRENT_STEP="Comparison Processing"
log "INFO" "=== STEP 3: STARTING COMPARISON PROCESSING ==="
STEP3_START_TIME=$(date +%s)

# Find the MinMax output Excel file
MINMAX_EXCEL=$(hdfs dfs -ls $HDFS_OUTPUT_DIR/minmax_output | grep ".xlsx" | head -1 | awk '{print $8}')

# Validate MinMax Excel output
if [ -z "$MINMAX_EXCEL" ]; then
    log "ERROR" "Could not find MinMax output Excel file in HDFS."
    
    # Send failure email
    EMAIL_BODY="Audience Engine Pipeline - Stage 3 FAILED for $CURRENT_MONTH_NAME
==================================================
❌ STEP 3: Comparison processing FAILED

Execution ID: $TIMESTAMP
Error: Could not find MinMax output Excel file
Start time: $(date -d @$STEP3_START_TIME)
End time: $(date)

Pipeline has been stopped. Check logs for details:
- Main Log: $MAIN_LOG_FILE
- Log Directory: $EXECUTION_LOG_DIR
"
    send_email "$EMAIL_SUBJECT_PREFIX FAILED - Comparison Processing Error" "$EMAIL_BODY"
    exit 1
fi

log "INFO" "Using MinMax output: $MINMAX_EXCEL"
log "INFO" "Using previous file: $PREVIOUS_FILE"

# Run comparison with validated files and enhanced logging
if [ -n "$PREVIOUS_FILE" ]; then
    log "INFO" "Running comparison with previous file"
    spark-submit \
        --master yarn \
        --queue $QUEUE \
        --files "$SCRIPTS_DIR/log.py" \
        "$SCRIPTS_DIR/new_module3.py" \
        --current_file "$MINMAX_EXCEL" \
        --previous_file "$PREVIOUS_FILE" \
        --output_dir "$HDFS_OUTPUT_DIR/comparison_output" \
        --sheet_name "Stats" \
        --log_file_path "$MODULE3_LOG_FILE" 2>&1 | tee -a "$MAIN_LOG_FILE"
else
    log "WARNING" "No previous file available, skipping comparison processing"
    log "INFO" "Creating placeholder comparison output directory"
    hdfs dfs -mkdir -p "$HDFS_OUTPUT_DIR/comparison_output"
    echo "No previous comparison file available for this execution" | hdfs dfs -put - "$HDFS_OUTPUT_DIR/comparison_output/no_comparison.txt"
fi

# Check if comparison succeeded or was skipped
if [ $? -eq 0 ]; then
    STEP3_END_TIME=$(date +%s)
    STEP3_DURATION=$((STEP3_END_TIME - STEP3_START_TIME))
    
    if [ -n "$PREVIOUS_FILE" ]; then
        log "SUCCESS" "Comparison processing completed successfully in $(format_time $STEP3_DURATION) (${STEP3_DURATION}s)"
        
        # List the output to verify
        hdfs dfs -ls $HDFS_OUTPUT_DIR/comparison_output/ >> "$MAIN_LOG_FILE"
        
        # Send email notification for Stage 3 success
        EMAIL_BODY="Audience Engine Pipeline - Stage 3 Complete for $CURRENT_MONTH_NAME
==================================================
✅ STEP 3: Comparison processing completed successfully

Execution ID: $TIMESTAMP
Start time: $(date -d @$STEP3_START_TIME)
End time: $(date -d @$STEP3_END_TIME)
Duration: $(format_time $STEP3_DURATION) (${STEP3_DURATION}s)

Processing Details:
- Current File: $MINMAX_EXCEL
- Previous File: $PREVIOUS_FILE
- Output: $HDFS_OUTPUT_DIR/comparison_output
- Module 3 Log: $MODULE3_LOG_FILE

Next: Proceeding to file copying and final steps

Logs available in: $EXECUTION_LOG_DIR
"
        send_email "$EMAIL_SUBJECT_PREFIX Stage 3 Complete - Comparison Processing" "$EMAIL_BODY"
    else
        log "SUCCESS" "Comparison processing skipped (no previous file available) in $(format_time $STEP3_DURATION) (${STEP3_DURATION}s)"
        
        # Send email notification for Stage 3 skipped
        EMAIL_BODY="Audience Engine Pipeline - Stage 3 Skipped for $CURRENT_MONTH_NAME
==================================================
⚠️ STEP 3: Comparison processing SKIPPED

Execution ID: $TIMESTAMP
Start time: $(date -d @$STEP3_START_TIME)
End time: $(date -d @$STEP3_END_TIME)
Duration: $(format_time $STEP3_DURATION) (${STEP3_DURATION}s)

Reason: No previous comparison file available
This is expected for first-time runs or when previous month data is missing.

Processing Details:
- Current File: $MINMAX_EXCEL
- Previous File: NOT AVAILABLE
- Output: $HDFS_OUTPUT_DIR/comparison_output (placeholder created)

Next: Proceeding to file copying and final steps

Logs available in: $EXECUTION_LOG_DIR
"
        send_email "$EMAIL_SUBJECT_PREFIX Stage 3 Skipped - No Previous File" "$EMAIL_BODY"
    fi
    
    LAST_COMPLETED_STEP="Comparison Processing"
else
    log "ERROR" "Comparison processing failed"
    
    # Send failure email
    EMAIL_BODY="Audience Engine Pipeline - Stage 3 FAILED for $CURRENT_MONTH_NAME
==================================================
❌ STEP 3: Comparison processing FAILED

Execution ID: $TIMESTAMP
Start time: $(date -d @$STEP3_START_TIME)
End time: $(date)
Duration: $(($(date +%s) - STEP3_START_TIME)) seconds

Check logs for details:
- Main Log: $MAIN_LOG_FILE
- Module 3 Log: $MODULE3_LOG_FILE
- Log Directory: $EXECUTION_LOG_DIR

Pipeline has been stopped.
"
    send_email "$EMAIL_SUBJECT_PREFIX FAILED - Comparison Processing Error" "$EMAIL_BODY"
    exit 1
fi

# =====================================================================
# STEP 4: Copy files to local temp directories
# =====================================================================

CURRENT_STEP="File Copying to Local Temp"
log "INFO" "=== STEP 4: COPYING FILES TO LOCAL TEMP DIRECTORIES ==="
STEP4_START_TIME=$(date +%s)

if copy_to_local_temp "$HDFS_OUTPUT_DIR"; then
    STEP4_END_TIME=$(date +%s)
    STEP4_DURATION=$((STEP4_END_TIME - STEP4_START_TIME))
    log "SUCCESS" "File copying to local temp completed in $(format_time $STEP4_DURATION) (${STEP4_DURATION}s)"
    
    LAST_COMPLETED_STEP="File Copying to Local Temp"
else
    log "ERROR" "File copying to local temp failed"
    
    # Send failure email
    EMAIL_BODY="Audience Engine Pipeline - Stage 4 FAILED for $CURRENT_MONTH_NAME
==================================================
❌ STEP 4: File copying to local temp FAILED

Execution ID: $TIMESTAMP
Start time: $(date -d @$STEP4_START_TIME)
End time: $(date)
Duration: $(($(date +%s) - STEP4_START_TIME)) seconds

Check logs for details:
- Main Log: $MAIN_LOG_FILE
- Log Directory: $EXECUTION_LOG_DIR

Pipeline has been stopped.
"
    send_email "$EMAIL_SUBJECT_PREFIX FAILED - File Copying Error" "$EMAIL_BODY"
    exit 1
fi

# =====================================================================
# PIPELINE COMPLETION
# =====================================================================

PIPELINE_END_TIME=$(date +%s)
PIPELINE_DURATION=$((PIPELINE_END_TIME - PIPELINE_START_TIME))

log "SUCCESS" "AUDIENCE ENGINE PIPELINE - COMPLETED SUCCESSFULLY"
log "SUCCESS" "Total duration: $(format_time $PIPELINE_DURATION) (${PIPELINE_DURATION}s)"
log "SUCCESS" "Output directory: $HDFS_OUTPUT_DIR"
log "SUCCESS" "Local temp directories: $LOCAL_TEMP_DIR and $LOCAL_TMP_DIR"
log "SUCCESS" "Execution logs saved in: $EXECUTION_LOG_DIR"

# Create execution summary file
cat > "$EXECUTION_LOG_DIR/EXECUTION_SUCCESS.txt" << EOF
Audience Engine Pipeline - EXECUTION COMPLETED SUCCESSFULLY
==========================================================
Execution ID: $TIMESTAMP
Start Time: $(date -d @$PIPELINE_START_TIME)
End Time: $(date -d @$PIPELINE_END_TIME)
Total Duration: $(format_time $PIPELINE_DURATION) (${PIPELINE_DURATION}s)

STAGE DURATIONS:
- File Validation: Completed
- Module 1: $(format_time ${STEP1_DURATION:-0}) (${STEP1_DURATION:-0}s)
- MinMax: $(format_time ${STEP2_TOTAL_DURATION:-0}) (${STEP2_TOTAL_DURATION:-0}s)
- Comparison: $(format_time ${STEP3_DURATION:-0}) (${STEP3_DURATION:-0}s)
- File Copying: $(format_time ${STEP4_DURATION:-0}) (${STEP4_DURATION:-0}s)

OUTPUT LOCATIONS:
- HDFS: $HDFS_OUTPUT_DIR
- Local Temp: $LOCAL_TEMP_DIR
- Local Tmp: $LOCAL_TMP_DIR (777 permissions)

LOG LOCATION: $EXECUTION_LOG_DIR

All processing completed successfully.
EOF

# Send final comprehensive summary email
FORMATTED_DURATION=$(format_time $PIPELINE_DURATION)
FORMATTED_STEP1=$(format_time ${STEP1_DURATION:-0})
FORMATTED_STEP2=$(format_time ${STEP2_TOTAL_DURATION:-0})
FORMATTED_STEP3=$(format_time ${STEP3_DURATION:-0})
FORMATTED_STEP4=$(format_time ${STEP4_DURATION:-0})

EMAIL_BODY="Audience Engine Pipeline - COMPLETE SUMMARY for $CURRENT_MONTH_NAME
==================================================
🎉 Pipeline execution completed successfully

Execution ID: $TIMESTAMP
Start time: $(date -d @$PIPELINE_START_TIME)
End time: $(date -d @$PIPELINE_END_TIME)
Total duration: $FORMATTED_DURATION (${PIPELINE_DURATION}s)

STAGE DURATIONS:
✅ File Validation: Completed successfully
✅ Stage 1 (Module 1): $FORMATTED_STEP1 (${STEP1_DURATION}s)
✅ Stage 2 (MinMax Analysis): $FORMATTED_STEP2 (${STEP2_TOTAL_DURATION}s)
✅ Stage 3 (Comparison): $FORMATTED_STEP3 (${STEP3_DURATION}s)
✅ Stage 4 (File Copying): $FORMATTED_STEP4 (${STEP4_DURATION}s)

INPUT FILES PROCESSED:
- Digital Taxonomy: $(basename "$DIGITAL_TAXONOMY_FILE")
- Experian Match: $(basename "$EXPERIAN_MATCH_FILE")
- PAM Directory: $(basename "$PAM_DIRECTORY_FILE")
- CBAF Utility: $(basename "$CBAF_UTILITY_FILE")
- Utility: $(basename "$UTILITY_FILE")
- Counties Lookup: $(basename "$COUNTIES_LOOKUP_FILE")
- Match Output: $(basename "$MATCH_OUTPUT_FILE")
- Previous File: $(basename "${PREVIOUS_FILE:-NOT_AVAILABLE}")

OUTPUT LOCATIONS:
✅ HDFS Output: $HDFS_OUTPUT_DIR
✅ Local Data Directory: $LOCAL_TEMP_DIR
✅ Local Temp Directory: $LOCAL_TMP_DIR (with 777 permissions)

FILES COPIED AND PERMISSIONS SET:
✅ All merged Module 1 files copied to local temp directories
✅ Excel files copied to both local directories with proper permissions
✅ Main CSV file: ${TIMESTAMP}_module1_output.csv
✅ Supporting files: counties_check.csv, Digital_taxonomy files, Adsmart files
✅ Excel outputs: MinMax and Comparison Excel files

DETAILED LOGS AVAILABLE:
- Main Pipeline Log: $MAIN_LOG_FILE
- Module 1 Log: $MODULE1_LOG_FILE
- MinMax Log: $MINMAX_LOG_FILE
- Excel Builder Log: $EXCEL_LOG_FILE
- Module 3 Log: $MODULE3_LOG_FILE
- File Inventory: $EXECUTION_LOG_DIR/file_inventory.txt

🔍 All output files have been copied to local directories for easy access
📊 Excel files are available in both locations with appropriate permissions
📝 All execution logs are preserved for troubleshooting and audit purposes

Pipeline execution completed successfully! 🚀
"

# Send the final summary email
send_email "$EMAIL_SUBJECT_PREFIX COMPLETE - $CURRENT_MONTH_NAME Pipeline Execution Summary" "$EMAIL_BODY"

log "SUCCESS" "Email notification sent. Pipeline execution complete."
log "INFO" "All logs saved in: $EXECUTION_LOG_DIR"
log "INFO" "Files copied to: $LOCAL_TEMP_DIR and $LOCAL_TMP_DIR"
log "INFO" "Pipeline execution completed successfully with execution ID: $TIMESTAMP"

exit 0