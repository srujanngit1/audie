from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, lit, count, when, isnan, row_number, monotonically_increasing_id, regexp_replace
from pyspark.sql.window import Window
from pyspark.sql.types import LongType
import os
from datetime import datetime
import argparse
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import pandas as pd
import tempfile
import subprocess
import glob
import logging

# Simple logging for EMR Serverless
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def read_excel_file(spark, file_path, sheet_name=0):
    """Reads an Excel file and converts it to a Spark DataFrame."""
    logger.info(f"Reading Excel file: {file_path}, sheet: {sheet_name}")
    
    # For S3 paths, we need to download locally first since Spark can't read Excel directly from S3
    is_s3_path = file_path.startswith("s3://") or file_path.startswith("s3a://")
    local_dir = "/tmp/audience_engine_tmp"
    
    if not os.path.exists(local_dir):
        os.makedirs(local_dir, exist_ok=True)
    
    if is_s3_path:
        logger.info("S3 path detected. Downloading file locally first.")
        filename = os.path.basename(file_path)
        local_file_path = os.path.join(local_dir, filename)
        logging.info(f"Downloading file from S3 to local path: {local_file_path}")
        
        # Use spark to copy file from S3 to local
        import boto3
        if file_path.startswith('s3a://'):
            s3_path_cleaned = file_path[6:]
        elif file_path.startswith('s3://'):
            s3_path_cleaned = file_path[5:]
        else:
            s3_path_cleaned = file_path
        
        parts = s3_path_cleaned.split('/')
        bucket = parts[0]
        key = '/'.join(parts[1:]) if len(parts) > 1 else ''
        
        s3 = boto3.client('s3')
        s3.download_file(bucket, key, local_file_path)
        file_to_read = local_file_path
    else:
        file_to_read = file_path
    
    logging.info(f"Reading Excel file with pandas: {file_to_read}")
    pandas_df = pd.read_excel(file_to_read, sheet_name=sheet_name)
    
    logging.info("Converting pandas DataFrame to Spark DataFrame")
    spark_df = spark.createDataFrame(pandas_df)
    logging.info(f"Successfully read Excel file with {len(pandas_df.columns)} columns")
    return spark_df

def read_pipe_delimited_csv(spark, file_path, header=True, inferSchema=False):
    """Read a pipe-delimited CSV file and convert to Spark DataFrame"""
    logging.info(f"Reading pipe-delimited file: {file_path}")
    
    df = spark.read.option("delimiter", "|") \
                  .option("header", header) \
                  .option("inferSchema", inferSchema) \
                  .csv(file_path)
    
    logging.info(f"Successfully read pipe-delimited file with {len(df.columns)} columns")
    return df

def log_dataframe_info(logging, df: DataFrame, stage_name: str) -> Tuple[int, int]:
    """
    Logging function that shows column information without counting rows for performance.
    """
    column_count = len(df.columns)
    logging.info(f"Stage: {stage_name}")
    logging.info(f"Column count: {column_count}")
    
    return column_count, 0  # Return 0 as placeholder for row count

def save_to_csv(df: DataFrame, output_path: str, header: bool = True) -> None:
    """Save DataFrame to CSV format"""
    logging.info(f"Saving DataFrame to CSV: {output_path}")
    
    if df.rdd.getNumPartitions() > 20:
        logging.info("Coalescing DataFrame to reduce partitions for output")
        df = df.coalesce(1)
    
    df.write.mode("overwrite").option("header", header).csv(output_path)
    logging.info("CSV file saved successfully")

def remove_columns(df: DataFrame, columns_to_remove: List[str], logging) -> DataFrame:
    """Remove specified columns from DataFrame"""
    all_columns = df.columns
    columns_to_remove_exist = [col for col in columns_to_remove if col in all_columns]
    columns_to_keep = [col for col in all_columns if col not in columns_to_remove]
    
    logging.info(f"Removing {len(columns_to_remove_exist)} columns from {len(all_columns)} total columns")
    logging.info(f"Keeping {len(columns_to_keep)} columns")
    
    result_df = df.select(*columns_to_keep)
    logging.info("Column removal completed successfully")
    return result_df

def filter_non_empty(df: DataFrame, column_name: str) -> DataFrame:
    """Filter rows where the specified column is not empty or null"""
    logging.info(f"Filtering non-empty values for column: {column_name}")
    result = df.filter(
        ~col(column_name).isNull() & 
        (col(column_name).cast("string") != "")
    )
    logging.info("Non-empty filtering completed")
    return result

def get_unique_values(df: DataFrame, column_name: str) -> DataFrame:
    """Return DataFrame with unique values from specified column, preserving all columns"""
    logging.info(f"Getting unique values for column: {column_name}")
    
    if len(df.columns) > 20:
        logging.info("Large DataFrame detected, using optimized unique value extraction")
        distinct_values = df.select(column_name).distinct()
        result = df.join(distinct_values, column_name, "inner").dropDuplicates([column_name])
        logging.info("Optimized unique value extraction completed")
        return result
    else:
        logging.info("Using simple dropDuplicates for unique value extraction")
        result = df.dropDuplicates([column_name])
        logging.info("Simple unique value extraction completed")
        return result

def perform_join(left_df: DataFrame, right_df: DataFrame, join_column: str, logging) -> Tuple[DataFrame, DataFrame, DataFrame]:
    """Perform a join similar to Alteryx with three outputs"""
    logging.info(f"Performing join on column: {join_column}")
    
    # Cache optimization for large DataFrames
    left_count_check = left_df.rdd.getNumPartitions() > 5
    right_count_check = right_df.rdd.getNumPartitions() > 5
    
    if left_count_check:
        left_df = left_df.cache()
        logging.info("Cached left DataFrame for join optimization")
    
    if right_count_check:
        right_df = right_df.cache()
        logging.info("Cached right DataFrame for join optimization")
    
    logging.info("Renaming join column in right DataFrame to avoid conflicts")
    right_df_renamed = right_df.withColumnRenamed(join_column, f"Right_{join_column}")
    join_condition = left_df[join_column] == right_df_renamed[f"Right_{join_column}"]
    
    logging.info("Executing inner join")
    j_output = left_df.join(right_df_renamed, join_condition, "inner")
    
    logging.info("Executing left anti-join")
    l_output = left_df.join(right_df_renamed, join_condition, "left_anti")
    
    logging.info("Executing right anti-join")
    r_output = right_df_renamed.join(left_df, join_condition, "left_anti")
    
    logging.info("All three join outputs completed successfully")
    return j_output, l_output, r_output

def perform_join_different_columns(left_df, right_df, left_join_column, right_join_column, logging):
    """Performs a join between two dataframes on different column names."""
    logging.info(f"Joining on left.{left_join_column} = right.{right_join_column}")
    
    j_output = left_df.join(right_df, left_df[left_join_column] == right_df[right_join_column], "inner")
    l_output = left_df.join(right_df, left_df[left_join_column] == right_df[right_join_column], "left_anti")
    r_output = right_df.join(left_df, right_df[right_join_column] == left_df[left_join_column], "left_anti")
    
    logging.info("Different column join completed successfully")
    return j_output, l_output, r_output

def join_with_prefix(left_df, right_df, join_column, logger):
    """Join two dataframes and prefix right columns with 'Right_'"""
    logger.info(f"Joining on {join_column} with prefixed columns")
    
    right_columns = right_df.columns
    for col_name in right_columns:
        right_df = right_df.withColumnRenamed(col_name, f"Right_{col_name}")
    
    right_join_column = f"Right_{join_column}"
    
    j_output = left_df.join(right_df, left_df[join_column] == right_df[right_join_column], "inner")
    l_output = left_df.join(right_df, left_df[join_column] == right_df[right_join_column], "left_anti")
    r_output = right_df.join(left_df, right_df[right_join_column] == left_df[join_column], "left_anti")
    
    logger.info("Prefixed column join completed successfully")
    return j_output, l_output, r_output

def main():
    # Parse command line arguments first to get log file path
    parser = argparse.ArgumentParser(description="Process various input files for Module 1.")
    parser.add_argument('--cbaf_utility_file', required=True, help='Path to CBAF utility file')
    parser.add_argument('--experian_match_file', required=True, help='Path to Experian match file')
    parser.add_argument('--pam_directory_file', required=True, help='Path to PAM directory file')
    parser.add_argument('--digital_taxonomy_file', required=True, help='Path to digital taxonomy file')
    parser.add_argument('--match_output_file', required=True, help='Path to match output file')
    parser.add_argument('--utility_file', required=True, help='Path to utility file')
    parser.add_argument('--counties_lookup_file', required=True, help='Path to counties lookup file')
    parser.add_argument('--output_dir', required=True, help='Directory for output files')
    parser.add_argument('--supporting_data_dir', required=True, help='Directory for supporting data files')
    parser.add_argument('--log_file_path', required=False, help='Path to log file')
    
    args = parser.parse_args()
    
    # Use the logger configured at module level
    current_date_str = datetime.now().strftime("%Y%m%d")
    
    logger.info("Module 1 - Starting data integration and processing")
    logger.info(f"Log file: {args.log_file_path}")
    logger.info("Command line arguments parsed successfully")
    
    # Initialize Spark session
    logger.info("Initializing Spark Session")
    spark = SparkSession.builder \
        .appName('Module 1 - Data Integration and Processing') \
        .getOrCreate()
        
    spark.sparkContext.setLogLevel("WARN")
    logger.info("Spark Session initialized successfully")

    #########################################################################################################
    # STEP 1: PROCESSING DIGITAL TAXONOMY FILE                                                             #
    #########################################################################################################
    logger.info(f"Loading digital taxonomy file: {args.digital_taxonomy_file}")
    digital_taxonomy_df = read_pipe_delimited_csv(spark, args.digital_taxonomy_file, header=True, inferSchema=False)
    cols, _ = log_dataframe_info(logger, digital_taxonomy_df, "Loading digital taxonomy file as strings")

    logger.info("Casting key columns to LongType for data integrity")
    digital_taxonomy_df = digital_taxonomy_df.withColumn(
        "cb_key_household", col("cb_key_household").cast(LongType())
    ).withColumn(
        "cb_key_db_person", col("cb_key_db_person").cast(LongType())
    )
    log_dataframe_info(logger, digital_taxonomy_df, "Casted key columns")

    #########################################################################################################
    # STEP 1.5: ADD ORIGINAL ROW NUMBER TO PRESERVE SOURCE POSITION                                        #
    #########################################################################################################
    logger.info("Adding original row number to preserve source data position")
    logger.info("Converting to RDD, zipping with index, then converting back to DataFrame")

    indexed_rdd = digital_taxonomy_df.rdd.zipWithIndex()
    indexed_rdd = indexed_rdd.map(lambda x: (*x[0], x[1] + 1))

    schema = digital_taxonomy_df.schema.add("Original_Row_Number", LongType())
    digital_taxonomy_with_row_df = spark.createDataFrame(indexed_rdd, schema)
    log_dataframe_info(logger, digital_taxonomy_with_row_df, "Added Original_Row_Number column")

    #########################################################################################################
    # STEP 2: REMOVING SPECIFIED COLUMNS FROM DIGITAL TAXONOMY                                              #
    #########################################################################################################
    logger.info("Setting up column removal for digital taxonomy")
    columns_to_remove = [
        "UDPRN", "C000001B", "C000002C", "C000014B", "C000018B",
        "C000021B", "C000021C", "C000069A", "C000069B", "C000072A",
        "C000070A", "C000071A", "C000072B", "C000072C", "C000072D",
        "C000073A", "C000072E", "C000074A", "C000074B", "C000075A",
        "C000079A", "C000076A", "C000077A", "C000078A", "C000078B",
        "C000078C", "C000078D", "C000079B", "C000079C", "C000079D",
        "C000079E", "C000079F", "C000080A", "C000080B", "C000080C",
        "C000079G", "C000080D", "C000079H", "C000080E", "C000080F",
        "C000080G", "C000079I", "C000081A", "C000082A", "C000083A",
        "C000083B", "C000083C", "C000083D", "C000083E", "C000083F",
        "C000083G", "C000083H", "C000083I", "C000084A", "C000318",
        "C000319", "C000320", "C000321", "C000322", "C000323",
        "C000324", "C000325", "C000326", "C000327", "C000328",
        "C000329", "C000330", "C000331", "C000332", "C000333",
        "C000334", "C000335", "C000336", "C000337", "C000338",
        "C000339", "C000340", "C000341", "C000342", "C000343",
        "C000344", "C000345", "C000346", "C000347", "C000348",
        "C000349", "C000350", "C000351", "C000352", "C000353",
        "C000354", "C000355", "C000356", "C000357", "C000358",
        "C000359", "C000360", "C000361", "C000362", "C000363",
        "C000364", "C000365", "C000366", "C000367", "C000368",
        "C000369", "C000370", "C000371", "C000372", "C000373",
        "C000374", "C000375", "C000376", "C000377", "C000378",
        "C000379", "C000380", "C000381", "C000382", "C000383",
        "C000384", "C000385", "C000386", "C000387", "C000388",
        "C000389", "C000390", "C000391", "C000392", "C000393",
        "C000394", "C000395", "C000396", "C000397", "C000406",
        "C000407", "C000408", "C000409", "C000410", "C000411",
        "C000412", "C000413", "C000414", "C000415", "C000416",
        "FileName", "Available_For_Adsmart_Selection"
    ]

    digital_taxonomy_filtered_df = remove_columns(digital_taxonomy_with_row_df, columns_to_remove, logger)
    log_dataframe_info(logger, digital_taxonomy_filtered_df, "After removing specified columns")

    #########################################################################################################
    # STEP 3: ADDING AD_SMART_FLAG COLUMN                                                                  #
    #########################################################################################################
    logger.info("Adding ad_smart_flag column with default value 1")
    digital_taxonomy_flagged_df = digital_taxonomy_filtered_df.withColumn("ad_smart_flag", lit(1))
    log_dataframe_info(logger, digital_taxonomy_flagged_df, "Added ad_smart_flag column")

    if "cb_key_db_person" not in digital_taxonomy_flagged_df.columns:
        logger.info("Adding cb_key_db_person column as it doesn't exist")
        digital_taxonomy_flagged_df = digital_taxonomy_flagged_df.withColumn("cb_key_db_person", lit(None))

    #########################################################################################################
    # STEP 4: LOADING AND PROCESSING EXPERIAN MATCH FILE                                                   #
    #########################################################################################################
    logger.info(f"Loading Experian match file: {args.experian_match_file}")
    experian_match_df = spark.read.csv(args.experian_match_file, header=False)
    log_dataframe_info(logger, experian_match_df, "Loading Experian match file")

    logger.info("Renaming column _c0 to cb_key_db_person")
    experian_match_df = experian_match_df.withColumnRenamed("_c0", "cb_key_db_person")
    log_dataframe_info(logger, experian_match_df, "Renamed columns from Experian match file")

    logger.info("Filtering for non-empty cb_key_db_person values")
    experian_filtered_df = filter_non_empty(experian_match_df, "cb_key_db_person")
    log_dataframe_info(logger, experian_filtered_df, "Filtered Experian match file")

    logger.info("Getting unique cb_key_db_person values")
    experian_unique_df = get_unique_values(experian_filtered_df, "cb_key_db_person")
    log_dataframe_info(logger, experian_unique_df, "Unique values from Experian match file")

    #########################################################################################################
    # STEP 5: JOIN DIGITAL TAXONOMY WITH EXPERIAN MATCH                                                    #
    #########################################################################################################
    logger.info("Preparing DataFrames for join with caching optimization")
    digital_taxonomy_flagged_df.cache()
    experian_unique_df.cache()

    j_output, l_output, r_output = perform_join(
        digital_taxonomy_flagged_df, 
        experian_unique_df, 
        "cb_key_db_person",
        logger
    )

    logger.info("Caching join results for performance optimization")
    j_output.cache()
    l_output.cache()

    #########################################################################################################
    # STEP 6: POST-JOIN PROCESSING                                                                        #
    #########################################################################################################
    logger.info("Adding Available_For_LiveRamp_Selection column to inner join result")
    j_output_with_liveramp = j_output.withColumn("Available_For_LiveRamp_Selection", lit("Y"))
    j_output_with_liveramp.cache()
    log_dataframe_info(logger, j_output_with_liveramp, "Inner join with LiveRamp column")

    logger.info("Performing union of inner join and left anti-join results")
    union_df = j_output_with_liveramp.unionByName(l_output, allowMissingColumns=True)
    union_df.cache()

    logger.info("Adding Available_For_Facebook column to union result")
    union_df_with_facebook = union_df.withColumn("Available_For_Facebook", lit("Y"))
    union_df_with_facebook.cache()
    log_dataframe_info(logger, union_df_with_facebook, "Union result with Facebook column")

    logger.info("Renaming ad_smart_flag to Available_For_Adsmart_Selection")
    result_df = union_df_with_facebook.withColumnRenamed("ad_smart_flag", "Available_For_Adsmart_Selection")
    result_df.cache()
    log_dataframe_info(logger, result_df, "Result with renamed columns")

    #########################################################################################################
    # STEP 7: JOIN WITH PAM DIRECTORY AND CBAF UTILITY - PAM FLAG JOIN                                    #
    #########################################################################################################
    logger.info(f"Loading PAM Directory file: {args.pam_directory_file}")
    pam_directory_df = spark.read.csv(args.pam_directory_file, header=True, inferSchema=False)
    log_dataframe_info(logger, pam_directory_df, "Loading PAM Directory file")

    logger.info("Selecting cb_key_household from PAM Directory file")
    pam_household_df = pam_directory_df.select("cb_key_household")
    pam_household_df = pam_household_df.withColumn(
        "cb_key_household", col("cb_key_household").cast(LongType())
    )
    log_dataframe_info(logger, pam_household_df, "Selected cb_key_household from PAM Directory")

    logger.info(f"Loading A16 CBAF Utility file: {args.utility_file}")
    # cbaf_utility_df = spark.read.option("delimiter", "|") \
    #               .option("header", True) \
    #               .option("inferSchema", False) \
    #               .csv(args.utility_file)
    cbaf_utility_df = spark.read.csv(args.utility_file, header=True, inferSchema=False)

    log_dataframe_info(logger, cbaf_utility_df, "Loading CBAF Utility file")
    cbaf_utility_df = cbaf_utility_df.withColumn(
        "cb_key_household", col("cb_key_household").cast(LongType())
    ).withColumn(
        "cb_key_db_person", col("cb_key_db_person").cast(LongType())
    )
    logger.info("Selecting cb_key_household from CBAF Utility file")
    cbaf_household_df = cbaf_utility_df.select("cb_key_household")
    log_dataframe_info(logger, cbaf_household_df, "Selected cb_key_household from CBAF Utility")

    logger.info("Getting unique cb_key_household values from CBAF Utility")
    cbaf_unique_household_df = get_unique_values(cbaf_household_df, "cb_key_household")
    log_dataframe_info(logger, cbaf_unique_household_df, "Unique cb_key_household from CBAF Utility")

    logger.info("Joining PAM Directory with CBAF Utility on cb_key_household")
    j_pam_cbaf, l_pam_cbaf, r_pam_cbaf = perform_join(
        pam_household_df,
        cbaf_unique_household_df,
        "cb_key_household",
        logger
    )

    logger.info("Getting unique cb_key_household values from PAM-CBAF left anti-join")
    unique_l_pam_cbaf = get_unique_values(l_pam_cbaf, "cb_key_household")
    log_dataframe_info(logger, unique_l_pam_cbaf, "Unique cb_key_household from PAM-CBAF left anti-join")

    if "cb_key_household" not in result_df.columns:
        logger.info("Adding cb_key_household column to result_df for join")
        result_df = result_df.withColumn("cb_key_household", lit(None))

    logger.info("Joining result_df with unique PAM households not in CBAF on cb_key_household")
    final_j_output, final_l_output, final_r_output = perform_join(
        result_df,
        unique_l_pam_cbaf,
        "cb_key_household",
        logger
    )

    final_l_output.drop("Right_cb_key_household")
    j_columns = final_j_output.columns
    if "Right_cb_key_household" in j_columns:
        logger.info("Dropping Right_cb_key_household from inner join")
        final_j_output = final_j_output.drop("Right_cb_key_household")

    #########################################################################################################
    # STEP 8: ADDING PARTIALLY ADDRESSED MAIL SELECTION COLUMN                                             #
    #########################################################################################################
    logger.info("Adding Available_For_Partially_Addressed_Mail_Selection column to inner join")
    j_output_with_pam = final_j_output.withColumn("Available_For_Partially_Addressed_Mail_Selection", lit("Y"))
    log_dataframe_info(logger, j_output_with_pam, "Inner join with PAM column")

    logger.info("Performing union of inner join with PAM and final left anti-join")
    union_pam_df = j_output_with_pam.unionByName(final_l_output, allowMissingColumns=True)
    log_dataframe_info(logger, union_pam_df, "Union result with PAM")

    logger.info("Selecting all columns (pass-through)")
    union_pam_selected_df = union_pam_df.select("*")
    log_dataframe_info(logger, union_pam_selected_df, "Selected all columns from union")

    #########################################################################################################
    # STEP 9: JOIN WITH CBAF UTILITY AND COUNTIES LOOKUP                                                   #
    #########################################################################################################
    logger.info(f"Loading F45 CBAF Utility file: {args.cbaf_utility_file}")
    f45_cbaf_utility_df = spark.read.csv(args.cbaf_utility_file, header=True, inferSchema=False)
    log_dataframe_info(logger, f45_cbaf_utility_df, "Loading F45 CBAF Utility file")

    logger.info("Selecting mailable_postcode and pc_county_or_unitary_auth_code from F45 CBAF Utility")
    f45_selected_df = f45_cbaf_utility_df.select("mailable_postcode", "pc_county_or_unitary_auth_code")
    log_dataframe_info(logger, f45_selected_df, "Selected columns from F45 CBAF Utility")

    logger.info(f"Loading Counties Lookup file: {args.counties_lookup_file}")
    counties_lookup_df = read_excel_file(spark, args.counties_lookup_file)
    log_dataframe_info(logger, counties_lookup_df, "Loading Counties Lookup file")

    logger.info("Joining F45 CBAF Utility with Counties Lookup on pc_county_or_unitary_auth_code = Code")
    j_output_counties, l_output_counties, r_output_counties = perform_join_different_columns(
        f45_selected_df,
        counties_lookup_df,
        "pc_county_or_unitary_auth_code",
        "Code",
        logger
    )

    logger.info("Performing union of inner join and left anti-join from F45-Counties join")
    union_counties_df = j_output_counties.unionByName(l_output_counties, allowMissingColumns=True)
    log_dataframe_info(logger, union_counties_df, "Union result of F45-Counties")

    logger.info("Adding pc_county_or_unitary_auth_code_2011 column with Counties value")
    counties_with_new_col_df = union_counties_df.withColumn(
        "pc_county_or_unitary_auth_code_2011", 
        when(col("Counties").isNotNull(), col("Counties")).otherwise(lit(None))
    )
    log_dataframe_info(logger, counties_with_new_col_df, "Added pc_county_or_unitary_auth_code_2011 column")

    logger.info("Creating counties_check summary")
    counties_check_df = counties_with_new_col_df.groupBy("pc_county_or_unitary_auth_code", "Counties") \
        .agg(count("*").alias("Count"))
    log_dataframe_info(logger, counties_check_df, "Counties check summary")

    counties_simplified_path = f"{args.output_dir}/counties_check.csv"
    logger.info(f"Saving counties check to: {counties_simplified_path}")
    simplified_counties_check = counties_check_df.select("pc_county_or_unitary_auth_code", "Counties", "Count").repartition(1)
    simplified_counties_check.write.mode("overwrite").option("header", True).csv(counties_simplified_path)
    logger.info("Counties check saved as a single file")

    logger.info("Joining union_pam_selected_df with counties data on mailable_postcode with prefixed columns")
    j_output_final, l_output_final, r_output_final = join_with_prefix(
        union_pam_selected_df,
        counties_with_new_col_df,
        "mailable_postcode",
        logger
    )

    logger.info("Dropping Right_mailable_postcode column")
    j_output_final = j_output_final.drop("Right_mailable_postcode")

    logger.info("Renaming Right_pc_county_or_unitary_auth_code_2011 column")
    if "Right_pc_county_or_unitary_auth_code_2011" in j_output_final.columns:
        j_output_final = j_output_final.withColumnRenamed(
            "Right_pc_county_or_unitary_auth_code_2011", 
            "pc_county_or_unitary_auth_code_2011"
        )

    logger.info("Performing union of inner join and left anti-join from final join")
    union_final_df = j_output_final.unionByName(l_output_final, allowMissingColumns=True)
    log_dataframe_info(logger, union_final_df, "Union result of final join")

    #########################################################################################################
    # STEP 10: MATCH FLAGGING JOIN                                                                         #
    #########################################################################################################
    logger.info(f"Loading Match Output file: {args.match_output_file}")
    match_output_df = spark.read.csv(args.match_output_file, header=True, inferSchema=False)
    log_dataframe_info(logger, match_output_df, "Loading Match Output file")

    logger.info("Selecting cb_key_household from Match Output file")
    match_selected_df = match_output_df.select(
        col("cb_key_household")
    )
    log_dataframe_info(logger, match_selected_df, "Selected and renamed columns from Match Output")

    logger.info("Getting unique cb_key_household values from Match Output")
    match_unique_df = get_unique_values(match_selected_df, "cb_key_household")
    log_dataframe_info(logger, match_unique_df, "Unique cb_key_household from Match Output")

    logger.info("Joining union_final_df with Match Output on cb_key_household")
    j_match_output, l_match_output, r_match_output = perform_join(
        union_final_df,
        match_unique_df,
        "cb_key_household",
        logger
    )

    logger.info("Adding Available_For_Match_ESIMedia column to inner join")
    j_match_with_flag = j_match_output.withColumn("Available_For_Match_ESIMedia", lit("Y"))
    j_match_with_flag = j_match_with_flag.drop("Right_cb_key_household")
    log_dataframe_info(logger, j_match_with_flag, "Inner join with Match ESIMedia flag")

    logger.info("Performing final union of match join and left anti-join")
    final_df = j_match_with_flag.unionByName(l_match_output, allowMissingColumns=True)
    log_dataframe_info(logger, final_df, "Final result DataFrame")

    #########################################################################################################
    # STEP 11: COMPRESSED POSTCODE PROCESSING                                                               #
    #########################################################################################################
    logger.info("Creating Compressed_Postcode column by removing spaces from mailable_postcode")
    replaced_mailable_postcode = final_df.withColumn(
        "Compressed_Postcode", 
        regexp_replace(col("mailable_postcode"), " ", "")
    )
    log_dataframe_info(logger, replaced_mailable_postcode, "Added Compressed_Postcode column")

    logger.info("Sorting by cb_key_household in ascending order")
    sorted_by_cb_key = replaced_mailable_postcode.orderBy("cb_key_household")
    log_dataframe_info(logger, sorted_by_cb_key, "Sorted by cb_key_household")

    logger.info("Summarizing by Compressed_Postcode with count")
    postcode_summary_df = replaced_mailable_postcode.groupBy("Compressed_Postcode") \
        .agg(count("*").alias("Count"))
    log_dataframe_info(logger, postcode_summary_df, "Summarized by Compressed_Postcode")

    #########################################################################################################
    # STEP 12: JOIN WITH POSTCODE SUMMARY                                                                  #
    #########################################################################################################
    logger.info("Checking for existing Number of people in postcode column in left dataframe")
    if "Number of people in postcode" in sorted_by_cb_key.columns:
        logger.info("Renaming existing Number of people in postcode column in left dataframe")
        sorted_by_cb_key = sorted_by_cb_key.withColumnRenamed("Number of people in postcode", 
                                                            "Left_Number of people in postcode")

    logger.info("Renaming Count column to Number of people in postcode in right dataframe")
    postcode_summary_renamed_df = postcode_summary_df.withColumnRenamed("Count", "Number of people in postcode")
    log_dataframe_info(logger, postcode_summary_renamed_df, "Renamed Count column")

    logger.info("Joining sorted_by_cb_key with postcode_summary on Compressed_Postcode")
    j_output_postcode, l_output_postcode, r_output_postcode = perform_join(
        sorted_by_cb_key,
        postcode_summary_renamed_df,
        "Compressed_Postcode",
        logger
    )

    logger.info("Dropping Right_Compressed_Postcode from inner join result")
    if "Right_Compressed_Postcode" in j_output_postcode.columns:
        j_output_postcode = j_output_postcode.drop("Right_Compressed_Postcode")
        logger.info("Dropped Right_Compressed_Postcode from inner join")

    log_dataframe_info(logger, j_output_postcode, "Final result after postcode join")

    #########################################################################################################
    # STEP 13: JOIN WITH HOUSEHOLD COUNT BY POSTCODE                                                       #
    #########################################################################################################
    logger.info("Getting unique records by cb_key_household")
    unique_households_df = get_unique_values(replaced_mailable_postcode, "cb_key_household")
    log_dataframe_info(logger, unique_households_df, "Unique records by cb_key_household")

    logger.info("Creating summary of households per compressed postcode")
    household_summary_df = unique_households_df.groupBy("Compressed_Postcode").agg(count("*").alias("Count"))
    log_dataframe_info(logger, household_summary_df, "Household count by compressed postcode")

    logger.info("Renaming Count to Number of households in postcode")
    household_summary_renamed_df = household_summary_df.withColumnRenamed("Count", "Number of households in postcode")
    log_dataframe_info(logger, household_summary_renamed_df, "Renamed household count column")

    logger.info("Checking for existing Number of households in postcode column in left dataframe")
    if "Number of households in postcode" in j_output_postcode.columns:
        logger.info("Renaming existing Number of households in postcode column in left dataframe")
        j_output_postcode = j_output_postcode.withColumnRenamed("Number of households in postcode", 
                                                            "Left_Number of households in postcode")

    logger.info("Joining inner join result with household summary on Compressed_Postcode")
    j_output_household, l_output_household, r_output_household = perform_join(
        j_output_postcode,
        household_summary_renamed_df,
        "Compressed_Postcode",
        logger
    )

    logger.info("Dropping Right_Compressed_Postcode from inner join result")
    if "Right_Compressed_Postcode" in j_output_household.columns:
        j_output_household = j_output_household.drop("Right_Compressed_Postcode")
        logger.info("Dropped Right_Compressed_Postcode from inner join")

    log_dataframe_info(logger, j_output_household, "Final result after household count join")

    #########################################################################################################
    # STEP 14: POSTCODE ID GENERATION AND FINAL PROCESSING                                                 #
    #########################################################################################################
    logger.info("Selecting unique Compressed_Postcode values from sorted_by_cb_key")
    unique_postcodes_df = sorted_by_cb_key.select("Compressed_Postcode").distinct()
    log_dataframe_info(logger, unique_postcodes_df, "Unique Compressed_Postcode values")

    logger.info("Adding RecordID column with auto-incrementing value starting from 1")
    window_spec = Window.orderBy("Compressed_Postcode")
    postcodes_with_id_df = unique_postcodes_df.withColumn(
        "RecordID", 
        row_number().over(window_spec).cast("int")
    )
    log_dataframe_info(logger, postcodes_with_id_df, "Added RecordID column")

    logger.info("Checking for existing Postcode ID column in left dataframe")
    if "Postcode ID" in j_output_household.columns:
        logger.info("Renaming existing Postcode ID column in left dataframe")
        j_output_household = j_output_household.withColumnRenamed("Postcode ID", "Left_Postcode ID")

    logger.info("Joining j_output_household with postcodes_with_id_df on Compressed_Postcode")
    j_output_postcode_id, l_output_postcode_id, r_output_postcode_id = perform_join(
        j_output_household,
        postcodes_with_id_df,
        "Compressed_Postcode",
        logger
    )

    logger.info("Renaming RecordID to Postcode ID")
    if "RecordID" in j_output_postcode_id.columns:
        j_output_postcode_id = j_output_postcode_id.withColumnRenamed("RecordID", "Postcode ID")

    logger.info("Dropping Right_Compressed_Postcode from inner join result")
    if "Right_Compressed_Postcode" in j_output_postcode_id.columns:
        j_output_postcode_id = j_output_postcode_id.drop("Right_Compressed_Postcode")
        logger.info("Dropped Right_Compressed_Postcode from inner join")

    logger.info("Adding 'Households Greater than or Equal to 6' column")
    j_output_with_household_flag = j_output_postcode_id.withColumn(
        "Households Greater than or Equal to 6",
        when(col("Number of households in postcode") >= 6, "Y").otherwise("")
    )
    log_dataframe_info(logger, j_output_with_household_flag, "Added household flag column")

    logger.info("Checking for pc_county_or_unitary_auth_code_2011 column")
    if "pc_county_or_unitary_auth_code_2011" in j_output_with_household_flag.columns:
        logger.info("Replacing commas in pc_county_or_unitary_auth_code_2011 column")
        j_output_final = j_output_with_household_flag.withColumn(
            "pc_county_or_unitary_auth_code_2011",
            regexp_replace(col("pc_county_or_unitary_auth_code_2011"), ",", "")
        )
        log_dataframe_info(logger, j_output_final, "Replaced commas in county code")
    else:
        logger.info("Column pc_county_or_unitary_auth_code_2011 not found, skipping comma replacement")
        j_output_final = j_output_with_household_flag
        log_dataframe_info(logger, j_output_final, "No changes made to data")

    logger.info("Optimizing final dataframe to prevent memory issues")
    j_output_final = j_output_final.repartition(10)
    j_output_final.cache()

    logger.info("Creating a final dataframe with the exact columns we need")
    all_columns = j_output_final.columns
    logger.info(f"Original columns: {len(all_columns)}")

    col_map = {col_name.lower(): col_name for col_name in all_columns}

    duplicates = {}
    for col_name in all_columns:
        col_lower = col_name.lower()
        if col_lower in duplicates:
            duplicates[col_lower].append(col_name)
        else:
            duplicates[col_lower] = [col_name]

    for col_lower, cols in duplicates.items():
        if len(cols) > 1:
            logger.info(f"Found duplicate column: {col_lower} appears as: {', '.join(cols)}")

    select_cols = []
    seen_cols = set()

    rename_mapping = {
        "left_number of people in postcode": "Number of people in postcode2",
        "left_number of households in postcode": "Number of households in postcode2", 
        "left_postcode id": "Postcode ID2",
        "right_available_for_match_esimedia": "Available_For_Match_ESIMedia",
        "number of people in postcode": "Number of people in postcode",
        "number of households in postcode": "Number of households in postcode",
        "postcode id": "Postcode ID",
        "available_for_adsmart_selection": "Available_For_Adsmart_Selection2",
        "right_pc_county_or_unitary_auth_code_2011": "Right_pc_county_or_unitary_auth_code_2011"
    }

    logger.info("Processing standard columns")
    for column in all_columns:
        col_lower = column.lower()
        
        if col_lower == "available_for_match_esimedia" and "right_available_for_match_esimedia" in col_map:
            logger.info(f"Skipping column to prevent duplicate: {column}")
            continue
            
        if col_lower in rename_mapping:
            continue
            
        if col_lower in seen_cols:
            logger.info(f"Skipping duplicate column: {column}")
            continue
            
        select_cols.append(col(column))
        seen_cols.add(col_lower)

    logger.info("Processing renamed columns")
    for source_col_lower, target_name in rename_mapping.items():
        if source_col_lower not in col_map:
            logger.info(f"Column not found for renaming: {source_col_lower}")
            continue
            
        if target_name.lower() in seen_cols:
            logger.info(f"Skipping rename to prevent duplicate: {source_col_lower} → {target_name}")
            continue
        
        source_col = col_map[source_col_lower]
        logger.info(f"Renaming column: {source_col} → {target_name}")
        select_cols.append(col(source_col).alias(target_name))
        seen_cols.add(source_col_lower)
        seen_cols.add(target_name.lower())

    logger.info(f"Creating new DataFrame with {len(select_cols)} columns")
    j_output_final_unique = j_output_final.select(*select_cols)
    logger.info("DataFrame column selection and renaming completed")

    expected_columns = [
    'cb_key_db_person', 'cb_key_household', 'mailable_postcode', 'Postcode Area', 'Postcode District', 'Postcode sector', 'Person_Mailable_flag', 
    'Prospect Email', 'Compressed_Postcode', 'Number of people in postcode', 'Number of households in postcode', 'Households Greater than or Equal to 6', 
    'Postcode ID', 'Available_For_Facebook', 'Available_For_Adsmart_Selection2', 'Available_For_LiveRamp_Selection', 
    'Available_For_Partially_Addressed_Mail_Selection', 'Available_For_Match_ESIMedia', 'pc_county_or_unitary_auth_code_2011', 'C000001A', 'C000005', 'C000002A', 'C000002B', 'C000002D', 'C000002E', 'C000002F', 'C000003A', 'C000003B', 'C000004', 'C000008A', 
    'C000008B', 'C000014A', 'C000018A', 'C000011A', 'C000011B', 'C000017', 'C000016', 'C000013', 'C000010A', 'C000010B', 'C000019', 'C000009', 'C000015', 'C000020A', 'C000020B', 'C000020C', 'C000020D', 'C000020E', 'C000020F', 'C000024A', 'C000024B', 'C000024C', 'C000021A', 'C000025A', 'C000025B', 'C000025C', 'C000025D', 'C000025E', 'C000025F', 'C000022', 'C000023', 'C000029', 'C000031', 'C000063', 'C000064', 'C000059', 'C000092', 'C000065',
    'C000066', 'C000067A', 'C000067B', 'C000067C', 'C000067D', 'C000067E', 'C000067F', 'C000067G', 'C000067H', 'C000067I', 'C000067J', 'C000067K', 'C000067L', 'C000067M', 'C000067N', 'C000067O', 'C000067P', 'C000067Q', 'C000067R', 'C000067S', 'C000067T', 'C000067U', 'C000067V', 'C000067W', 'C000067X', 'C000067Y', 'C000067Z', 'C000067AA', 'C000006A', 'C000006B', 'C000006C', 'C000006D', 'C000006E', 'C000006F', 'C000006G', 'C000006H', 'C000006I', 
    'C000006J', 'C000006K', 'C000006L', 'C000007A', 'C000007B', 'C000007C', 'C000007D', 'C000007E', 'C000007F', 'C000007G', 'C000007H', 'C000007I', 'C000007J', 'C000007K', 'C000007L', 'C000007M', 'C000007N', 'C000007O', 'C000007P', 'C000007Q', 'C000007R', 'C000007S', 'C000007T', 'C000007U', 'C000007V', 'C000007W', 'C000007X', 'C000007Y', 'C000007Z', 'C000007AA', 'C000007AB', 'C000007AC', 'C000007AD', 'C000007AE', 'C000007AF', 'C000007AG', 'C000007AH', 'C000007AI', 'C000007AJ', 'C000007AK', 'C000007AL', 'C000007AM', 'C000007AN', 'C000007AO', 'C000007AP', 'C000007AQ', 'C000007AR', 'C000007AS', 'C000007AT', 'C000068AA', 'C000068AB', 'C000068AC', 'C000068AD', 'C000068AE', 'C000068AF', 'C000068AG', 'C000068AH', 'C000068AI', 'C000068AJ', 'C000068AK', 'C000068AL', 'C000068AM', 'C000068AN', 'C000068AO', 'C000068AP', 'C000068AQ', 'C000068AR', 'C000068AS', 'C000068AT', 'C000068AU', 'C000068AV', 'C000068AW', 'C000068AX', 'C000068AY', 'C000068AZ', 'C000068BA', 'C000068BB', 'C000068BC', 'C000068BD', 'C000068BE', 'C000068BF', 'C000068BG', 'C000068BH', 'C000068BI', 'C000068BJ', 'C000068BK', 'C000068BL', 'C000068BM', 'C000068BN', 'C000068BO', 'C000068BP', 'C000068BQ', 'C000068BR', 'C000068BS', 'C000068BT', 'C000068BU', 'C000068BV', 'C000068BW', 'C000068BX', 'C000068BY', 'C000068BZ', 'C000068CA', 'C000068CB', 'C000068CC', 'C000068CD', 'C000068CE', 'C000068CF', 'C000068CG', 'C000068CH', 'C000068CI', 'C000068CJ', 'C000068CK', 'C000068CL', 'C000068CM', 'C000068CN', 'C000068CO', 'C000068CP', 'C000068CQ', 'C000398', 'C000399', 'C000400', 'C000401', 'C000404', 'C000405', 'C000402', 'C000403', 'C000417', 'C000418', 'C000419', 'C000420', 'C000421', 'C000422', 'C000423', 'C000424', 'C000425', 'C000426', 'C000427', 'C000428', 'C000429', 'C000430', 'C000431', 'C000432', 'C000433', 'C000434', 'C000435', 'C000436', 'C000437', 'C000438', 'C000439', 'C000440', 'C000441', 'C000442', 'C000443', 'C000444', 'C000445', 'C000446', 'C000447', 'C000448', 'C000449', 'C000450', 'C000451', 'C000452', 'C000453', 'C000454', 'C000455', 'C000456', 'C000457', 'C000458', 'C000459', 'C000460', 'C000461', 'C000462', 'C000463', 'C000464', 'C000465', 'C000466', 'C000467', 'C000468', 'C000469', 'C000470', 'C000471', 'C000472', 'C000473', 'C000474', 'C000475', 'C000476', 'C000477', 'C000478', 'C000479', 'C000480', 'C000481', 'C000482', 'C000483', 'C000484', 'C000485', 'C000486', 'C000487', 'C000488', 'C000489', 'C000490', 'C000491', 'C000492', 'C000493', 'C000494', 'C000495', 'C000496', 'C000497', 'C000498', 'C000499', 'C000500', 'C000501', 'C000502', 'C000503', 'C000504', 'C000505', 'C000506', 'C000507', 'C000508', 'C000509', 'C000510', 'C000511', 'C000512', 'C000513', 'C000514', 'C000515', 'C000516', 'C000517', 'C000518', 'C000519', 'C000520', 'C000521', 'C000522', 'C000523', 'C000524', 'C000525', 'C000526', 'C000527', 'C000528', 'C000529', 'C000530', 'C000531', 'C000532', 'C000533', 'C000534', 'C000535', 'C000536', 'C000537', 'C000538', 'C000539', 'C000540', 'C000541', 'C000542', 'C000543', 'C000544', 'C000545', 'C000546', 'C000547', 'C000548', 'C000549', 'C000550', 'C000551', 'C000552', 'C000553', 'C000554', 'C000555', 'C000556', 'C000557', 'C000558', 'C000559', 'C000560', 'C000561', 'C000562', 'C000563', 'C000564', 'C000565', 'C000566', 'C000567', 'C000568', 'C000569', 'C000570', 'C000571', 'C000572', 'C000573', 'C000574', 'C000575', 'C000576', 'C000577', 'C000578', 'C000579', 'C000580', 'C000581', 'C000582', 'C000583', 'C000584', 'C000585', 'C000586', 'C000587', 'C000588', 'C000589', 'C000590', 'C000591', 'C000592', 'C000593', 'C000594', 'C000595', 'C000596', 'C000597', 'C000598', 'C000599', 'C000600', 'C000601', 'C000602', 'C000603', 'C000604', 'C000605', 'C000606', 'C000607', 'C000608', 'C000609', 'C000610', 'C000611', 'C000612', 'C000613', 'C000614', 'C000615', 'C000616', 'C000617', 'C000618', 'C000619', 'C000620', 'C000621', 'C000622', 'C000623', 'C000624', 'C000625', 'C000626', 'C000627', 'C000628', 'C000629', 'C000630', 'C000631', 'C000632', 'C000633', 'C000634', 'C000635', 'C000636', 'C000637', 'C000638', 'C000639', 'C000640', 'C000641', 'C000642', 'C000643', 'C000644', 'C000645', 'C000646', 'C000647', 'C000648', 'C000649', 'C000650', 'C000651', 'C000652', 'C000653', 'C000654', 'C000655', 'C000656', 'C000657', 'C000658', 'C000659', 'C000660', 'C000661', 'C000662', 'C000663', 'C000664', 'C000665', 'C000666', 'C000667', 'C000668', 'C000669', 'C000670',
    'C000671', 'C000672', 'C000673', 'C000674', 'C000675', 'C000676', 'C000677', 'C000678', 'C000679', 'C000680', 'C000681', 'C000682', 'C000683', 'C000684', 'C000685', 'C000686', 'C000687', 'C000688', 'C000689', 'C000690', 'C000691', 'C000692', 'C000693', 'C000694', 'C000695', 'C000696', 'C000697', 'C000698', 'C000699', 
    'C000700', 'C000701', 'C000702', 'C000703', 'C000704', 'C000705', 'C000706', 'C000707', 'C000708', 'C000709',
    'C000710', 'C000711', 'C000712', 'C000713','Original_Row_Number'  
    ]

    logger.info("Setting up exact column ordering for output file")
    try:
        logger.info("Reordering columns to match required specification")
        ordered_df = j_output_final_unique.select(*expected_columns)
        logger.info("Column reordering completed successfully")
    except Exception as e:
        logger.error(f"Error reordering columns: {e}")
        raise ValueError("Failed to reorder columns")

    current_date_str = datetime.now().strftime("%Y%m%d")
    final_output_path = f"{args.output_dir}/{current_date_str}_module1_output.csv"
    logger.info(f"Saving final output to: {final_output_path}")
    ordered_df.write.mode("overwrite").option("header", True).csv(final_output_path)
    logger.info("Module 1 processing completed successfully")

    #########################################################################################################
    # STEP 15: FINAL SUMMARIZATION AND OUTPUT                                                              #
    #########################################################################################################
    logger.info("Creating month string for output files")
    current_month_str = datetime.now().strftime("%B%y") + "_Supply"
    logger.info(f"Month string: {current_month_str}")

    logger.info("Adding month column to final output")
    j_output_final_with_month = j_output_final_unique.withColumn("month", lit(current_month_str))
    log_dataframe_info(logger, j_output_final_with_month, "Added month column to final output")

    logger.info("Reordering columns for final output")
    expected_columns = [
    'cb_key_db_person', 'cb_key_household', 'mailable_postcode', 'Postcode Area', 'Postcode District', 'Postcode sector', 'Person_Mailable_flag', 
    'Prospect Email', 'Compressed_Postcode', 'Number of people in postcode', 'Number of households in postcode', 'Households Greater than or Equal to 6', 
    'Postcode ID', 'Available_For_Facebook', 'Available_For_Adsmart_Selection2', 'Available_For_LiveRamp_Selection', 
    'Available_For_Partially_Addressed_Mail_Selection', 'Available_For_Match_ESIMedia', 'pc_county_or_unitary_auth_code_2011', 'C000001A', 'C000005', 'C000002A', 'C000002B', 'C000002D', 'C000002E', 'C000002F', 'C000003A', 'C000003B', 'C000004', 'C000008A', 
    'C000008B', 'C000014A', 'C000018A', 'C000011A', 'C000011B', 'C000017', 'C000016', 'C000013', 'C000010A', 'C000010B', 'C000019', 'C000009', 'C000015', 'C000020A', 'C000020B', 'C000020C', 'C000020D', 'C000020E', 'C000020F', 'C000024A', 'C000024B', 'C000024C', 'C000021A', 'C000025A', 'C000025B', 'C000025C', 'C000025D', 'C000025E', 'C000025F', 'C000022', 'C000023', 'C000029', 'C000031', 'C000063', 'C000064', 'C000059', 'C000092', 'C000065',
    'C000066', 'C000067A', 'C000067B', 'C000067C', 'C000067D', 'C000067E', 'C000067F', 'C000067G', 'C000067H', 'C000067I', 'C000067J', 'C000067K', 'C000067L', 'C000067M', 'C000067N', 'C000067O', 'C000067P', 'C000067Q', 'C000067R', 'C000067S', 'C000067T', 'C000067U', 'C000067V', 'C000067W', 'C000067X', 'C000067Y', 'C000067Z', 'C000067AA', 'C000006A', 'C000006B', 'C000006C', 'C000006D', 'C000006E', 'C000006F', 'C000006G', 'C000006H', 'C000006I', 
    'C000006J', 'C000006K', 'C000006L', 'C000007A', 'C000007B', 'C000007C', 'C000007D', 'C000007E', 'C000007F', 'C000007G', 'C000007H', 'C000007I', 'C000007J', 'C000007K', 'C000007L', 'C000007M', 'C000007N', 'C000007O', 'C000007P', 'C000007Q', 'C000007R', 'C000007S', 'C000007T', 'C000007U', 'C000007V', 'C000007W', 'C000007X', 'C000007Y', 'C000007Z', 'C000007AA', 'C000007AB', 'C000007AC', 'C000007AD', 'C000007AE', 'C000007AF', 'C000007AG', 'C000007AH', 'C000007AI', 'C000007AJ', 'C000007AK', 'C000007AL', 'C000007AM', 'C000007AN', 'C000007AO', 'C000007AP', 'C000007AQ', 'C000007AR', 'C000007AS', 'C000007AT', 'C000068AA', 'C000068AB', 'C000068AC', 'C000068AD', 'C000068AE', 'C000068AF', 'C000068AG', 'C000068AH', 'C000068AI', 'C000068AJ', 'C000068AK', 'C000068AL', 'C000068AM', 'C000068AN', 'C000068AO', 'C000068AP', 'C000068AQ', 'C000068AR', 'C000068AS', 'C000068AT', 'C000068AU', 'C000068AV', 'C000068AW', 'C000068AX', 'C000068AY', 'C000068AZ', 'C000068BA', 'C000068BB', 'C000068BC', 'C000068BD', 'C000068BE', 'C000068BF', 'C000068BG', 'C000068BH', 'C000068BI', 'C000068BJ', 'C000068BK', 'C000068BL', 'C000068BM', 'C000068BN', 'C000068BO', 'C000068BP', 'C000068BQ', 'C000068BR', 'C000068BS', 'C000068BT', 'C000068BU', 'C000068BV', 'C000068BW', 'C000068BX', 'C000068BY', 'C000068BZ', 'C000068CA', 'C000068CB', 'C000068CC', 'C000068CD', 'C000068CE', 'C000068CF', 'C000068CG', 'C000068CH', 'C000068CI', 'C000068CJ', 'C000068CK', 'C000068CL', 'C000068CM', 'C000068CN', 'C000068CO', 'C000068CP', 'C000068CQ', 'C000398', 'C000399', 'C000400', 'C000401', 'C000404', 'C000405', 'C000402', 'C000403', 'C000417', 'C000418', 'C000419', 'C000420', 'C000421', 'C000422', 'C000423', 'C000424', 'C000425', 'C000426', 'C000427', 'C000428', 'C000429', 'C000430', 'C000431', 'C000432', 'C000433', 'C000434', 'C000435', 'C000436', 'C000437', 'C000438', 'C000439', 'C000440', 'C000441', 'C000442', 'C000443', 'C000444', 'C000445', 'C000446', 'C000447', 'C000448', 'C000449', 'C000450', 'C000451', 'C000452', 'C000453', 'C000454', 'C000455', 'C000456', 'C000457', 'C000458', 'C000459', 'C000460', 'C000461', 'C000462', 'C000463', 'C000464', 'C000465', 'C000466', 'C000467', 'C000468', 'C000469', 'C000470', 'C000471', 'C000472', 'C000473', 'C000474', 'C000475', 'C000476', 'C000477', 'C000478', 'C000479', 'C000480', 'C000481', 'C000482', 'C000483', 'C000484', 'C000485', 'C000486', 'C000487', 'C000488', 'C000489', 'C000490', 'C000491', 'C000492', 'C000493', 'C000494', 'C000495', 'C000496', 'C000497', 'C000498', 'C000499', 'C000500', 'C000501', 'C000502', 'C000503', 'C000504', 'C000505', 'C000506', 'C000507', 'C000508', 'C000509', 'C000510', 'C000511', 'C000512', 'C000513', 'C000514', 'C000515', 'C000516', 'C000517', 'C000518', 'C000519', 'C000520', 'C000521', 'C000522', 'C000523', 'C000524', 'C000525', 'C000526', 'C000527', 'C000528', 'C000529', 'C000530', 'C000531', 'C000532', 'C000533', 'C000534', 'C000535', 'C000536', 'C000537', 'C000538', 'C000539', 'C000540', 'C000541', 'C000542', 'C000543', 'C000544', 'C000545', 'C000546', 'C000547', 'C000548', 'C000549', 'C000550', 'C000551', 'C000552', 'C000553', 'C000554', 'C000555', 'C000556', 'C000557', 'C000558', 'C000559', 'C000560', 'C000561', 'C000562', 'C000563', 'C000564', 'C000565', 'C000566', 'C000567', 'C000568', 'C000569', 'C000570', 'C000571', 'C000572', 'C000573', 'C000574', 'C000575', 'C000576', 'C000577', 'C000578', 'C000579', 'C000580', 'C000581', 'C000582', 'C000583', 'C000584', 'C000585', 'C000586', 'C000587', 'C000588', 'C000589', 'C000590', 'C000591', 'C000592', 'C000593', 'C000594', 'C000595', 'C000596', 'C000597', 'C000598', 'C000599', 'C000600', 'C000601', 'C000602', 'C000603', 'C000604', 'C000605', 'C000606', 'C000607', 'C000608', 'C000609', 'C000610', 'C000611', 'C000612', 'C000613', 'C000614', 'C000615', 'C000616', 'C000617', 'C000618', 'C000619', 'C000620', 'C000621', 'C000622', 'C000623', 'C000624', 'C000625', 'C000626', 'C000627', 'C000628', 'C000629', 'C000630', 'C000631', 'C000632', 'C000633', 'C000634', 'C000635', 'C000636', 'C000637', 'C000638', 'C000639', 'C000640', 'C000641', 'C000642', 'C000643', 'C000644', 'C000645', 'C000646', 'C000647', 'C000648', 'C000649', 'C000650', 'C000651', 'C000652', 'C000653', 'C000654', 'C000655', 'C000656', 'C000657', 'C000658', 'C000659', 'C000660', 'C000661', 'C000662', 'C000663', 'C000664', 'C000665', 'C000666', 'C000667', 'C000668', 'C000669', 'C000670',
    'C000671', 'C000672', 'C000673', 'C000674', 'C000675', 'C000676', 'C000677', 'C000678', 'C000679', 'C000680', 'C000681', 'C000682', 'C000683', 'C000684', 'C000685', 'C000686', 'C000687', 'C000688', 'C000689', 'C000690', 'C000691', 'C000692', 'C000693', 'C000694', 'C000695', 'C000696', 'C000697', 'C000698', 'C000699', 
    'C000700', 'C000701', 'C000702', 'C000703', 'C000704', 'C000705', 'C000706', 'C000707', 'C000708', 'C000709',
    'C000710', 'C000711', 'C000712', 'C000713'  
    ]
    ordered_df = j_output_final_with_month.select(*expected_columns)

    logger.info("Saving full dataset as pipe-delimited TXT file")
    full_output_path_txt = f"{args.output_dir}/Digital_taxonomy_Audience_Engine_{current_month_str}.txt"
    logger.info(f"Saving full dataset as pipe-delimited TXT to: {full_output_path_txt}")
    ordered_df.coalesce(1).write.mode("overwrite") \
        .option("header", True) \
        .option("delimiter", "|") \
        .option("quote", "") \
        .option("escape", "") \
        .option("nullValue", "") \
        .option("emptyValue", "") \
        .csv(full_output_path_txt)
    logger.info("Full dataset saved successfully")

    logger.info("Saving count file")
    final_count = ordered_df.count()
    count_output_path_txt = f"{args.output_dir}/Digital_taxonomy_Count_{current_month_str}.txt"
    logger.info(f"Saving count file to: {count_output_path_txt}")
    
    count_data = [(f"Total Records: {final_count:,}",)]
    count_df = spark.createDataFrame(count_data, ["Count"])
    count_df.coalesce(1).write.mode("overwrite").option("header", False).csv(count_output_path_txt)

    # Create file summary for Adsmart liveramp files used
    logger.info("Creating file summary for Adsmart liveramp files used")
    file_summaries = []
    
    files_info = [
        ("Digital Taxonomy", args.digital_taxonomy_file),
        ("Experian Match", args.experian_match_file),
        ("PAM Directory", args.pam_directory_file),
        ("CBAF Utility", args.cbaf_utility_file),
        ("Utility", args.utility_file),
        ("Counties Lookup", args.counties_lookup_file),
        ("Match Output", args.match_output_file)
    ]
    
    for file_type, file_path in files_info:
        file_summary_data = [(file_type, file_path)]
        file_summary_df = spark.createDataFrame(file_summary_data, ["File Type", "File Path"])
        file_summaries.append(file_summary_df)
    
    # Union all file summaries
    file_summary_df = file_summaries[0]
    for df in file_summaries[1:]:
        file_summary_df = file_summary_df.unionByName(df)

    adsmart_liveramp_path = f"{args.output_dir}/Adsmart_liveramp_files_used.csv"
    logger.info(f"Saving file summary to CSV: {adsmart_liveramp_path}")
    file_summary_df.coalesce(1).write.mode("overwrite").option("header", True).csv(adsmart_liveramp_path)

    logger.info("All processing completed successfully")
    logger.info(f"Final record count: {final_count:,}")
    logger.info("Stopping Spark session")
    spark.stop()

if __name__ == "__main__":
    main()