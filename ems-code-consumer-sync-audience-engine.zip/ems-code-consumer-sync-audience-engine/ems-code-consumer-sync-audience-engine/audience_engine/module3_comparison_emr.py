#!/usr/bin/env python
"""
Module 3 - Comparison Processing for EMR Serverless
==================================================
This script performs comparison between current and previous month Excel files.
Converted for EMR Serverless with S3 storage - maintains exact same logic as new_module3.py
"""

import os
import argparse
import pandas as pd
import tempfile
import json
import boto3
import shutil
import fnmatch
from datetime import datetime
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, lit, count, when, isnan, expr, row_number, concat_ws, desc, asc
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType, IntegerType, StringType
from typing import List, Dict, Tuple, Optional
import logging

# Simple logging for EMR Serverless
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Import openpyxl for Excel operations
try:
    import openpyxl
    logger.info("openpyxl is available")
except ImportError:
    logger.error("openpyxl is not available - Excel functionality will not work")
    raise

spark = None

def parse_s3_path(s3_path):
    """Parse S3 path into bucket and key components."""
    if s3_path.startswith("s3a://"):
        s3_path = s3_path[6:]
    elif s3_path.startswith("s3://"):
        s3_path = s3_path[5:]
    
    parts = s3_path.split('/', 1)
    bucket = parts[0]
    key = parts[1] if len(parts) > 1 else ""
    
    return bucket, key

def s3_path_exists(s3_path):
    """Check if an S3 path exists."""
    try:
        bucket, key = parse_s3_path(s3_path)
        s3 = boto3.client('s3')
        
        if not key:
            # Check if bucket exists
            s3.head_bucket(Bucket=bucket)
            return True
        
        # Check if it's a directory (prefix) or file
        response = s3.list_objects_v2(Bucket=bucket, Prefix=key, MaxKeys=1)
        return 'Contents' in response
        
    except Exception as e:
        logger.warning(f"S3 path does not exist: {s3_path} - {str(e)}")
        return False

def resolve_s3_pattern(s3_path_pattern):
    """Resolve S3 pattern with wildcards to actual file path."""
    try:
        bucket, key_pattern = parse_s3_path(s3_path_pattern)
        s3 = boto3.client('s3')
        
        if '*' not in key_pattern:
            return s3_path_pattern
        
        # Extract prefix before first wildcard for efficient S3 listing
        prefix = key_pattern.split('*')[0]
        
        paginator = s3.get_paginator('list_objects_v2')
        page_iterator = paginator.paginate(Bucket=bucket, Prefix=prefix)
        
        for page in page_iterator:
            if 'Contents' in page:
                for obj in page['Contents']:
                    obj_key = obj['Key']
                    if fnmatch.fnmatch(obj_key, key_pattern):
                        resolved_path = f"s3://{bucket}/{obj_key}"
                        logger.info(f"Resolved pattern {s3_path_pattern} to: {resolved_path}")
                        return resolved_path
        
        logger.warning(f"No files found matching pattern: {key_pattern}")
        return None
        
    except Exception as e:
        logger.error(f"Error resolving S3 pattern {s3_path_pattern}: {e}")
        return None

def download_file_from_s3(s3_path, local_path):
    """Download a file from S3 to local path."""
    try:
        bucket, key = parse_s3_path(s3_path)
        s3 = boto3.client('s3')
        
        logger.info(f"Downloading {s3_path} to {local_path}")
        s3.download_file(bucket, key, local_path)
        logger.info(f"Successfully downloaded to: {local_path}")
        return True
        
    except Exception as e:
        logger.error(f"Error downloading from S3: {str(e)}")
        return False

def upload_file_to_s3(local_file_path, s3_path):
    """Upload a local file to S3."""
    try:
        bucket, key = parse_s3_path(s3_path)
        s3 = boto3.client('s3')
        
        logger.info(f"Uploading {local_file_path} to s3://{bucket}/{key}")
        s3.upload_file(local_file_path, bucket, key)
        logger.info(f"Successfully uploaded to S3: {s3_path}")
        return True
        
    except Exception as e:
        logger.error(f"Error uploading to S3: {str(e)}")
        return False

def save_to_csv(df: DataFrame, output_path: str, header: bool = True) -> None:
    """Save DataFrame to CSV format"""
    logger.info(f"Saving CSV to path: {output_path}")
    df.coalesce(1).write.mode("overwrite").option("header", header).csv(output_path)

def log_dataframe_info(logger, df: DataFrame, stage_name: str) -> Tuple[int, int]:
    """Log DataFrame information including row count and schema"""
    column_count = len(df.columns)
    
    logger.info(f"Stage: {stage_name}")
    logger.info(f"Column count: {column_count}")
    
    if column_count <= 50:
        logger.info(f"Columns: {', '.join(df.columns)}")
    else:
        first_cols = df.columns[:20]
        last_cols = df.columns[-20:]
        logger.info(f"First 20 columns: {', '.join(first_cols)}")
        logger.info(f"Last 20 columns: {', '.join(last_cols)}")
        logger.info(f"Total columns: {column_count}")
    
    row_count = df.count()
    logger.info(f"Row count: {row_count}")
    
    return row_count, column_count

def read_excel_sheet_from_s3(spark: SparkSession, s3_file_path: str, sheet_name: str) -> DataFrame:
    """Read a specific sheet from an Excel file in S3, add original order, and convert to Spark DataFrame"""
    logger.info(f"Reading Excel file from S3: {s3_file_path}, sheet: {sheet_name}")
    
    try:
        # Resolve S3 pattern if it contains wildcards
        actual_s3_path = resolve_s3_pattern(s3_file_path)
        if not actual_s3_path:
            raise FileNotFoundError(f"No file found matching pattern: {s3_file_path}")
        
        # Check if file exists
        if not s3_path_exists(actual_s3_path):
            raise FileNotFoundError(f"Excel file not found in S3: {actual_s3_path}")
        
        # Create temporary directory
        temp_dir = tempfile.mkdtemp()
        filename = os.path.basename(actual_s3_path.split('/')[-1])
        if not filename.endswith('.xlsx'):
            filename += '.xlsx'
        local_file_path = os.path.join(temp_dir, filename)
        
        # Download file from S3
        if not download_file_from_s3(actual_s3_path, local_file_path):
            raise Exception(f"Failed to download file from S3: {actual_s3_path}")
        
        # Read Excel file using pandas
        logger.info(f"Reading Excel file locally: {local_file_path}")
        try:
            pandas_df = pd.read_excel(local_file_path, sheet_name=sheet_name)
            logger.info("Successfully read Excel file")
        except Exception as excel_err:
            logger.warning(f"Error reading Excel file: {str(excel_err)}")
            # Try to find CSV backup in S3
            csv_backup_pattern = actual_s3_path.replace('.xlsx', '.csv')
            csv_backup_dir = csv_backup_pattern + "/"
            
            logger.info(f"Looking for CSV backup at: {csv_backup_dir}")
            if s3_path_exists(csv_backup_dir):
                logger.info("Found CSV backup, reading it instead")
                # Convert to s3a:// for Spark
                spark_csv_path = csv_backup_dir.replace("s3://", "s3a://")
                csv_df = spark.read.option("header", "true").csv(spark_csv_path)
                
                # Add __OriginalOrder column
                csv_df = csv_df.withColumn("__OriginalOrder", row_number().over(Window.orderBy(lit(1))) - 1)
                
                # Clean up temp directory
                shutil.rmtree(temp_dir)
                return csv_df
            else:
                raise excel_err

        logger.info("Adding '__OriginalOrder' column to preserve initial row order.")
        pandas_df.reset_index(inplace=True)
        pandas_df.rename(columns={'index': '__OriginalOrder'}, inplace=True)

        logger.info("Converting all columns to string type to avoid type conflicts")
        for col_name in pandas_df.columns:
            if col_name != '__OriginalOrder':
                pandas_df[col_name] = pandas_df[col_name].astype(str)
        
        # Convert to Spark DataFrame
        spark_df = spark.createDataFrame(pandas_df)
        
        # Clean up temp directory
        shutil.rmtree(temp_dir)
        
        logger.info(f"Successfully read Excel data from {sheet_name}")
        return spark_df
    
    except Exception as e:
        logger.error(f"Error reading Excel file from S3: {str(e)}")
        # Clean up temp directory if it exists
        try:
            if 'temp_dir' in locals():
                shutil.rmtree(temp_dir)
        except:
            pass
        raise

def select_columns(df: DataFrame, columns: List[str], logger) -> DataFrame:
    """Select specified columns from DataFrame"""
    logger.info(f"Selecting {len(columns)} columns")
    
    missing_columns = [col for col in columns if col not in df.columns]
    if missing_columns:
        logger.warning(f"These columns don't exist in the DataFrame: {', '.join(missing_columns)}")
        columns = [col for col in columns if col in df.columns]
    
    if len(columns) <= 20:
        logger.info(f"Selecting columns: {', '.join(columns)}")
    else:
        logger.info(f"Selecting {len(columns)} columns including: {', '.join(columns[:10])}... and {len(columns)-10} more")
    
    return df.select(*columns)

def add_blank_percentage(df: DataFrame, logger) -> DataFrame:
    """Create a new column with percentage of blanks based on CountBlank and Count"""
    logger.info("Calculating percentage of blanks")
    return df.withColumn("CountBlank", col("CountBlank").cast(DoubleType())) \
             .withColumn("Count", col("Count").cast(DoubleType())) \
             .withColumn("%_Blanks", (col("CountBlank") / col("Count") * 100).cast(DoubleType()))

def dynamic_rename(df: DataFrame, field_names: List[str], new_name: str, logger) -> DataFrame:
    """Dynamically rename specific fields based on condition"""
    logger.info(f"Dynamically renaming fields: {', '.join(field_names)} to {new_name}")
    select_expressions = [col(c).alias(new_name) if c in field_names else col(c) for c in df.columns]
    return df.select(*select_expressions)

def perform_join(left_df: DataFrame, right_df: DataFrame, left_column: str, right_column: str, logger) -> Tuple[DataFrame, DataFrame, DataFrame]:
    """Perform a join and return inner join (J), left only (L), and right only (R)"""
    logger.info(f"Performing join on left.{left_column} = right.{right_column}")
    
    left_df = left_df.withColumnRenamed("__OriginalOrder", "__CurrentOrder")
    right_df = right_df.withColumnRenamed("__OriginalOrder", "__PreviousOrder")
        
    join_condition = left_df[left_column] == right_df[right_column]
    
    j_output = left_df.join(right_df, join_condition, "inner")
    l_output = left_df.join(right_df, join_condition, "left_anti")
    r_output = right_df.join(left_df, join_condition, "left_anti")
    
    j_rows, l_rows, r_rows = j_output.count(), l_output.count(), r_output.count()
    logger.info(f"Join results - Inner: {j_rows} rows | Left only: {l_rows} rows | Right only: {r_rows} rows")
    
    if right_column in j_output.columns and left_column in j_output.columns and right_column != left_column:
        logger.info(f"Dropping {right_column} column from inner join result")
        j_output = j_output.drop(right_column)
    
    if "__PreviousOrder" in j_output.columns:
        j_output = j_output.drop("__PreviousOrder")
        
    return j_output, l_output, r_output

def add_continuous_record_id(df: DataFrame, start_id: int, order_by_col: str = "Name") -> DataFrame:
    """Add RecordID column with continuous numbering"""
    logger.info(f"Adding continuous RecordID starting from {start_id}, ordering by {order_by_col}")
    
    window_spec = Window.orderBy(order_by_col)
    
    if "RecordID" in df.columns:
        df = df.drop("RecordID")
    
    df_with_id = df.withColumn("RecordID", (row_number().over(window_spec) + start_id - 1).cast(IntegerType()))
    
    all_cols = df_with_id.columns
    all_cols.remove("RecordID")
    reordered_cols = ["RecordID"] + all_cols
    
    return df_with_id.select(*reordered_cols)

def save_excel_to_s3(df: DataFrame, s3_output_path: str, sheet_name: str = "Stats") -> bool:
    """Save DataFrame as Excel file to S3"""
    try:
        # Create temporary directory
        temp_dir = tempfile.mkdtemp()
        filename = os.path.basename(s3_output_path.split('/')[-1])
        if not filename.endswith('.xlsx'):
            filename += '.xlsx'
        local_excel_path = os.path.join(temp_dir, filename)
        
        # Convert to pandas and save locally
        row_count = df.count()
        if row_count > 1000000:
            logger.warning(f"Large DataFrame with {row_count} rows, saving only first 1,000,000 rows to Excel")
            pandas_df = df.limit(1000000).toPandas()
        else:
            pandas_df = df.toPandas()
        
        logger.info(f"Saving Excel locally to: {local_excel_path}")
        with pd.ExcelWriter(local_excel_path, engine='openpyxl') as writer:
            pandas_df.to_excel(writer, sheet_name=sheet_name, index=False)
        
        # Upload to S3
        success = upload_file_to_s3(local_excel_path, s3_output_path)
        
        # Also save CSV backup
        csv_backup_path = s3_output_path.replace('.xlsx', '.csv')
        csv_backup_dir = csv_backup_path + "/"
        logger.info(f"Saving CSV backup to S3: {csv_backup_dir}")
        
        # Convert s3:// to s3a:// for Spark
        spark_csv_path = csv_backup_dir.replace("s3://", "s3a://")
        save_to_csv(df, spark_csv_path)
        
        # Clean up temp directory
        shutil.rmtree(temp_dir)
        
        return success
        
    except Exception as e:
        logger.error(f"Error saving Excel to S3: {str(e)}")
        # Clean up temp directory if it exists
        try:
            if 'temp_dir' in locals():
                shutil.rmtree(temp_dir)
        except:
            pass
        return False

def main():
    """Main function to run Module 3 comparison processing for EMR."""
    global spark
    
    parser = argparse.ArgumentParser(description="Process current and previous Excel files for Module 3.")
    parser.add_argument('--current_file', required=True, help='S3 path to current Excel file (supports wildcards)')
    parser.add_argument('--previous_file', required=True, help='S3 path to previous Excel file (supports wildcards)')
    parser.add_argument('--output_dir', required=True, help='S3 directory for output files')
    parser.add_argument('--sheet_name', default='Stats', help='Name of the sheet to process (default: Stats)')
    
    args = parser.parse_args()
    
    logger.info("Module 3 - Starting comparison processing for EMR")
    logger.info(f"Current file: {args.current_file}")
    logger.info(f"Previous file: {args.previous_file}")
    logger.info(f"Output directory: {args.output_dir}")
    logger.info(f"Sheet name: {args.sheet_name}")
    
    # Initialize Spark session for EMR
    try:
        spark = SparkSession.builder \
            .appName("Module3_Comparison_EMR") \
            .getOrCreate()
        
        spark.sparkContext.setLogLevel("WARN")
        logger.info("SparkSession initialized successfully for EMR")
    except Exception as e:
        logger.error(f"Failed to initialize SparkSession: {str(e)}")
        raise

    max_record_id = 0
    
    try:
        # STEP 1: READ CURRENT EXCEL FILE AND PROCESS DATA
        logger.info("STEP 1: Processing current data")
        current_df = read_excel_sheet_from_s3(spark, args.current_file, args.sheet_name)
        log_dataframe_info(logger, current_df, "Current Excel data read")

        columns_to_select = ["__OriginalOrder", "Name", "Min_Value", "Max_Value", "CountBlank", "CountNonBlank", "Count", "FileName"]
        current_selected_df = select_columns(current_df, columns_to_select, logger)
        log_dataframe_info(logger, current_selected_df, "Selected columns from current data")

        current_with_id_df = add_continuous_record_id(current_selected_df, 1, "Name")
        max_record_id = current_with_id_df.agg({"RecordID": "max"}).collect()[0][0] or 0
        logger.info(f"Updated max_record_id to {max_record_id} after processing current data")

        current_with_blanks_df = add_blank_percentage(current_with_id_df, logger)
        current_with_blanks_df = current_with_blanks_df.withColumnRenamed("%_Blanks", "Current_%_Blanks")

        current_renamed_df = current_with_blanks_df.select(
            col("RecordID"), col("__OriginalOrder"), col("Name"),
            col("Min_Value").alias("Current_Min_Value"), col("Max_Value").alias("Current_Max_Value"),
            col("CountBlank").alias("Current_CountBlank"), col("CountNonBlank").alias("Current_CountNonBlank"),
            col("Count").alias("Current_Count"), col("Current_%_Blanks")
        )

        current_final_df = dynamic_rename(current_renamed_df, ["Name"], "Current_Name", logger)
        log_dataframe_info(logger, current_final_df, "Current data processing complete")

        # STEP 2: READ PREVIOUS EXCEL FILE AND PROCESS DATA
        logger.info("STEP 2: Processing previous data")
        previous_df = read_excel_sheet_from_s3(spark, args.previous_file, args.sheet_name)
        log_dataframe_info(logger, previous_df, "Previous Excel data read")

        previous_selected_df = select_columns(previous_df, columns_to_select, logger)
        previous_with_id_df = add_continuous_record_id(previous_selected_df, max_record_id + 1, "Name")
        max_record_id = previous_with_id_df.agg({"RecordID": "max"}).collect()[0][0] or max_record_id
        logger.info(f"Updated max_record_id to {max_record_id} after processing previous data")

        previous_with_blanks_df = add_blank_percentage(previous_with_id_df, logger)
        previous_with_blanks_df = previous_with_blanks_df.withColumnRenamed("%_Blanks", "Previous_%_Blanks")

        previous_renamed_df = previous_with_blanks_df.select(
            col("RecordID"), col("__OriginalOrder"), col("Name"),
            col("Min_Value").alias("Previous_Min_Value"), col("Max_Value").alias("Previous_Max_Value"),
            col("CountBlank").alias("Previous_CountBlank"), col("CountNonBlank").alias("Previous_CountNonBlank"),
            col("Count").alias("Previous_Count"), col("Previous_%_Blanks")
        )
        previous_final_df = dynamic_rename(previous_renamed_df, ["Name"], "Previous_Name", logger)
        log_dataframe_info(logger, previous_final_df, "Previous data processing complete")

        # STEP 3: JOIN CURRENT AND PREVIOUS DATA
        logger.info("STEP 3: Joining current and previous data")
        j_output, l_output, r_output = perform_join(current_final_df, previous_final_df, "Current_Name", "Previous_Name", logger)

        # STEP 4 & 5: PROCESSING L & R OUTPUTS
        logger.info("STEP 4 & 5: Processing Left and Right outputs")
        l_output_with_new_field = l_output.withColumn("New_Field", lit("Y"))
        r_output_with_old_field = r_output.withColumn("Old_Field", lit("Y"))
        r_output_renamed = r_output_with_old_field.withColumnRenamed("Previous_Name", "Current_Name")

        max_id_before_r = (j_output.count() + l_output.count())
        r_output_with_id = add_continuous_record_id(r_output_renamed, max_id_before_r + 1, "Current_Name")

        # STEP 6 & 7: UNION ALL DATA & CREATE SORT KEY
        logger.info("STEP 6 & 7: Unioning all data parts (J, L, R) and preparing for sort")

        j_output = j_output.withColumnRenamed("__CurrentOrder", "__SortOrder")
        l_output_with_new_field = l_output_with_new_field.withColumnRenamed("__CurrentOrder", "__SortOrder")

        if "__PreviousOrder" in r_output_with_id.columns:
            r_output_with_id = r_output_with_id.drop("__PreviousOrder")

        # Handle duplicate columns (case-insensitive)
        for output_df_name, output_df in [("j_output", j_output), ("l_output", l_output_with_new_field), ("r_output", r_output_with_id)]:
            columns_lower = [col_name.lower() for col_name in output_df.columns]
            duplicate_cols = [col_name for col_name in columns_lower if columns_lower.count(col_name) > 1]

            if duplicate_cols:
                logger.warning(f"Found duplicate column names in {output_df_name} (case-insensitive): {', '.join(set(duplicate_cols))}")
                
                for dup_col in set(duplicate_cols):
                    matching_cols = [col_name for col_name in output_df.columns if col_name.lower() == dup_col]
                    logger.info(f"Columns that match '{dup_col}': {', '.join(matching_cols)}")
                    
                    # Keep the first occurrence, drop the rest
                    for col_to_drop in matching_cols[1:]:
                        logger.info(f"Dropping duplicate column from {output_df_name}: {col_to_drop}")
                        output_df = output_df.drop(col_to_drop)
                
                # Update the variables
                if output_df_name == "j_output":
                    j_output = output_df
                elif output_df_name == "l_output":
                    l_output_with_new_field = output_df
                elif output_df_name == "r_output":
                    r_output_with_id = output_df

        # Union all three parts together
        logger.info("Performing first union: J and L outputs")
        union_jl_df = j_output.unionByName(l_output_with_new_field, allowMissingColumns=True)

        logger.info("Performing second union: Adding R output")
        final_union_df = union_jl_df.unionByName(r_output_with_id, allowMissingColumns=True)

        log_dataframe_info(logger, final_union_df, "Final union of J, L, and R complete")

        # STEP 8: CALCULATE CHANGE METRICS
        logger.info("STEP 8: Calculating change metrics")
        final_union_df = final_union_df.withColumn("Previous_Count", col("Previous_Count").cast(DoubleType())) \
                                       .withColumn("Current_Count", col("Current_Count").cast(DoubleType())) \
                                       .withColumn("Previous_%_Blanks", col("Previous_%_Blanks").cast(DoubleType())) \
                                       .withColumn("Current_%_Blanks", col("Current_%_Blanks").cast(DoubleType()))

        final_union_df = final_union_df.withColumn(
            "% Blanks Change",
            when(col("Previous_%_Blanks") == 0, 0)
            .otherwise(((col("Current_%_Blanks") / col("Previous_%_Blanks")) - 1) * 100)
        )
        final_union_df = final_union_df.withColumn(
            "% Blanks Change",
            when(col("% Blanks Change").isNull(),
                 when(col("Current_%_Blanks") == 0, 0).otherwise(1)
            ).otherwise(col("% Blanks Change"))
        )
        final_union_df = final_union_df.withColumn(
            "Total Change",
            when(col("Previous_Count").isNull() | (col("Previous_Count") == 0), lit(None))
            .otherwise(((col("Current_Count") / col("Previous_Count")) - 1) * 100)
        )

        # STEP 9 & 10: FINAL PREPARATION AND SORTING
        logger.info("STEP 9 & 10: Final data preparation and sorting")
        required_column_order = [
            "RecordID", "Current_Name", "Current_Min_Value", "Current_Max_Value",
            "Current_CountBlank", "Current_CountNonBlank", "Current_Count", "Current_%_Blanks",
            "Previous_Min_Value", "Previous_Max_Value", "Previous_CountBlank", "Previous_CountNonBlank",
            "Previous_Count", "Previous_%_Blanks", "New_Field", "Old_Field", "% Blanks Change", "Total Change"
        ]

        for column in required_column_order:
            if column not in final_union_df.columns:
                logger.warning(f"Required column {column} is missing. Adding with null values.")
                final_union_df = final_union_df.withColumn(column, lit(None).cast(StringType()))

        logger.info("Sorting final DataFrame based on original file order.")
        final_union_df_sorted = final_union_df.orderBy(col("__SortOrder").asc_nulls_last())

        final_output_df_presort = final_union_df_sorted.select(*required_column_order)
        final_output_df = final_output_df_presort.withColumn("RecordID", row_number().over(Window.orderBy(lit(1))))

        log_dataframe_info(logger, final_output_df, "Final DataFrame sorted and ready for saving")

        # STEP 11: SAVE FINAL OUTPUT TO S3
        logger.info("STEP 11: Saving final output to S3")
        current_date_str = datetime.now().strftime("%Y-%m-%d")
        base_filename = f"Audience_Engine_Supply_Internal_minmax_{current_date_str}_Comparison"
        
        # Ensure output_dir uses s3:// protocol
        output_dir = args.output_dir
        if output_dir.startswith("s3a://"):
            output_dir = output_dir.replace("s3a://", "s3://")
        
        excel_output_path = f"{output_dir}/{base_filename}.xlsx"
        csv_output_path = f"{output_dir}/{base_filename}_csv"
        
        logger.info(f"Excel output path: {excel_output_path}")
        logger.info(f"CSV output path: {csv_output_path}")

        # Save Excel to S3
        excel_success = save_excel_to_s3(final_output_df, excel_output_path, args.sheet_name)
        if not excel_success:
            logger.error("Failed to save Excel file to S3")
        
        # Save CSV to S3
        csv_spark_path = csv_output_path.replace("s3://", "s3a://")
        save_to_csv(final_output_df, csv_spark_path)
        
        logger.info("Module 3 processing completed successfully")
        
    except Exception as e:
        logger.error(f"Error in Module 3 processing: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise
    finally:
        if spark:
            logger.info("Stopping Spark session")
            spark.stop()

if __name__ == "__main__":
    main()