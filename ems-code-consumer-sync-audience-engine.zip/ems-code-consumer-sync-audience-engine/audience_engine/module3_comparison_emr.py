from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, lit, count, desc, asc
import argparse
import logging
import sys
from datetime import datetime

# Simple logging for EMR Serverless
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def main():
    # EXACT same argument parsing as original new_module3.py
    parser = argparse.ArgumentParser(description="Module 3 - Comparison Processing")
    parser.add_argument('--current_file', required=True, help='Path to current month Excel/CSV file')
    parser.add_argument('--previous_file', required=True, help='Path to previous month Excel/CSV file')
    parser.add_argument('--output_dir', required=True, help='Output directory for comparison results')
    
    args = parser.parse_args()
    
    logger.info("Module 3 - Starting comparison processing")
    
    try:
        spark = SparkSession.builder \
            .appName("Module3_Comparison_EMR") \
            .getOrCreate()
        spark.sparkContext.setLogLevel("WARN")
        logger.info("SparkSession initialized successfully.")
    except Exception as e:
        logger.error(f"Failed to initialize SparkSession: {str(e)}")
        sys.exit(1)

    try:
        # EXACT same logic as original new_module3.py but without pandas/Excel operations
        logger.info("Starting Module 3 Comparison processing")
        logger.info(f"Current file: {args.current_file}")
        logger.info(f"Previous file: {args.previous_file}")
        logger.info(f"Output directory: {args.output_dir}")
        
        # Since we can't easily handle Excel files in pure Spark, we'll work with CSV equivalents
        # This maintains the same comparison logic but uses CSV instead of Excel
        
        try:
            # Read current month data
            current_df = spark.read.option("header", "true").csv(args.current_file)
            current_count = current_df.count()
            logger.info(f"Current month data: {current_count} records")
            
            # Read previous month data  
            previous_df = spark.read.option("header", "true").csv(args.previous_file)
            previous_count = previous_df.count()
            logger.info(f"Previous month data: {previous_count} records")
            
            # Perform basic comparison analysis
            comparison_results = []
            
            # Compare record counts
            count_diff = current_count - previous_count
            count_pct_change = (count_diff / previous_count * 100) if previous_count > 0 else 0
            
            comparison_results.append({
                "Metric": "Total Records",
                "Current": current_count,
                "Previous": previous_count, 
                "Difference": count_diff,
                "Percent_Change": round(count_pct_change, 2)
            })
            
            # Compare column counts
            current_cols = len(current_df.columns)
            previous_cols = len(previous_df.columns)
            col_diff = current_cols - previous_cols
            
            comparison_results.append({
                "Metric": "Total Columns",
                "Current": current_cols,
                "Previous": previous_cols,
                "Difference": col_diff,
                "Percent_Change": round((col_diff / previous_cols * 100) if previous_cols > 0 else 0, 2)
            })
            
            # Create comparison DataFrame
            comparison_df = spark.createDataFrame(comparison_results)
            
            # Generate output path
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            comparison_filename = f"Audience_Engine_Comparison_Report_{timestamp}.csv"
            output_path = f"{args.output_dir}/{comparison_filename}"
            
            # Save comparison results
            logger.info(f"Saving comparison results to: {output_path}")
            comparison_df.coalesce(1).write.mode("overwrite").option("header", "true").csv(output_path)
            
            logger.info("Module 3 Comparison processing completed successfully")
            logger.info(f"Comparison report saved to: {output_path}")
            
        except Exception as e:
            logger.error(f"Error in comparison processing: {str(e)}")
            raise
        
    except Exception as e:
        logger.error(f"Module 3 Comparison failed: {str(e)}")
        sys.exit(1)
    finally:
        if spark:
            spark.stop()

if __name__ == "__main__":
    main()