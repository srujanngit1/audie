from pyspark.sql import SparkSession
import argparse
import logging
import sys
from datetime import datetime
import json

# Simple logging for EMR Serverless
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def find_csv_directories_in_s3(spark, input_dir):
    """Find all CSV output directories from MinMax processing using Spark"""
    logger.info(f"Scanning for CSV directories in: {input_dir}")
    
    try:
        # Read directory structure to find CSV outputs
        # MinMax processing creates directories with CSV files
        csv_directories = []
        
        # Look for the main MinMax output directory pattern
        minmax_pattern = f"{input_dir}/Audience_Engine_Supply_Internal_minmax_*"
        
        # Use Spark to check for CSV files in directories
        try:
            # Try to read from the pattern to see if directories exist
            df_test = spark.read.option("header", "true").csv(f"{minmax_pattern}/*")
            if df_test.count() > 0:
                csv_directories.append("stats")
                csv_directories.append("samples")
                csv_directories.append("frequencies")
                logger.info("Found MinMax output directories with CSV files")
        except Exception as e:
            logger.warning(f"No CSV files found in MinMax pattern: {str(e)}")
        
        # Also check for any direct CSV files
        try:
            direct_csv = spark.read.option("header", "true").csv(f"{input_dir}/*.csv")
            if direct_csv.count() > 0:
                csv_directories.append("direct_csv")
                logger.info("Found direct CSV files")
        except Exception as e:
            logger.warning(f"No direct CSV files found: {str(e)}")
        
        logger.info(f"Found CSV data types: {csv_directories}")
        return csv_directories
        
    except Exception as e:
        logger.error(f"Error scanning for CSV directories: {str(e)}")
        return []

def create_excel_summary_with_spark(spark, input_dir, output_dir):
    """Create Excel summary using Spark operations"""
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    excel_summary_filename = f"Audience_Engine_MinMax_Report_{timestamp}"
    
    logger.info(f"Creating Excel summary: {excel_summary_filename}")
    
    # Since we can't create actual Excel files in pure Spark EMR,
    # we'll create structured CSV files that can be easily converted to Excel
    excel_summary = {
        "report_name": excel_summary_filename,
        "created_timestamp": timestamp,
        "input_location": input_dir,
        "output_location": output_dir,
        "sheets_created": []
    }
    
    try:
        # Process MinMax stats output
        try:
            stats_pattern = f"{input_dir}/Audience_Engine_Supply_Internal_minmax_*/stats"
            stats_df = spark.read.option("header", "true").csv(stats_pattern)
            stats_count = stats_df.count()
            
            if stats_count > 0:
                stats_output = f"{output_dir}/{excel_summary_filename}_Stats.csv"
                stats_df.coalesce(1).write.mode("overwrite").option("header", "true").csv(stats_output)
                logger.info(f"Created Stats sheet with {stats_count} rows: {stats_output}")
                excel_summary["sheets_created"].append({
                    "sheet_name": "Stats",
                    "row_count": stats_count,
                    "output_path": stats_output
                })
        except Exception as e:
            logger.warning(f"Could not process stats data: {str(e)}")
        
        # Process MinMax samples output
        try:
            samples_pattern = f"{input_dir}/Audience_Engine_Supply_Internal_minmax_*/samples"
            samples_df = spark.read.option("header", "true").csv(samples_pattern)
            samples_count = samples_df.count()
            
            if samples_count > 0:
                samples_output = f"{output_dir}/{excel_summary_filename}_Samples.csv"
                samples_df.coalesce(1).write.mode("overwrite").option("header", "true").csv(samples_output)
                logger.info(f"Created Samples sheet with {samples_count} rows: {samples_output}")
                excel_summary["sheets_created"].append({
                    "sheet_name": "Samples",
                    "row_count": samples_count,
                    "output_path": samples_output
                })
        except Exception as e:
            logger.warning(f"Could not process samples data: {str(e)}")
        
        # Process MinMax frequencies output
        try:
            frequencies_pattern = f"{input_dir}/Audience_Engine_Supply_Internal_minmax_*/frequencies"
            frequencies_df = spark.read.option("header", "true").csv(frequencies_pattern)
            frequencies_count = frequencies_df.count()
            
            if frequencies_count > 0:
                frequencies_output = f"{output_dir}/{excel_summary_filename}_Frequencies.csv"
                frequencies_df.coalesce(1).write.mode("overwrite").option("header", "true").csv(frequencies_output)
                logger.info(f"Created Frequencies sheet with {frequencies_count} rows: {frequencies_output}")
                excel_summary["sheets_created"].append({
                    "sheet_name": "Frequencies",
                    "row_count": frequencies_count,
                    "output_path": frequencies_output
                })
        except Exception as e:
            logger.warning(f"Could not process frequencies data: {str(e)}")
        
        # Create summary metadata file
        summary_output = f"{output_dir}/{excel_summary_filename}_Summary.json"
        summary_df = spark.createDataFrame([excel_summary])
        summary_df.coalesce(1).write.mode("overwrite").json(summary_output)
        
        logger.info(f"Excel processing completed. Created {len(excel_summary['sheets_created'])} data files")
        logger.info(f"Summary metadata saved to: {summary_output}")
        
        return excel_summary
        
    except Exception as e:
        logger.error(f"Error creating Excel summary: {str(e)}")
        return None

def create_excel_placeholder(spark, output_dir):
    """Create Excel placeholder file using Spark"""
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    placeholder_filename = f"Audience_Engine_MinMax_Report_{timestamp}_PLACEHOLDER"
    
    logger.info(f"Creating Excel placeholder: {placeholder_filename}")
    
    # Create a simple CSV that represents what would be in Excel
    placeholder_data = [
        ("Sheet_Name", "Description", "Status"),
        ("Stats", "MinMax statistical analysis results", "Ready for Excel conversion"),
        ("Samples", "Sample records from dataset", "Ready for Excel conversion"),
        ("Frequencies", "Frequency analysis results", "Ready for Excel conversion"),
        ("Summary", "Processing summary and metadata", "Ready for Excel conversion")
    ]
    
    placeholder_df = spark.createDataFrame(placeholder_data, ["Sheet_Name", "Description", "Status"])
    placeholder_output = f"{output_dir}/{placeholder_filename}.csv"
    
    placeholder_df.coalesce(1).write.mode("overwrite").option("header", "true").csv(placeholder_output)
    
    logger.info(f"Excel placeholder created: {placeholder_output}")
    return placeholder_output

def main():
    parser = argparse.ArgumentParser(description="Excel Builder EMR - Convert MinMax CSV outputs to Excel format")
    parser.add_argument('--input_dir', required=True, help='S3 path to MinMax CSV output directory')
    parser.add_argument('--output_dir', required=True, help='S3 path for Excel output files')
    parser.add_argument('--single_report', action='store_true', help='Create single consolidated report')
    
    args = parser.parse_args()
    
    logger.info("Excel Builder EMR - Starting MinMax CSV to Excel processing")
    logger.info(f"Input directory: {args.input_dir}")
    logger.info(f"Output directory: {args.output_dir}")
    logger.info(f"Single report mode: {args.single_report}")
    
    try:
        spark = SparkSession.builder \
            .appName("ExcelBuilder_MinMax_EMR") \
            .config("spark.sql.adaptive.enabled", "true") \
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
            .getOrCreate()
        spark.sparkContext.setLogLevel("WARN")
        logger.info("SparkSession initialized successfully for Excel processing")
    except Exception as e:
        logger.error(f"Failed to initialize SparkSession: {str(e)}")
        sys.exit(1)

    try:
        # Normalize S3 paths
        input_dir = args.input_dir
        output_dir = args.output_dir
        
        # Ensure consistent S3 path format
        if input_dir.startswith("s3a://"):
            input_dir = input_dir.replace("s3a://", "s3://")
        if output_dir.startswith("s3a://"):
            output_dir = output_dir.replace("s3a://", "s3://")
        
        logger.info(f"Processing MinMax outputs from: {input_dir}")
        logger.info(f"Saving Excel outputs to: {output_dir}")
        
        # Find available CSV data from MinMax processing
        csv_directories = find_csv_directories_in_s3(spark, input_dir)
        
        if not csv_directories:
            logger.warning("No CSV data found from MinMax processing")
            logger.info("Creating Excel placeholder file")
            placeholder_path = create_excel_placeholder(spark, output_dir)
            logger.info(f"Excel Builder completed with placeholder: {placeholder_path}")
            return
        
        # Create consolidated Excel summary from MinMax outputs
        if args.single_report:
            logger.info("Creating single consolidated Excel report from MinMax data")
            excel_summary = create_excel_summary_with_spark(spark, input_dir, output_dir)
            
            if excel_summary and len(excel_summary.get("sheets_created", [])) > 0:
                logger.info(f"Excel processing completed successfully")
                logger.info(f"Created {len(excel_summary['sheets_created'])} data files for Excel conversion")
                
                # Log details of created files
                for sheet in excel_summary["sheets_created"]:
                    logger.info(f"- {sheet['sheet_name']}: {sheet['row_count']} rows -> {sheet['output_path']}")
            else:
                logger.error("Failed to create Excel summary from MinMax data")
                sys.exit(1)
        else:
            logger.info("Processing individual CSV outputs (not implemented in this version)")
            logger.info("Use --single_report for consolidated Excel processing")
        
        logger.info("Excel Builder EMR completed successfully")
        logger.info("Note: CSV files created are ready for Excel conversion in downstream processing")
        
    except Exception as e:
        logger.error(f"Excel Builder EMR failed: {str(e)}")
        sys.exit(1)
    finally:
        if spark:
            spark.stop()

if __name__ == "__main__":
    main()