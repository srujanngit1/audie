from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.window import Window
from pyspark.sql.functions import (
    row_number, monotonically_increasing_id, lit, regexp_extract, length, col,
    rand, round, coalesce, when, isnan, upper, sum as sum_func, trim
)
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, LongType
)
from datetime import datetime
import time
import pandas as pd
import numpy as np
import os
import re
import json
from config import C_VARIABLES_COLUMNS, PROFILE_COLUMNS, TODAY_DATE, EXCLUDE_SAMPLE_SIZE
from functions import file_config, escape_xml_metacharacters
import argparse
import sys
import logging

# Simple logging for EMR Serverless
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

spark = None

def logic_main(file_path, output_dir, num_sample_records, run_exclude_seeds, exclude_field, exclude_value,
               include_empty_cells, input_format_fixed, batch_processing_enabled, batch_field_name, run_frequency_reports=False,
               frequency_c_fields=None, num_records_show_freq=10, separate_reports_by_batch=False):
    """
    Main processing logic - EXACT copy from original minmax_comparision.py
    """
    success_flags = []
    starttime = datetime.now()

    logger.info(f"Running MinMax process for input: {file_path}")

    df_raw = None

    try:
        logger.info(f"Reading input CSV file(s) from: {file_path}")
        
        # Direct CSV reading - Spark handles directory with parts automatically
        df_raw = spark.read.option("header", "true") \
            .option("inferSchema", "false") \
            .option("sep", ",") \
            .csv(file_path)

        # Log basic info for debugging
        logger.info(f"Successfully loaded DataFrame from {file_path}")
        logger.info(f"Available columns: {df_raw.columns}")
        
        if "Original_Row_Number" in df_raw.columns:
            logger.info("Casting Original_Row_Number column to LongType.")
            df_raw = df_raw.withColumn("Original_Row_Number", col("Original_Row_Number").cast(LongType()))
        else:
            logger.error("CRITICAL: Original_Row_Number column expected from Module 1 output is MISSING.")
            logger.error(f"Available columns are: {df_raw.columns}")
            raise ValueError("Original_Row_Number column is required but not found in input data.")

        logger.info("Adding Minmax_RecordID column for internal processing")
        df_raw = df_raw.withColumn("Minmax_RecordID", monotonically_increasing_id() + 1)

        initial_row_count = df_raw.count()
        logger.info(f"Initial dataset loaded: {initial_row_count:,} rows, {len(df_raw.columns)} columns")

        if initial_row_count == 0:
            logger.error("Input dataset is empty. Cannot proceed with MinMax processing.")
            raise ValueError("Input dataset contains no records.")

        # Apply exclusions if enabled (EXACT same logic as original)
        df_after_exclusions = df_raw
        seed_records_df = None

        if run_exclude_seeds and exclude_field and exclude_value is not None:
            logger.info(f"Applying seed exclusions: {exclude_field} != '{exclude_value}'")
            
            if exclude_field not in df_raw.columns:
                logger.error(f"Exclude field '{exclude_field}' not found in dataset columns.")
                raise ValueError(f"Exclude field '{exclude_field}' does not exist in the input data.")

            if "*" in exclude_value:
                logger.info(f"Wildcard pattern detected in exclude_value: '{exclude_value}'")
                pattern = exclude_value.replace("*", ".*")
                seed_records_df = df_raw.filter(col(exclude_field).rlike(pattern))
                df_after_exclusions = df_raw.filter(~col(exclude_field).rlike(pattern))
            else:
                seed_records_df = df_raw.filter(col(exclude_field) == exclude_value)
                df_after_exclusions = df_raw.filter(col(exclude_field) != exclude_value)

            excluded_count = seed_records_df.count() if seed_records_df else 0
            remaining_count = df_after_exclusions.count()
            
            logger.info(f"Exclusion results: {excluded_count:,} records excluded, {remaining_count:,} records remaining")
            
            if remaining_count == 0:
                logger.warning("All records were excluded. Proceeding with original dataset.")
                df_after_exclusions = df_raw
                seed_records_df = None

        # Process batches (EXACT same logic as original)
        if batch_processing_enabled and batch_field_name:
            logger.info(f"Batch processing enabled with field: {batch_field_name}")
            
            if batch_field_name not in df_after_exclusions.columns:
                logger.error(f"Batch field '{batch_field_name}' not found in dataset.")
                raise ValueError(f"Batch field '{batch_field_name}' does not exist.")

            batch_values = [row[batch_field_name] for row in 
                          df_after_exclusions.select(batch_field_name).distinct().collect()]
            logger.info(f"Found {len(batch_values)} unique batch values: {batch_values[:5]}...")

            for batch_value in batch_values:
                logger.info(f"Processing batch: {batch_value}")
                
                current_batch_df = df_after_exclusions.filter(col(batch_field_name) == batch_value)
                current_batch_df = current_batch_df.withColumn("batch", lit(str(batch_value)))
                
                batch_count = current_batch_df.count()
                logger.info(f"Batch '{batch_value}' contains {batch_count:,} records")

                if batch_count == 0:
                    logger.warning(f"Batch '{batch_value}' is empty. Skipping.")
                    continue

                # Process this batch with exact same logic as original
                process_single_batch(current_batch_df, seed_records_df, output_dir, 
                                   num_sample_records, include_empty_cells, input_format_fixed,
                                   run_frequency_reports, frequency_c_fields, num_records_show_freq,
                                   file_path, batch_value, separate_reports_by_batch)
        else:
            logger.info("Processing entire dataset as single batch")
            df_after_exclusions = df_after_exclusions.withColumn("batch", lit("all"))
            
            process_single_batch(df_after_exclusions, seed_records_df, output_dir,
                               num_sample_records, include_empty_cells, input_format_fixed,
                               run_frequency_reports, frequency_c_fields, num_records_show_freq,
                               file_path, None, separate_reports_by_batch)

        endtime = datetime.now()
        total_time = endtime - starttime
        logger.info(f"MinMax processing completed successfully in {total_time}")
        
        return True

    except Exception as e:
        logger.error(f"MinMax processing failed: {str(e)}", exc_info=True)
        raise

def process_single_batch(current_batch_df, seed_records_df, output_dir, num_sample_records,
                        include_empty_cells, input_format_fixed, run_frequency_reports, 
                        frequency_c_fields, num_records_show_freq, file_path, batch_value, separate_reports):
    """Process a single batch - EXACT same logic as original"""
    
    try:
        logger.info("Starting single batch processing")
        
        # Generate stats (EXACT same logic as original)
        stats_df = logic_stats(logger, current_batch_df, include_empty_cells, input_format_fixed, file_path)
        
        # Generate samples (EXACT same logic as original) 
        samples_df = logic_samples(logger, current_batch_df, num_sample_records)
        
        # Generate seed samples if applicable (EXACT same logic as original)
        seed_samples_df = None
        if seed_records_df is not None:
            seed_samples_df = logic_exclude_seed_samples(logger, seed_records_df)
        
        # Generate frequency reports if enabled (EXACT same logic as original)
        frequencies_df = None
        if run_frequency_reports:
            frequencies_df = logic_frequency_reports(logger, current_batch_df, frequency_c_fields, 
                                                   num_records_show_freq, None, None)
        
        # Save outputs (EXACT same logic as original but to S3)
        save_outputs_to_csv(output_dir, stats_df, samples_df, seed_samples_df, 
                           frequencies_df, batch_value, separate_reports)
        
        logger.info("Single batch processing completed successfully")
        
    except Exception as e:
        logger.error(f"Error in single batch processing: {str(e)}")
        raise

def logic_stats(logger, stats_df, include_empty_cells, input_format_fixed, filepath):
    """
    Generate stats preserving exact input column order (excluding Original_Row_Number)
    EXACT copy from original minmax_comparision.py
    """
    try:
        import re
        from pyspark.sql.functions import upper, row_number, lit, length, col, when
        from pyspark.sql.window import Window
        from pyspark.sql.types import StructType, StructField, StringType, IntegerType

        def sanitize_view_name(column_name):
            """Create valid SQL view name from column name"""
            sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', column_name)
            if sanitized and not sanitized[0].isalpha():
                sanitized = 'v_' + sanitized
            return sanitized

        logger.info("MinMax File Process - Starting stats process with preserved column order")

        row_count = stats_df.count()
        logger.info(f"Processing stats for {row_count} rows")

        cols_to_drop = [c for c in ["Minmax_RecordID", "batch", "Original_Row_Number"]
                         if c in stats_df.columns]
        if cols_to_drop:
            stats_df_clean = stats_df.drop(*cols_to_drop)
            logger.info(f"Dropped columns for stats: {cols_to_drop}")
        else:
            stats_df_clean = stats_df

        input_column_order = stats_df_clean.columns
        logger.info(f"Input column order preserved: {input_column_order[:5]}... (showing first 5)")

        logger.info("Extracting column configuration information")
        stats_config_df = file_config(spark, stats_df_clean, filepath)

        if not input_format_fixed:
            logger.info("CSV format detected - using simple sequential positions")
        else:
            logger.info("Fixed format detected - calculating byte positions")
            from pyspark.sql.functions import sum as sum_func
            window_spec_order = Window.partitionBy(lit(1)).orderBy("Position")
            window_spec_running = Window.orderBy("Position").rowsBetween(
                Window.unboundedPreceding, Window.currentRow)

            stats_config_df = stats_config_df.withColumn(
                "running_size",
                sum_func(when(col("Size").cast("int").isNotNull(), col("Size").cast("int")).otherwise(0))
                .over(window_spec_running)
            ).withColumn(
                "Position",
                when(col("Position") == 1, 1)
                .otherwise(col("running_size") - col("Size").cast("int") + 1)
            ).drop("running_size")

        stats_config_df = stats_config_df.withColumn("Name", upper(col("Name")))
        stats_config_df = escape_xml_metacharacters(stats_config_df, "Name")

        valid_columns = input_column_order
        logger.info(f"Processing {len(valid_columns)} columns in original order")

        stats_df_clean.createOrReplaceTempView("stats_temp")

        logger.info("Computing all column metrics using optimized SQL approach")

        combined_results = []
        batch_size = 50

        all_metrics = {}
        for i in range(0, len(valid_columns), batch_size):
            batch_columns = valid_columns[i:i+batch_size]
            if not batch_columns:
                continue

            logger.info(f"Processing metrics batch {i//batch_size + 1} for {len(batch_columns)} columns")

            all_metrics_exprs = []
            for col_name in batch_columns:
                escaped_name = col_name.replace("`", "``")
                all_metrics_exprs.extend([
                    f"SUM(CASE WHEN `{escaped_name}` IS NULL THEN 1 ELSE 0 END) as `{escaped_name}_null`",
                    f"SUM(CASE WHEN `{escaped_name}` = '' THEN 1 ELSE 0 END) as `{escaped_name}_empty`",
                    f"MIN(CASE WHEN `{escaped_name}` IS NOT NULL AND `{escaped_name}` != '' THEN LENGTH(CAST(`{escaped_name}` AS STRING)) ELSE NULL END) as `{escaped_name}_min_len`",
                    f"MAX(LENGTH(CAST(`{escaped_name}` AS STRING))) as `{escaped_name}_max_len`"
                ])

            batch_sql = f"SELECT {', '.join(all_metrics_exprs)} FROM stats_temp"
            batch_result = spark.sql(batch_sql).collect()[0]

            for field_name in batch_result.__fields__:
                all_metrics[field_name] = batch_result[field_name]

        for column_name in valid_columns:
            null_count = all_metrics.get(f"{column_name}_null", 0) or 0
            empty_count = all_metrics.get(f"{column_name}_empty", 0) or 0
            total_blank_count = null_count + empty_count
            min_len = all_metrics.get(f"{column_name}_min_len", 0) or 0
            max_len = all_metrics.get(f"{column_name}_max_len", 0) or 0

            sample_sql = f"""
            SELECT `{column_name}` FROM stats_temp
            WHERE `{column_name}` IS NOT NULL AND `{column_name}` != ''
            LIMIT 5
            """
            sample_values = [row[0] for row in spark.sql(sample_sql).collect()]

            numeric_indicators = ["id", "key", "count", "num", "total", "amount", "price", "cost", "qty", "quantity"]
            name_indicates_numeric = any(indicator in column_name.lower() for indicator in numeric_indicators)

            treat_as_numeric = False
            if sample_values:
                numeric_pattern = r'^-?\d+(\.\d+)?([eE][+-]?\d+)?$'
                if "code" in column_name.lower():
                    has_numeric = any(re.match(numeric_pattern, str(val).strip()) for val in sample_values if val is not None)
                    treat_as_numeric = has_numeric
                elif name_indicates_numeric or all(
                    re.match(r'^-?\d+(\.\d+)?([eE][+-]?\d+)?$', str(val).strip())
                    for val in sample_values if val is not None
                ):
                    treat_as_numeric = True

            sanitized_view_name = sanitize_view_name(column_name)
            stats_df_clean.select(column_name).createOrReplaceTempView(f"col_{sanitized_view_name}")

            min_value = ""
            max_value = ""

            if treat_as_numeric:
                min_max_sql = f"""
                SELECT
                    {f"MIN(CASE WHEN `{column_name}` IS NOT NULL AND `{column_name}` != '' THEN CAST(`{column_name}` AS DOUBLE) ELSE NULL END)" if include_empty_cells else f"MIN(CAST(`{column_name}` AS DOUBLE))"} as min_val,
                    MAX(CAST(`{column_name}` AS DOUBLE)) as max_val
                FROM col_{sanitized_view_name}
                WHERE CAST(`{column_name}` AS DOUBLE) IS NOT NULL AND NOT isnan(CAST(`{column_name}` AS DOUBLE))
                """
                try:
                    min_max_result = spark.sql(min_max_sql).collect()
                    if min_max_result and len(min_max_result) > 0:
                        min_numeric = min_max_result[0].min_val
                        max_numeric = min_max_result[0].max_val

                        if min_numeric is not None:
                            min_sql = f"SELECT `{column_name}` FROM col_{sanitized_view_name} WHERE CAST(`{column_name}` AS DOUBLE) = {min_numeric} LIMIT 1"
                            min_result = spark.sql(min_sql).collect()
                            min_value = str(min_result[0][0]) if min_result else ""

                        if max_numeric is not None:
                            max_sql = f"SELECT `{column_name}` FROM col_{sanitized_view_name} WHERE CAST(`{column_name}` AS DOUBLE) = {max_numeric} LIMIT 1"
                            max_result = spark.sql(max_sql).collect()
                            max_value = str(max_result[0][0]) if max_result else ""
                except:
                    treat_as_numeric = False

            if not treat_as_numeric:
                if include_empty_cells:
                    min_max_sql = f"""
                    SELECT
                        MIN(CASE WHEN `{column_name}` IS NOT NULL AND `{column_name}` != ''
                            THEN `{column_name}` ELSE NULL END) as min_val,
                        MAX(`{column_name}`) as max_val
                    FROM col_{sanitized_view_name}
                    """
                else:
                    min_max_sql = f"SELECT MIN(`{column_name}`) as min_val, MAX(`{column_name}`) as max_val FROM col_{sanitized_view_name}"

                min_max_result = spark.sql(min_max_sql).collect()
                if min_max_result and len(min_max_result) > 0:
                    min_value = str(min_max_result[0].min_val) if min_max_result[0].min_val is not None else ""
                    max_value = str(min_max_result[0].max_val) if min_max_result[0].max_val is not None else ""

            shortest_value = ""
            longest_value = ""

            if min_len > 0:
                shortest_sql = f"""
                SELECT `{column_name}` FROM col_{sanitized_view_name}
                WHERE LENGTH(CAST(`{column_name}` AS STRING)) = {min_len}
                AND `{column_name}` IS NOT NULL AND `{column_name}` != ''
                LIMIT 1
                """
                shortest_result = spark.sql(shortest_sql).collect()
                shortest_value = str(shortest_result[0][0]) if shortest_result else ""

            if max_len > 0:
                longest_sql = f"""
                SELECT `{column_name}` FROM col_{sanitized_view_name}
                WHERE LENGTH(CAST(`{column_name}` AS STRING)) = {max_len}
                AND `{column_name}` IS NOT NULL
                LIMIT 1
                """
                longest_result = spark.sql(longest_sql).collect()
                longest_value = str(longest_result[0][0]) if longest_result else ""

            combined_results.append({
                "Name": column_name,
                "Min_Value": min_value,
                "Max_Value": max_value,
                "CountBlank": int(total_blank_count),
                "CountNonBlank": int(row_count - total_blank_count),
                "Count": int(row_count),
                "Type": "V_String",
                "Position": valid_columns.index(column_name) + 1,
                "Shortest": shortest_value,
                "Shortest_Length": int(min_len),
                "Longest": longest_value,
                "Longest_Length": int(max_len)
            })

            spark.catalog.dropTempView(f"col_{sanitized_view_name}")

        spark.catalog.dropTempView("stats_temp")

        schema = StructType([
            StructField("Name", StringType(), True),
            StructField("Min_Value", StringType(), True),
            StructField("Max_Value", StringType(), True),
            StructField("CountBlank", IntegerType(), True),
            StructField("CountNonBlank", IntegerType(), True),
            StructField("Count", IntegerType(), True),
            StructField("Type", StringType(), True),
            StructField("Position", IntegerType(), True),
            StructField("Shortest", StringType(), True),
            StructField("Shortest_Length", IntegerType(), True),
            StructField("Longest", StringType(), True),
            StructField("Longest_Length", IntegerType(), True)
        ])

        stats_results_df = spark.createDataFrame(combined_results, schema)

        stats_results_df = stats_results_df.orderBy("Position").select(
            "Name", "Min_Value", "Max_Value", "CountBlank", "CountNonBlank", "Count",
            "Type", "Position", "Shortest", "Shortest_Length", "Longest", "Longest_Length"
        )

        logger.info("MinMax File Process - Stats output process completed successfully with preserved column order")
        return stats_results_df

    except Exception as e:
        logger.error(f"Stats process failed: {str(e)}")
        return None

def logic_samples(logger, current_batch_df, num_sample_records):
    """
    Generate random sample records preserving RowNumber from module1 output.
    EXACT copy from original minmax_comparision.py
    """
    try:
        logger.info("MinMax File Process - Starting optimized samples output process")

        if "Original_Row_Number" not in current_batch_df.columns:
            logger.error("FATAL: Original_Row_Number column NOT FOUND in input for logic_samples. This column is expected from Module 1.")
            raise ValueError("Original_Row_Number column is missing, cannot proceed with sampling as required.")

        row_count = current_batch_df.count()
        logger.info(f"Generating samples from {row_count} records for batch.")

        if row_count == 0 or num_sample_records == 0:
            logger.info("No records or zero samples requested, returning empty samples DataFrame.")
            sample_columns = ["Original_Row_Number"] + [c for c in current_batch_df.columns if c not in ["Original_Row_Number", "Minmax_RecordID", "batch"]]
            empty_schema = StructType([StructField(c, StringType(), True) for c in sample_columns])
            if "Original_Row_Number" in sample_columns:
                 empty_schema["Original_Row_Number"].dataType = LongType()
            return spark.createDataFrame([], schema=empty_schema)

        cols_to_keep = ["Original_Row_Number"] + [c for c in current_batch_df.columns if c not in ["Original_Row_Number", "Minmax_RecordID", "batch"]]
        df_for_sampling = current_batch_df.select(*cols_to_keep)

        samples_df = None
        if num_sample_records >= row_count:
            logger.info(f"Number of requested samples ({num_sample_records}) is >= total rows ({row_count}). Taking all records.")
            samples_df = df_for_sampling
        elif row_count > 1000000 and num_sample_records < row_count * 0.1:
            sample_fraction = min(1.0, (num_sample_records * 2.0) / row_count)
            logger.info(f"Large dataset ({row_count} rows) detected. Using two-stage sampling with initial fraction: {sample_fraction:.6f}")
            intermediate_samples = df_for_sampling.sample(withReplacement=False, fraction=sample_fraction, seed=42)
            samples_df = intermediate_samples.orderBy(rand(seed=123)).limit(num_sample_records)
        else:
            logger.info(f"Using direct orderBy(rand()).limit() sampling for {row_count} rows.")
            samples_df = df_for_sampling.orderBy(rand(seed=42)).limit(num_sample_records)

        final_cols = ["Original_Row_Number"] + [c for c in samples_df.columns if c != "Original_Row_Number"]
        samples_df = samples_df.select(*final_cols)

        final_sample_count = samples_df.count()
        logger.info(f"Generated {final_sample_count} sample records with preserved RowNumber.")
        if final_sample_count < num_sample_records and row_count >= num_sample_records :
             logger.warning(f"Requested {num_sample_records} samples, but only {final_sample_count} were generated. This might happen with skewed data or very small sampling fractions.")

        return samples_df

    except Exception as e:
        logger.error(f"MinMax File Process - Samples process failed: {str(e)}", exc_info=True)
        raise

def logic_exclude_seed_samples(logger, seed_records_df):
    """
    Process excluded seed records preserving RowNumber from module1.
    EXACT copy from original minmax_comparision.py
    """
    try:
        logger.info("MinMax File Process - Starting Exclude Seed Samples process")

        if seed_records_df is None:
            logger.warning("No seed records DataFrame provided.")
            return None

        if "Original_Row_Number" not in seed_records_df.columns:
            logger.error("FATAL: Original_Row_Number column NOT FOUND in input for logic_exclude_seed_samples.")
            raise ValueError("Original_Row_Number column is missing from seed_records_df.")

        row_count = seed_records_df.count()
        if row_count == 0:
            logger.warning("No seed records to process (empty DataFrame).")
            sample_columns = ["Original_Row_Number"] + [c for c in seed_records_df.columns if c not in ["Original_Row_Number", "Minmax_RecordID", "batch"]]
            empty_schema = StructType([StructField(c, StringType(), True) for c in sample_columns])
            if "Original_Row_Number" in sample_columns:
                 empty_schema["Original_Row_Number"].dataType = LongType()
            return spark.createDataFrame([], schema=empty_schema)

        logger.info(f"Processing {row_count} seed records.")

        cols_to_keep = ["Original_Row_Number"] + [c for c in seed_records_df.columns if c not in ["Original_Row_Number", "Minmax_RecordID", "batch"]]
        processed_df = seed_records_df.select(*cols_to_keep)

        if row_count > EXCLUDE_SAMPLE_SIZE:
            logger.info(f"Number of seed records ({row_count}) exceeds EXCLUDE_SAMPLE_SIZE ({EXCLUDE_SAMPLE_SIZE}). Sampling down.")
            processed_df = processed_df.orderBy(rand(seed=43)).limit(EXCLUDE_SAMPLE_SIZE)
            logger.info(f"Sampled down to {processed_df.count()} seed records.")

        processed_df = processed_df.orderBy("Original_Row_Number")

        final_cols = ["Original_Row_Number"] + [c for c in processed_df.columns if c != "Original_Row_Number"]
        processed_df = processed_df.select(*final_cols)

        final_seed_sample_count = processed_df.count()
        logger.info(f"Prepared {final_seed_sample_count} seed records for output with preserved RowNumber.")
        return processed_df

    except Exception as e:
        logger.error(f"MinMax File Process - Exclude Seed Samples process failed: {str(e)}", exc_info=True)
        raise

def logic_frequency_reports(logger, current_batch_df, frequency_c_fields, num_records_show, df_raw_for_batch_stats, batch_field):
    """
    Memory-optimized frequency analysis for large column counts
    EXACT copy from original minmax_comparision.py
    """
    try:
        logger.info("MinMax File Process - Starting OPTIMIZED frequency reports")

        row_count_batch = current_batch_df.count()
        logger.info(f"Processing frequency reports for {row_count_batch} rows")

        if row_count_batch == 0:
            logger.warning("Empty batch for frequency reports")
            return None

        df_columns_in_batch = current_batch_df.columns

        if frequency_c_fields:
            all_columns_to_analyze = [c for c in frequency_c_fields if c in df_columns_in_batch]
        else:
            all_columns_to_analyze = []

            for column in PROFILE_COLUMNS:
                if column in df_columns_in_batch and column not in all_columns_to_analyze:
                    all_columns_to_analyze.append(column)

            for column in C_VARIABLES_COLUMNS:
                if column in df_columns_in_batch and column not in all_columns_to_analyze:
                    all_columns_to_analyze.append(column)

        cols_to_exclude_freq = ["Original_Row_Number", "Minmax_RecordID", "batch"]
        if batch_field:
            cols_to_exclude_freq.append(batch_field)

        all_columns_to_analyze = [c for c in all_columns_to_analyze if c not in cols_to_exclude_freq]

        logger.info(f"Analyzing {len(all_columns_to_analyze)} columns for frequency reports")
        logger.info(f"Column order: P-columns first: {[c for c in all_columns_to_analyze if c in PROFILE_COLUMNS][:3]}...")
        logger.info(f"Then C-columns: {[c for c in all_columns_to_analyze if c.startswith('C')][:3]}...")

        if not all_columns_to_analyze:
            logger.warning("No columns to analyze for frequency reports")
            return None

        column_order_map = {col_name: idx for idx, col_name in enumerate(all_columns_to_analyze)}

        all_frequency_results = []

        view_name = f"freq_simple_view_{int(time.time())}"
        current_batch_df.createOrReplaceTempView(view_name)
        logger.info(f"Created temp view: {view_name}")

        for i, col_name in enumerate(all_columns_to_analyze):
            if i % 10 == 0:
                logger.info(f"Processing frequency column {i+1}/{len(all_columns_to_analyze)}: {col_name}")

            try:
                safe_column = col_name.replace("`", "``")
                
                freq_sql = f"""
                SELECT `{safe_column}` as value, COUNT(*) as frequency
                FROM {view_name}
                WHERE `{safe_column}` IS NOT NULL
                GROUP BY `{safe_column}`
                ORDER BY frequency DESC, value ASC
                LIMIT {num_records_show}
                """
                
                freq_result = spark.sql(freq_sql).collect()
                
                for row in freq_result:
                    value = str(row.value) if row.value is not None else ""
                    frequency = int(row.frequency)
                    
                    all_frequency_results.append({
                        "Name": col_name,
                        "Value": value,
                        "Frequency": frequency,
                        "Position": column_order_map.get(col_name, 999)
                    })
                    
            except Exception as e:
                logger.warning(f"Error processing frequency for column {col_name}: {str(e)}")
                continue
        
        spark.catalog.dropTempView(view_name)
        
        if not all_frequency_results:
            logger.warning("No frequency results generated")
            return None
        
        # Create DataFrame with results
        schema = StructType([
            StructField("Name", StringType(), True),
            StructField("Value", StringType(), True),
            StructField("Frequency", IntegerType(), True),
            StructField("Position", IntegerType(), True)
        ])
        
        freq_df = spark.createDataFrame(all_frequency_results, schema)
        freq_df = freq_df.orderBy("Position", "Name", col("Frequency").desc())
        
        logger.info(f"Generated frequency report with {freq_df.count()} entries")
        return freq_df
        
    except Exception as e:
        logger.error(f"Frequency reports failed: {str(e)}")
        return None

def save_outputs_to_csv(output_dir, stats_df, samples_df, seed_samples_df, frequencies_df, batch_value, separate_reports):
    """Save all outputs to CSV files in S3 - EXACT same logic as original"""
    try:
        logger.info("Saving outputs to S3 CSV files")
        
        # Create batch-specific directory if needed
        if batch_value and separate_reports:
            batch_output_dir = f"{output_dir}/report_{batch_value}"
        else:
            batch_output_dir = output_dir
        
        # Save stats - EXACT same logic as on-premises
        if stats_df is not None:
            stats_path = f"{batch_output_dir}/stats"
            df_count = stats_df.count()
            logger.info(f"Saving stats to: {stats_path} ({df_count} rows)")
            num_partitions = 1 if df_count < 500000 else stats_df.rdd.getNumPartitions()
            stats_df.coalesce(num_partitions).write.mode("overwrite").option("header", True).csv(stats_path)
        
        # Save samples - EXACT same logic as on-premises
        if samples_df is not None:
            samples_path = f"{batch_output_dir}/samples"
            df_count = samples_df.count()
            logger.info(f"Saving samples to: {samples_path} ({df_count} rows)")
            num_partitions = 1 if df_count < 500000 else samples_df.rdd.getNumPartitions()
            samples_df.coalesce(num_partitions).write.mode("overwrite").option("header", True).csv(samples_path)
        
        # Save seed samples - EXACT same logic as on-premises
        if seed_samples_df is not None:
            seed_samples_path = f"{batch_output_dir}/seed_samples"
            df_count = seed_samples_df.count()
            logger.info(f"Saving seed samples to: {seed_samples_path} ({df_count} rows)")
            num_partitions = 1 if df_count < 500000 else seed_samples_df.rdd.getNumPartitions()
            seed_samples_df.coalesce(num_partitions).write.mode("overwrite").option("header", True).csv(seed_samples_path)
        
        # Save frequencies - EXACT same logic as on-premises
        if frequencies_df is not None:
            frequencies_path = f"{batch_output_dir}/frequencies"
            df_count = frequencies_df.count()
            logger.info(f"Saving frequencies to: {frequencies_path} ({df_count} rows)")
            num_partitions = 1 if df_count < 500000 else frequencies_df.rdd.getNumPartitions()
            frequencies_df.coalesce(num_partitions).write.mode("overwrite").option("header", True).csv(frequencies_path)
        
        # Save metadata as JSON - keep as directory since it's not user-facing
        metadata = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "batch_value": batch_value,
            "separate_reports": separate_reports,
            "files_created": {
                "stats": stats_df is not None,
                "samples": samples_df is not None,
                "seed_samples": seed_samples_df is not None,
                "frequencies": frequencies_df is not None
            }
        }
        
        metadata_path = f"{batch_output_dir}/metadata_json"
        metadata_rdd = spark.sparkContext.parallelize([json.dumps(metadata)])
        metadata_rdd.coalesce(1).saveAsTextFile(metadata_path)
        
        logger.info("All outputs saved successfully")
        
    except Exception as e:
        logger.error(f"Error saving outputs: {str(e)}")
        raise

def main():
    """Main entry point for MinMax processing"""
    global spark
    
    parser = argparse.ArgumentParser(description="MinMax Processor for EMR Serverless")
    
    parser.add_argument('--input_file', required=True, help='Input CSV file path in S3')
    parser.add_argument('--output_dir', required=True, help='Output directory in S3')
    parser.add_argument('--num_sample_records', type=int, default=100, help='Number of sample records')
    parser.add_argument('--run_exclude_seeds', type=str, default='False', help='Run exclude seeds')
    parser.add_argument('--exclude_field', type=str, default='', help='Field to exclude')
    parser.add_argument('--exclude_value', type=str, default='', help='Value to exclude')
    parser.add_argument('--include_empty_cells', type=str, default='True', help='Include empty cells')
    parser.add_argument('--input_format_fixed', type=str, default='False', help='Input format is fixed')
    parser.add_argument('--batch', type=str, default='False', help='Enable batch processing')
    parser.add_argument('--batch_field', type=str, default='', help='Batch field name')
    parser.add_argument('--run_frequency_reports', type=str, default='True', help='Run frequency reports')
    parser.add_argument('--num_records_show', type=int, default=999, help='Number of records to show in frequency')
    parser.add_argument('--separate_reports', type=str, default='False', help='Create separate reports')
    
    args = parser.parse_args()
    
    # Convert string booleans to actual booleans
    run_exclude_seeds = args.run_exclude_seeds.lower() == 'true'
    include_empty_cells = args.include_empty_cells.lower() == 'true'
    input_format_fixed = args.input_format_fixed.lower() == 'true'
    batch_processing_enabled = args.batch.lower() == 'true'
    run_frequency_reports = args.run_frequency_reports.lower() == 'true'
    separate_reports_by_batch = args.separate_reports.lower() == 'true'
    
    logger.info("MinMax Processor EMR - Starting processing")
    logger.info(f"Input file: {args.input_file}")
    logger.info(f"Output directory: {args.output_dir}")
    logger.info(f"Sample records: {args.num_sample_records}")
    logger.info(f"Exclude seeds: {run_exclude_seeds}")
    logger.info(f"Batch processing: {batch_processing_enabled}")
    logger.info(f"Frequency reports: {run_frequency_reports}")
    
    try:
        spark = SparkSession.builder \
            .appName("MinMaxProcessorEMR") \
            .getOrCreate()
        
        spark.sparkContext.setLogLevel("WARN")
        logger.info("SparkSession initialized successfully")
        
        # Run the main processing logic
        success = logic_main(
            file_path=args.input_file,
            output_dir=args.output_dir,
            num_sample_records=args.num_sample_records,
            run_exclude_seeds=run_exclude_seeds,
            exclude_field=args.exclude_field if args.exclude_field else None,
            exclude_value=args.exclude_value if args.exclude_value else None,
            include_empty_cells=include_empty_cells,
            input_format_fixed=input_format_fixed,
            batch_processing_enabled=batch_processing_enabled,
            batch_field_name=args.batch_field if args.batch_field else None,
            run_frequency_reports=run_frequency_reports,
            frequency_c_fields=None,
            num_records_show_freq=args.num_records_show,
            separate_reports_by_batch=separate_reports_by_batch
        )
        
        if success:
            logger.info("MinMax processing completed successfully")
        else:
            logger.error("MinMax processing failed")
            raise Exception("MinMax processing failed")
            
    except Exception as e:
        logger.error(f"MinMax processing failed: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise
    finally:
        if spark:
            spark.stop()

if __name__ == "__main__":
    main()