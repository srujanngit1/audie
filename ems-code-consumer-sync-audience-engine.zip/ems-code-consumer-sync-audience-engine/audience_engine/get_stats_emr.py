import os
import sys
import datetime
import argparse
import logging
import json
import boto3
from typing import Dict, List
from pathlib import Path
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, count, sum as spark_sum, avg, max as spark_max, min as spark_min, isnan, isnull
from timeit import default_timer as timer

# Simple logging for EMR Serverless
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_parser():
    """Create command line argument parser for stats collection."""
    parser = argparse.ArgumentParser(description="Collect statistics from input files for Audience Engine")
    
    parser.add_argument("--input_file_path", type=str, required=True, help="Path to input file")
    parser.add_argument("--file_name", type=str, required=True, help="Name of the file being processed")
    parser.add_argument("--execution_date", type=str, required=True, help="Execution date")
    parser.add_argument("--stats_timestamp", type=str, required=True, help="Stats timestamp")
    
    return parser

def collect_basic_stats(df: DataFrame, file_name: str) -> Dict:
    """Collect basic statistics from DataFrame."""
    
    logger.info(f"Collecting basic statistics for {file_name}")
    
    try:
        # Basic counts
        total_rows = df.count()
        total_columns = len(df.columns)
        
        stats = {
            "file_name": file_name,
            "total_rows": total_rows,
            "total_columns": total_columns,
            "columns": df.columns,
            "timestamp": datetime.datetime.now().isoformat()
        }
        
        logger.info(f"Basic stats for {file_name}: {total_rows:,} rows, {total_columns} columns")
        
        # Column-level statistics for numeric columns
        numeric_stats = {}
        for column in df.columns:
            try:
                # Check if column has numeric data
                col_type = dict(df.dtypes)[column]
                if col_type in ['int', 'bigint', 'float', 'double', 'decimal']:
                    col_stats = df.select(
                        spark_min(col(column)).alias('min'),
                        spark_max(col(column)).alias('max'),
                        avg(col(column)).alias('avg'),
                        count(col(column)).alias('non_null_count')
                    ).collect()[0]
                    
                    numeric_stats[column] = {
                        'min': col_stats['min'],
                        'max': col_stats['max'],
                        'avg': col_stats['avg'],
                        'non_null_count': col_stats['non_null_count'],
                        'null_count': total_rows - col_stats['non_null_count']
                    }
            except Exception as e:
                logger.warning(f"Could not collect numeric stats for column {column}: {e}")
        
        stats["numeric_columns"] = numeric_stats
        
        # Null counts for all columns (sample of first 10 columns to avoid performance issues)
        null_counts = {}
        sample_columns = df.columns[:10]  # Limit to first 10 columns for performance
        
        for column in sample_columns:
            try:
                null_count = df.filter(col(column).isNull() | (col(column) == "")).count()
                null_counts[column] = {
                    'null_count': null_count,
                    'null_percentage': (null_count / total_rows * 100) if total_rows > 0 else 0
                }
            except Exception as e:
                logger.warning(f"Could not collect null stats for column {column}: {e}")
        
        stats["null_analysis"] = null_counts
        
        return stats
        
    except Exception as e:
        logger.error(f"Error collecting basic statistics: {e}")
        raise

def collect_sample_data(df: DataFrame, file_name: str, sample_size: int = 100) -> Dict:
    """Collect sample data from DataFrame."""
    
    logger.info(f"Collecting sample data for {file_name}")
    
    try:
        # Get sample rows
        sample_df = df.limit(sample_size)
        sample_data = []
        
        for row in sample_df.collect():
            sample_data.append(row.asDict())
        
        return {
            "file_name": file_name,
            "sample_size": len(sample_data),
            "sample_data": sample_data[:10]  # Only store first 10 rows to avoid large output
        }
        
    except Exception as e:
        logger.error(f"Error collecting sample data: {e}")
        return {"file_name": file_name, "sample_size": 0, "sample_data": []}

def write_stats_to_s3(stats: Dict, output_path: str, spark: SparkSession):
    """Write statistics to S3 as JSON."""
    
    logger.info(f"Writing statistics to {output_path}")
    
    try:
        # Convert stats to JSON string
        stats_json = json.dumps(stats, indent=2, default=str)
        
        # Create RDD with single JSON string and write to S3
        stats_rdd = spark.sparkContext.parallelize([stats_json])
        stats_rdd.coalesce(1).saveAsTextFile(output_path)
        
        logger.info(f"Successfully wrote statistics to {output_path}")
        
    except Exception as e:
        logger.error(f"Error writing statistics to S3: {e}")
        raise

def process_file_stats(spark: SparkSession, args: argparse.Namespace):
    """Main function to process file statistics."""
    
    start_time = timer()
    
    logger.info(f"Starting statistics collection for {args.file_name}")
    logger.info(f"Input file: {args.input_file_path}")
    
    try:
        # Determine delimiter based on file extension and name
        delimiter = "|"  # Default for audience engine files
        if args.input_file_path.endswith('.csv') or 'csv' in args.input_file_path.lower():
            delimiter = ","
        
        # Read the input file
        logger.info("Reading input file")
        
        # Handle different file types
        if args.input_file_path.endswith('.xlsx'):
            # Excel file
            df = spark.read.format("com.crealytics.spark.excel") \
                .option("header", "true") \
                .option("inferSchema", "true") \
                .load(args.input_file_path)
        else:
            # CSV/TXT file
            df = spark.read.csv(
                args.input_file_path, 
                sep=delimiter, 
                header=True, 
                inferSchema=True
            )
        
        logger.info(f"Successfully loaded file: {df.count():,} rows, {len(df.columns)} columns")
        
        # Collect basic statistics
        basic_stats = collect_basic_stats(df, args.file_name)
        
        # Collect sample data
        sample_stats = collect_sample_data(df, args.file_name)
        
        # Combine all statistics
        all_stats = {
            "execution_info": {
                "execution_date": args.execution_date,
                "stats_timestamp": args.stats_timestamp,
                "processing_timestamp": datetime.datetime.now().isoformat(),
                "input_file_path": args.input_file_path
            },
            "basic_statistics": basic_stats,
            "sample_data": sample_stats
        }
        
        # Write statistics to stats bucket
        from shared.bucket_list import get_bucket_name
        stats_bucket = get_bucket_name("stats")
        stats_output_path = f"s3a://{stats_bucket}/audience_engine/{args.execution_date}/{args.stats_timestamp}/{args.file_name}_stats"
        
        write_stats_to_s3(all_stats, stats_output_path, spark)
        
        end_time = timer()
        processing_time = end_time - start_time
        
        logger.info(f"Statistics collection completed in {processing_time:.2f} seconds")
        
        return all_stats
        
    except Exception as e:
        logger.error(f"Error processing file statistics: {e}")
        raise

def main():
    """Main entry point."""
    
    start_time = timer()
    
    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()
    
    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")
    
    # Initialize Spark Session
    spark = (SparkSession.builder
        .appName(f"AE Stats Collection - {args.file_name}")
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .getOrCreate())
    
    spark.sparkContext.setLogLevel("WARN")
    
    logger.info(f"Starting Audience Engine statistics collection job for {args.file_name}")
    
    try:
        # Process file statistics
        stats = process_file_stats(spark, args)
        
        # Calculate total time
        end_time = timer()
        total_time = end_time - start_time
        
        logger.info(f"Statistics collection job completed successfully in {total_time:.2f} seconds")
        
        # Exit successfully
        sys.exit(0)
        
    except Exception as e:
        logger.error(f"Statistics collection job failed: {type(e).__name__}: {str(e)}", exc_info=True)
        sys.exit(1)
    
    finally:
        if spark:
            spark.stop()

if __name__ == "__main__":
    main()