import os
import sys
import datetime
import argparse
import logging
import boto3
from typing import List
from pathlib import Path
from timeit import default_timer as timer

# Simple logging for EMR Serverless
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_parser():
    """Create command line argument parser for file copying."""
    parser = argparse.ArgumentParser(description="Copy and merge S3 files for Audience Engine (equivalent to shell script getmerge)")
    
    parser.add_argument("--module1_s3_output", type=str, required=True, help="S3 path to module1 output directory")
    parser.add_argument("--minmax_s3_output", type=str, required=True, help="S3 path to MinMax output directory")
    parser.add_argument("--comparison_s3_output", type=str, required=True, help="S3 path to Comparison output directory")
    parser.add_argument("--final_s3_output", type=str, required=True, help="S3 path to final output directory")
    parser.add_argument("--file_suffix", type=str, required=True, help="File suffix (e.g., July25_Supply)")
    parser.add_argument("--execution_date", type=str, required=True, help="Execution date")
    
    return parser

def merge_partitioned_files_s3(input_s3_path: str, output_s3_path: str, file_format: str = "csv"):
    """
    Merge partitioned files from S3 (equivalent to hdfs dfs -getmerge)
    Uses boto3 to directly merge part files into single file
    """
    logger.info(f"Merging S3 partitioned files from {input_s3_path} to {output_s3_path}")
    
    try:
        import boto3
        from io import StringIO
        
        # Parse S3 paths
        def parse_s3_path(s3_path):
            if s3_path.startswith("s3a://"):
                s3_path = s3_path[6:]
            elif s3_path.startswith("s3://"):
                s3_path = s3_path[5:]
            parts = s3_path.split('/', 1)
            return parts[0], parts[1] if len(parts) > 1 else ""
        
        input_bucket, input_key = parse_s3_path(input_s3_path)
        output_bucket, output_key = parse_s3_path(output_s3_path)
        
        s3 = boto3.client('s3')
        
        # List all part files in the input directory
        response = s3.list_objects_v2(Bucket=input_bucket, Prefix=input_key)
        
        if 'Contents' not in response:
            logger.warning(f"No files found in {input_s3_path}")
            return False
        
        # Filter for part files and sort them
        part_files = []
        for obj in response['Contents']:
            key = obj['Key']
            if 'part-' in key and (key.endswith('.csv') or key.endswith('.txt')):
                part_files.append(key)
        
        if not part_files:
            logger.warning(f"No part files found in {input_s3_path}")
            return False
        
        part_files.sort()  # Ensure correct order
        logger.info(f"Found {len(part_files)} part files to merge")
        
        # Optimized streaming merge - process files in chunks to avoid memory issues
        from io import BytesIO
        
        merged_content = BytesIO()
        header_written = False
        
        for i, part_file in enumerate(part_files):
            logger.info(f"Processing part file {i+1}/{len(part_files)}: {part_file}")
            
            # Stream file content to avoid loading entire file in memory
            obj_response = s3.get_object(Bucket=input_bucket, Key=part_file)
            
            # Read file line by line for memory efficiency
            lines = []
            for line in obj_response['Body'].iter_lines():
                if line:
                    lines.append(line.decode('utf-8'))
            
            if file_format.lower() == "csv" and lines:
                # For CSV, handle header properly
                if not header_written and lines[0].strip():
                    # Write header from first file
                    merged_content.write((lines[0] + '\n').encode('utf-8'))
                    header_written = True
                    # Write data lines (skip header)
                    for line in lines[1:]:
                        if line.strip():
                            merged_content.write((line + '\n').encode('utf-8'))
                else:
                    # Skip header for subsequent files, write data only
                    start_idx = 1 if lines and lines[0].strip() and ',' in lines[0] else 0
                    for line in lines[start_idx:]:
                        if line.strip():
                            merged_content.write((line + '\n').encode('utf-8'))
            else:
                # For TXT files, just append all content
                for line in lines:
                    if line.strip():
                        merged_content.write((line + '\n').encode('utf-8'))
        
        # Upload merged content to output location
        if merged_content.tell() > 0:  # Check if we have content
            merged_content.seek(0)
            s3.put_object(
                Bucket=output_bucket,
                Key=output_key,
                Body=merged_content.getvalue(),
                ContentType='text/plain' if file_format.lower() == 'txt' else 'text/csv'
            )
            logger.info(f"Successfully merged {len(part_files)} files to {output_s3_path}")
            return True
        else:
            logger.warning("No content to merge")
            return False
            
    except Exception as e:
        logger.error(f"Error merging S3 files: {e}")
        return False

def copy_excel_files_s3(source_s3_dir: str, dest_s3_dir: str):
    """
    Copy Excel files from source to destination using S3 operations
    """
    logger.info(f"Copying Excel files from {source_s3_dir} to {dest_s3_dir}")
    
    try:
        import boto3
        
        # Parse S3 paths
        def parse_s3_path(s3_path):
            if s3_path.startswith("s3a://"):
                s3_path = s3_path[6:]
            elif s3_path.startswith("s3://"):
                s3_path = s3_path[5:]
            parts = s3_path.split('/', 1)
            return parts[0], parts[1] if len(parts) > 1 else ""
        
        source_bucket, source_prefix = parse_s3_path(source_s3_dir)
        dest_bucket, dest_prefix = parse_s3_path(dest_s3_dir)
        
        s3 = boto3.client('s3')
        
        # List Excel files in source directory
        response = s3.list_objects_v2(Bucket=source_bucket, Prefix=source_prefix)
        
        if 'Contents' not in response:
            logger.warning(f"No files found in {source_s3_dir}")
            return False
        
        excel_files = []
        for obj in response['Contents']:
            key = obj['Key']
            if key.endswith('.xlsx') or key.endswith('.xls'):
                excel_files.append(key)
        
        if not excel_files:
            logger.warning(f"No Excel files found in {source_s3_dir}")
            return False
        
        # Copy each Excel file
        copied_count = 0
        for excel_file in excel_files:
            filename = excel_file.split('/')[-1]
            dest_key = f"{dest_prefix}/{filename}" if dest_prefix else filename
            
            # Copy file within S3
            copy_source = {'Bucket': source_bucket, 'Key': excel_file}
            s3.copy_object(CopySource=copy_source, Bucket=dest_bucket, Key=dest_key)
            
            logger.info(f"Copied Excel file: {filename}")
            copied_count += 1
        
        logger.info(f"Successfully copied {copied_count} Excel files")
        return True
        
    except Exception as e:
        logger.error(f"Error copying Excel files: {e}")
        return False

def process_file_copying(args: argparse.Namespace):
    """
    Main function to process file copying and merging (equivalent to shell script copy_to_local_temp)
    """
    
    start_time = timer()
    
    logger.info("Starting file copying and merging process")
    logger.info(f"Module1 S3 output: {args.module1_s3_output}")
    logger.info(f"MinMax S3 output: {args.minmax_s3_output}")
    logger.info(f"Comparison S3 output: {args.comparison_s3_output}")
    logger.info(f"Final S3 output: {args.final_s3_output}")
    logger.info(f"File suffix: {args.file_suffix}")
    
    try:
        # Define files to merge (equivalent to shell script files_to_merge array)
        files_to_merge = [
            {
                "name": "counties_check.csv",
                "source": f"{args.module1_s3_output}/counties_check",
                "dest": f"{args.final_s3_output}/counties_check.csv",
                "format": "csv"
            },
            {
                "name": "Adsmart_liveramp_files_used.xlsx",
                "source": f"{args.module1_s3_output}/Adsmart_liveramp_files_used.xlsx",
                "dest": f"{args.final_s3_output}/Adsmart_liveramp_files_used.xlsx",
                "format": "xlsx"
            },
            {
                "name": f"Digital_taxonomy_Audience_Engine_{args.file_suffix}.txt",
                "source": f"{args.module1_s3_output}/Digital_taxonomy_Audience_Engine",
                "dest": f"{args.final_s3_output}/Digital_taxonomy_Audience_Engine_{args.file_suffix}.txt",
                "format": "txt"
            },
            {
                "name": f"Digital_taxonomy_Count_{args.file_suffix}.txt",
                "source": f"{args.module1_s3_output}/Digital_taxonomy_Count",
                "dest": f"{args.final_s3_output}/Digital_taxonomy_Count_{args.file_suffix}.txt",
                "format": "txt"
            }
        ]
        
        copied_files = []
        
        # Process each file (equivalent to shell script loop)
        for file_info in files_to_merge:
            logger.info(f"Processing file: {file_info['name']}")
            
            try:
                if file_info['format'] in ['csv', 'txt']:
                    # Merge partitioned files using S3 operations (equivalent to getmerge)
                    if merge_partitioned_files_s3(file_info['source'], file_info['dest'], file_info['format']):
                        copied_files.append(file_info['name'])
                        logger.info(f"Successfully processed {file_info['name']}")
                    else:
                        logger.warning(f"Failed to process {file_info['name']}")
                        
                elif file_info['format'] == 'xlsx':
                    # Excel files - copy from source to destination
                    if copy_excel_files_s3(file_info['source'], args.final_s3_output):
                        copied_files.append(file_info['name'])
                        logger.info(f"Successfully processed Excel file {file_info['name']}")
                    else:
                        logger.warning(f"Failed to process Excel file {file_info['name']}")
                    
            except Exception as e:
                logger.warning(f"Error processing {file_info['name']}: {e}")
        
        # Copy Excel files from MinMax and Comparison outputs
        logger.info("Processing Excel outputs from MinMax and Comparison stages")
        
        # MinMax Excel files
        try:
            if copy_excel_files_s3(args.minmax_s3_output, args.final_s3_output):
                logger.info("MinMax Excel files processed successfully")
            else:
                logger.warning("No MinMax Excel files found or failed to copy")
        except Exception as e:
            logger.warning(f"Error processing MinMax Excel files: {e}")
        
        # Comparison Excel files
        try:
            if copy_excel_files_s3(args.comparison_s3_output, args.final_s3_output):
                logger.info("Comparison Excel files processed successfully")
            else:
                logger.warning("No Comparison Excel files found or failed to copy")
        except Exception as e:
            logger.warning(f"Error processing Comparison Excel files: {e}")
        
        # Create summary of copied files
        logger.info("=== FILE COPYING SUMMARY ===")
        for file_name in copied_files:
            logger.info(f"✓ Processed: {file_name}")
        
        end_time = timer()
        processing_time = end_time - start_time
        
        logger.info(f"File copying and merging completed in {processing_time:.2f} seconds")
        logger.info(f"Total files processed: {len(copied_files)}")
        
        return {
            "copied_files": copied_files,
            "processing_time": processing_time,
            "total_files": len(copied_files)
        }
        
    except Exception as e:
        logger.error(f"Error in file copying process: {e}")
        raise

def main():
    """Main entry point."""
    
    start_time = timer()
    
    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()
    
    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")
    
    # No Spark session needed - using S3 operations only
    logger.info("File copy using S3 operations only - no Spark session required")
    
    logger.info(f"Starting Audience Engine file copying job for {args.execution_date}")
    
    try:
        # Process file copying and merging
        result = process_file_copying(args)
        
        # Calculate total time
        end_time = timer()
        total_time = end_time - start_time
        
        logger.info(f"File copying job completed successfully in {total_time:.2f} seconds")
        logger.info(f"Files processed: {result['total_files']}")
        
        # Exit successfully
        sys.exit(0)
        
    except Exception as e:
        logger.error(f"File copying job failed: {type(e).__name__}: {str(e)}", exc_info=True)
        sys.exit(1)
    
    finally:
        logger.info("File copy operations completed")

if __name__ == "__main__":
    main()