from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from datetime import datetime
import sys
import os
import glob
import subprocess
from pyspark.sql.functions import length, col, regexp_replace


#########################################################################################################
# File Configuration Logic                                                                              #
#########################################################################################################
def file_config(spark, raw_df, filePath):
    """Gets column metadata and preserves exact input file order"""
    from pyspark.sql.functions import max as max_func, length
    import pyspark.sql.types as T
    
    # Store the EXACT original column order - EXCLUDE Original_Row_Number for stats
    original_columns = [col for col in raw_df.columns if col != "Original_Row_Number"]
    
    # Create expressions for all aggregations in a single pass
    agg_exprs = {}
    
    # Prepare aggregation expressions for all columns (except Original_Row_Number)
    for field in raw_df.schema.fields:
        column_name = field.name
        if column_name == "Original_Row_Number":
            continue  # Skip Original_Row_Number completely
            
        if isinstance(field.dataType, (T.StringType, T.BinaryType)):
            # For string columns, get max length
            agg_exprs[f"{column_name}_length"] = max_func(length(col(column_name)))
        else:
            # For numeric columns, get max value
            agg_exprs[f"{column_name}_max"] = max_func(col(column_name))
    
    # Run all aggregations in a single pass
    agg_results = raw_df.agg(*[expr.alias(name) for name, expr in agg_exprs.items()]).collect()[0]
    
    # Build config rows using the aggregation results
    config_rows = []
    for i, column_name in enumerate(original_columns):
        # Find the field in schema
        field = next((f for f in raw_df.schema.fields if f.name == column_name), None)
        if not field:
            continue
            
        data_type = str(field.dataType)
        
        if isinstance(field.dataType, (T.StringType, T.BinaryType)):
            max_length = agg_results[f"{column_name}_length"]
            size = str(max_length) if max_length is not None else "0"
            scale = ""
        elif any(isinstance(field.dataType, t) for t in (T.IntegerType, T.LongType, T.DoubleType, T.FloatType, T.DecimalType)):
            max_val = agg_results[f"{column_name}_max"]
            size = str(max_val) if max_val is not None else "0"
            
            if isinstance(field.dataType, T.DecimalType):
                scale = str(field.dataType.scale)
            else:
                scale = "0" if isinstance(field.dataType, (T.IntegerType, T.LongType)) else "Variable"
        else:
            size = "0"
            scale = ""
        
        # Simple sequential position (1-based indexing)
        position = i + 1
            
        config_rows.append({
            "Name": column_name,
            "Data Type": data_type,
            "Size": size,
            "Scale": scale,
            "Source": filePath,
            "Description": "",
            "Position": position
        })
    
    # Create DataFrame from config data
    schema = T.StructType([
        T.StructField("Name", T.StringType(), True),
        T.StructField("Data Type", T.StringType(), True),
        T.StructField("Size", T.StringType(), True),
        T.StructField("Scale", T.StringType(), True),
        T.StructField("Source", T.StringType(), True),
        T.StructField("Description", T.StringType(), True),
        T.StructField("Position", T.IntegerType(), True)
    ])
    
    stats_config_df = spark.createDataFrame(config_rows, schema)
    return stats_config_df


#########################################################################################################
# escape_xml_metacharacters (Matches Alteryx Function)                                                  #
# https://help.alteryx.com/20241/en/designer/functions/specialized-functions.html                       #
#########################################################################################################

def escape_xml_metacharacters(df, column_name):
    """
    Escapes XML metacharacters in the specified column.
    
    Args:
        df: The DataFrame containing the column to process
        column_name: The name of the column to process
        
    Returns:
        DataFrame with the specified column having XML metacharacters escaped
    """
    # Define replacements for XML special characters
    replacements = {
        "&": "&amp;",  # Must be first to avoid double-escaping
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&apos;"
    }

    # Apply replacements one by one
    result_df = df
    for char, escaped_char in replacements.items():
        result_df = result_df.withColumn(column_name, regexp_replace(col(column_name), char, escaped_char))
    
    return result_df

#########################################################################################################
# Helper Functions                                                                                      #
#########################################################################################################

def ensure_directory_exists(directory_path):
    """
    Creates a directory if it doesn't exist
    
    Args:
        directory_path: Path to check/create
        
    Returns:
        True if directory exists or was created successfully
    """
    if not os.path.exists(directory_path):
        try:
            os.makedirs(directory_path)
            return True
        except Exception as e:
            print(f"Error creating directory {directory_path}: {str(e)}")
            return False
    return True

def safe_cast(val, to_type, default=None):
    """
    Safely casts a value to the specified type, returning a default if it fails
    
    Args:
        val: Value to cast
        to_type: Type to cast to (e.g., int, float, str)
        default: Default value if casting fails
        
    Returns:
        Casted value or default
    """
    try:
        return to_type(val)
    except (ValueError, TypeError):
        return default